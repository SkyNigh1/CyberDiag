"""
Logging Configuration Module

This module provides centralized logging setup for the CyberDiag application.
It configures a consistent logging format and level across all modules.

Attributes:
    DEFAULT_FORMAT (str): Default log message format
    DEFAULT_DATE_FORMAT (str): Default timestamp format

Functions:
    setup_logging: Initialize the logging configuration
    get_logger: Get a logger instance for a specific module

Example:
    >>> from utils.logging_config import setup_logging, get_logger
    >>> setup_logging()
    >>> logger = get_logger(__name__)
    >>> logger.info("Message logged")
    2026-03-12 10:30:00 [INFO] __main__: Message logged
"""

import logging
import os
import sys

# Constants for logging configuration
DEFAULT_FORMAT = '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
DEFAULT_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'


def setup_logging(level: int | None = None) -> None:
    """
    Configure the logging system for the entire CyberDiag application.

    This function should be called once at application startup, before
    any logging calls are made. It configures the root logger with
    appropriate handlers and formatters.

    Args:
        level: The logging level to use (e.g., logging.DEBUG, logging.INFO).
               If None, the level is determined from the DEBUG environment
               variable. Defaults to INFO if DEBUG is not set.

    Environment Variables:
        DEBUG: Set to 'true', '1', or 'yes' to enable DEBUG level logging.

    Example:
        >>> import logging
        >>> setup_logging(logging.DEBUG)  # Force debug level
        >>> setup_logging()  # Use environment variable or default to INFO

    Note:
        This function uses basicConfig, so it should only be called once.
        Subsequent calls will have no effect unless force=True is added
        in future versions.
    """
    if level is None:
        # Check for DEBUG environment variable
        if os.environ.get('DEBUG', '').lower() in ('true', '1', 'yes'):
            level = logging.DEBUG
        else:
            level = logging.INFO

    logging.basicConfig(
        level=level,
        format=DEFAULT_FORMAT,
        datefmt=DEFAULT_DATE_FORMAT,
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the specified name.

    This is a convenience wrapper around logging.getLogger() that ensures
    consistent logger naming throughout the application.

    Args:
        name: The name of the logger, typically __name__ of the calling module.
              This creates a hierarchical logger name based on the module path.

    Returns:
        A Logger instance configured for the specified name.

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Processing started")
        >>> logger.error("An error occurred", exc_info=True)

    Note:
        Loggers are cached by name, so multiple calls with the same name
        return the same logger instance.
    """
    return logging.getLogger(name)
