"""
CyberDiag Utilities Module

This module provides shared utility functions used across the CyberDiag application.

Components:
    - logging_config: Centralized logging configuration
        - setup_logging(): Initialize logging for the application
        - get_logger(): Get a logger instance for a specific module

Logging Configuration:
    - Default level: INFO (can be set to DEBUG via DEBUG environment variable)
    - Format: timestamp [LEVEL] module_name: message
    - Output: stdout (console)

Example:
    >>> from utils.logging_config import setup_logging, get_logger
    >>> setup_logging()  # Call once at application startup
    >>> logger = get_logger(__name__)
    >>> logger.info("Application started")

Environment Variables:
    - DEBUG: Set to 'true', '1', or 'yes' to enable DEBUG level logging
"""

from utils.logging_config import setup_logging, get_logger

__all__ = ["setup_logging", "get_logger"]
