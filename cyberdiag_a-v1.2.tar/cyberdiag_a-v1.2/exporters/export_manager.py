import json
import math
import uuid
from datetime import datetime
from pathlib import Path

import weasyprint
from jinja2 import Environment, FileSystemLoader


def get_project_root():
    """Return the physical root path of the project."""
    return Path(__file__).resolve().parent.parent


_TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
_JINJA_ENV = Environment(loader=FileSystemLoader(str(_TEMPLATES_DIR)))
_REPORT_TEMPLATE = _JINJA_ENV.get_template("report.html")


def _compute_network_score(scan_data):
    """Compute a score aligned with frontend logic for network scans."""
    if not isinstance(scan_data, list):
        return None

    criticality_map = {
        "CRITIQUE": "critical",
        "ELEVEE": "high",
        "MOYENNE": "medium",
        "FAIBLE": "low",
    }

    critical_count = 0
    high_count = 0
    medium_count = 0
    low_count = 0

    def _bump_count(sev):
        nonlocal critical_count, high_count, medium_count, low_count
        if sev == "critical":
            critical_count += 1
        elif sev == "high":
            high_count += 1
        elif sev == "medium":
            medium_count += 1
        elif sev == "low":
            low_count += 1

    total_exploits = 0
    hosts_with_issues = 0
    total_hosts = max(1, len(scan_data))

    for host in scan_data:
        host_has_issues = False

        for vuln in host.get("vulnerabilities", []) or []:
            sev = criticality_map.get(vuln.get("criticite"), "medium")
            _bump_count(sev)
            if sev in ("critical", "high", "medium"):
                host_has_issues = True

        for port in host.get("ports_ouverts", []) or []:
            sev = criticality_map.get(port.get("criticite"), "medium")
            _bump_count(sev)
            exploits = int(port.get("nombre_exploits", 0) or 0)
            total_exploits += exploits
            if sev in ("critical", "high", "medium") or exploits > 0:
                host_has_issues = True

        tcp_sev = criticality_map.get(host.get("criticite_tcpsequence"), "low")
        _bump_count(tcp_sev)
        ipid_sev = criticality_map.get(host.get("criticite_ipidsequence"), "low")
        _bump_count(ipid_sev)

        if host_has_issues:
            hosts_with_issues += 1

    score = 100
    score -= critical_count * 20
    score -= high_count * 12
    score -= medium_count * 6
    score -= low_count * 1

    if total_exploits > 0:
        score -= min(25, round(math.log1p(total_exploits) * 6))

    host_risk_ratio = hosts_with_issues / total_hosts
    score -= round(host_risk_ratio * 10)

    return max(0, min(100, int(round(score))))


def _build_network_stats(scan_data):
    """Compute summary stats for network reports."""
    total_hosts = len(scan_data) if isinstance(scan_data, list) else 0
    total_ports = 0
    total_exploits = 0
    hosts_with_issues = 0

    if isinstance(scan_data, list):
        for host in scan_data:
            ports = host.get("ports_ouverts", []) or []
            total_ports += len(ports)
            host_has_issues = False
            for port in ports:
                exploits = int(port.get("nombre_exploits", 0) or 0)
                total_exploits += exploits
                if exploits > 0 or port.get("criticite") in {"CRITIQUE", "ELEVEE", "MOYENNE"}:
                    host_has_issues = True
            if host.get("vulnerabilities"):
                host_has_issues = True
            if host_has_issues:
                hosts_with_issues += 1

    return {
        "total_hosts": total_hosts,
        "total_ports": total_ports,
        "total_exploits": total_exploits,
        "hosts_with_issues": hosts_with_issues,
    }


def export_scan(scan_type: str, scan_data: any) -> dict:
    """
    Standardize scan output by writing JSON, HTML, and PDF
    to a dedicated results/<scan_id>/ folder.
    
    Args:
        scan_type (str): 'network' or 'system'
        scan_data (any): The parsed scan results dictionary/list.
                         For system scans, expects a dict with 'summary' structure.
        
    Returns:
        dict: Generated paths for json, html, and pdf artifacts
    """
    root = get_project_root()
    # Unique ID for this scan
    now = datetime.now()
    scan_id = now.strftime("%Y%m%d_%H%M%S") + "_" + str(uuid.uuid4())[:8]

    # Destination folder 'results/<scan_id>'
    out_dir = root / "results" / scan_id
    out_dir.mkdir(parents=True, exist_ok=True)

    json_path = out_dir / "data.json"
    html_path = out_dir / "report.html"
    pdf_path = out_dir / "report.pdf"

    # Ensure system scan data has summary structure to prevent template errors
    if scan_type == "system" and isinstance(scan_data, dict) and "summary" not in scan_data:
        scan_data["summary"] = {"total_tests": 0, "warnings": 0, "suggestions": 0}

    # 1. Write structured JSON
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(scan_data, f, ensure_ascii=False, indent=4)

    # 2. Render HTML via Jinja2
    network_stats = _build_network_stats(scan_data) if scan_type == "network" else None
    score = _compute_network_score(scan_data) if scan_type == "network" else scan_data.get(
        "security_score") if isinstance(scan_data, dict) else None

    html_content = _REPORT_TEMPLATE.render(
        scan_type=scan_type,
        scan_id=scan_id,
        date=now.strftime("%Y-%m-%d %H:%M:%S"),
        data=scan_data,
        score=score,
        network_stats=network_stats,
    )

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    # 3. Generate PDF from HTML
    # Catching weasyprint errors just in case dependencies are missing
    try:
        weasyprint.HTML(string=html_content).write_pdf(target=str(pdf_path))
    except Exception as e:
        print(f"Warning: PDF generation failed ({e}). HTML report available at {html_path}.")
        # We can write a dummy PDF or log a detailed warning if needed
        pass

    return {
        "scan_id": scan_id,
        "json": str(json_path),
        "html": str(html_path),
        "pdf": str(pdf_path) if pdf_path.exists() else None,
        "scan_type": scan_type,
        "date": now.isoformat()
    }
