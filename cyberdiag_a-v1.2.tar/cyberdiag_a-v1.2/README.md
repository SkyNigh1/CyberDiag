# CyberDiag

**Plateforme d'audit de sécurité semi-automatisée pour TPE, PME et collectivités locales**

CyberDiag facilite l'évaluation du niveau de sécurité informatique sans nécessiter d'expertise technique. L'outil
propose des scans réseau (nmap) et système (Lynis) avec une interface graphique intuitive, un questionnaire de maturité
cyber, et génère des rapports détaillés avec recommandations classées par criticité.

---
Notion : https://www.notion.so/boutros-victor/27e5b1ef11c8802aaca5da6420c83ece?source=copy_link

## Lancer l'application

Deux options selon votre profil :

---

### Option A — Binaire précompilé (recommandé)

> Aucun prérequis technique. Téléchargez l'archive depuis la page **Releases** du dépôt GitLab.

```sh
tar -xzf cyberdiag-v1.0-linux.tar.gz
sudo ./install.sh    # installe nmap, lynis et GTK (une seule fois)
sudo ./cyberdiag     # lance l'application
```

**Distributions supportées :** Ubuntu, Debian, Kali, Fedora, Arch Linux, Manjaro

---

### Option B — Compiler depuis les sources

> Pour les développeurs ou ceux qui préfèrent compiler eux-mêmes.

**Prérequis :** `make`, `python3.10+`, accès `sudo`

```sh
git clone <URL_DU_REPO>
cd cyberdiag_a
make setup           # installe les dépendances + configure le venv
make build           # compile le binaire dans dist/
sudo ./dist/cyberdiag
```

> `make setup` installe les dépendances système (nmap, lynis, GTK) et configure l'environnement virtuel Python.
> `make build` génère `dist/cyberdiag`, un binaire autonome (Python embarqué, pas de venv nécessaire à l'exécution).

---

### Compilation et empaquetage (mainteneurs)

```sh
make setup           # configure l'environnement de développement
make build           # binaire PyInstaller → dist/cyberdiag
make build-appimage  # AppImage → dist/CyberDiag-x86_64.AppImage
make release         # binaire + AppImage en une commande
make clean           # supprime le venv et les artefacts de build
```

Pour des instructions détaillées, consultez la **[documentation de compilation](docs/BUILD.md)**.

---

## Fonctionnalités

### Types de scans disponibles

- **Scan Réseau** : Détection de machines actives, ports ouverts, services vulnérables (via nmap)
- **Scan Système** : Audit de configuration Linux, permissions, services, mise à jour (via Lynis)

### Niveaux d'audit

1. **Basique** : Vérifications essentielles pour un fonctionnement sécurisé
2. **Intermédiaire** : Analyse approfondie avec tests détaillés
3. **Avancé** : Audit complet et personnalisé dépassant les obligations réglementaires

### Autres fonctionnalités

- **Questionnaire de maturité cyber** : Évaluation préalable du niveau de sécurité
- **Recommandations priorisées** : Classement par criticité (critique, élevée, moyenne, faible)
- **Historique des scans** : Consultation des audits précédents avec artefacts JSON / HTML / PDF
- **Interface moderne** : Navigation fluide avec animations 3D (Three.js, GSAP)

---

## Désinstallation

### Environnement de développement

```sh
make clean
```

Supprime l'environnement virtuel local ainsi que les artefacts de build/caches du projet. Les dépendances système (`nmap`, `lynis`, GTK/WebKit) restent installées et doivent être retirées via le gestionnaire de paquets de votre distribution si besoin.

### Application installée depuis `dist/`

```sh
sudo /usr/local/bin/uninstall-cyberdiag.sh
# ou, depuis le dossier dist/
sudo ./dist/uninstall.sh
```

---

## Contexte du projet

### Objectif

Le projet **CyberDiag** vise à concevoir une plateforme d'audit de sécurité semi-automatisée, pensée spécialement pour
les petites structures (TPE, PME, collectivités locales) qui n'ont pas les moyens techniques ou humains pour gérer
efficacement leur sécurité informatique.

L'outil permet à des utilisateurs non-spécialistes de réaliser des audits de sécurité grâce à :

- Une interface intuitive et accessible
- Un questionnaire adaptatif sur l'infrastructure informatique
- Des scans automatisés du réseau et du système
- Des rapports clairs avec recommandations priorisées

### Problématique

Les petites structures sont souvent les plus vulnérables car elles n'ont ni les outils, ni les compétences pour se
protéger correctement. Les outils existants comme **Lynis** ou **Nmap** sont trop complexes pour des utilisateurs non
techniques.

**CyberDiag** se présente comme un outil de pré-diagnostic qui permet de :

- Identifier les failles de sécurité les plus courantes (systèmes Linux et réseaux)
- Classer les problèmes par ordre de criticité pour prioriser les actions
- Donner des recommandations claires conformes aux référentiels ANSSI
- Conserver un historique local des audits pour suivre l'évolution

---

## Architecture technique

### Technologies utilisées

- **Backend** : Python 3 avec pywebview (interface native)
- **Frontend** : HTML5, CSS3, JavaScript (Three.js pour animations 3D, GSAP pour transitions)
- **Outils de scan** :
    - `nmap` : Scan réseau et détection de vulnérabilités
    - `Lynis` : Audit système Linux
- **Interface graphique** : GTK3 + WebKit2GTK

### Structure modulaire

```
cyberdiag_a/
├── cyberdiag.py             # Point d'entrée principal
├── gui/                      # Module Interface utilisateur
│   ├── webview_external.py  # API bridge backend
│   ├── index.html           # Page principale
│   ├── styles.css           # Styles
│   ├── js/                  # Scripts frontend
│   │   ├── main.js          # Initialisation
│   │   ├── navigation.js    # Navigation entre pages
│   │   ├── questionnaire.js # Questionnaire de maturité
│   │   ├── scan.js          # Gestion des scans
│   │   ├── results.js       # Affichage des résultats
│   │   └── history.js       # Historique des scans
│   │   └── questions
│   │       └── questions.json # Questions du questionnaire
│   └── lib/                 # Bibliothèques JS (Three.js, GSAP)
├── docs/                     # Documentation du projet
├── network/                  # Module scan réseau
│   ├── nmap_call.py         # Interface nmap
│   └── networkScanAnalysis.py # Analyse des résultats
├── system/                   # Module scan système
│   └── lynis_interface.py   # Interface Lynis complète
├── tests/                    # Tests centralisés
│   ├── conftest.py          # Fixtures partagées et configuration pytest
│   ├── test_cyberdiag_main.py    # Tests point d'entrée principal
│   ├── test_logging_config.py    # Tests configuration logging
│   ├── test_conftest_helpers.py  # Tests des helpers conftest
│   ├── network/             # Tests réseau
│   │   ├── unit/            # Tests unitaires
│   │   │   ├── test_scan_analysis.py  # Analyse XML, vulnérabilités, export JSON
│   │   │   └── test_nmap_scanner.py   # Classe NmapScanner, niveaux de profondeur
│   │   └── integration/     # Tests d'intégration
│   │       └── test_network_integration.py
│   ├── system/              # Tests système
│   │   ├── unit/            # Tests unitaires
│   │   │   └── test_lynis.py  # Parsers, Analyzer, Interface, ReportGenerator
│   │   └── integration/     # Tests d'intégration
│   │       └── test_system_integration.py
│   ├── gui/                 # Tests interface graphique
│   │   ├── unit/            # Tests unitaires
│   │   │   └── test_scan_api.py  # ScanAPI, helpers, notifications
│   │   └── integration/     # Tests d'intégration bridge
│   │       └── test_integration_gui.py
│   └── security/            # Tests de sécurité et intégrité
│       └── unit/            # Tests unitaires (privilèges & intégrité)
│           ├── test_integrity.py   # Vérification assets GUI
│           └── test_privileges.py  # Élévation de privilèges
├── results/                 # Résultats bruts des scans (JSON historiques)
│   ├── network/             # Scans réseau
│   └── system/              # Scans système
├── result/                  # Exports consolidés générés à l'exécution
│   └── <scan_id>/           # data.json, report.html, report.pdf
└── build/                   # Scripts de compilation
    ├── build.sh             # Orchestrateur build/release (binaire + AppImage)
    ├── build.py             # Shim de compatibilité vers build.sh
    ├── build-appimage.sh    # Shim de compatibilité vers build.sh
    └── cyberdiag.spec       # Spécifications PyInstaller
```

### Privilèges requis

L'application nécessite des **droits root** pour :

- Accéder aux configurations système complètes
- Exécuter nmap avec toutes les fonctionnalités (scan SYN, détection OS)
- Utiliser Lynis pour un audit système approfondi

---

## Méthodologie de développement

Le projet a été développé selon une approche **Agile** avec la méthode **SCRUM** :

- **Sprints itératifs** : Développement par cycles courts avec objectifs précis
- **Livraisons incrémentales** : Chaque sprint produit une version testable
- **Revues régulières** : Retours fréquents pour éviter les conflits et corriger les bugs
- **Priorisation continue** : Identification collaborative des priorités à chaque sprint

Cette méthodologie favorise la collaboration, la progression continue, et maintient une vision claire des objectifs tout
en simulant une organisation professionnelle réelle.

---

## Tests et qualité

Le projet inclut une suite de tests complète organisée par module dans le package `tests/` :

### Tests unitaires

- `tests/gui/unit/test_scan_api.py` : Tests de l'API `ScanAPI` et helpers
- `tests/network/unit/test_scan_analysis.py` : Tests d'analyse XML et évaluation des vulnérabilités
- `tests/network/unit/test_nmap_cli.py` : Tests de l'interface CLI `nmap`
- `tests/network/unit/test_nmap_scanner.py` : Tests du scanner Nmap
- `tests/system/unit/test_lynis.py` : Tests complets de l'interface Lynis
- `tests/security/unit/test_integrity.py` : Tests d'intégrité des assets
- `tests/security/unit/test_privileges.py` : Tests de la gestion des privilèges root
- `tests/exporters/test_export_manager.py` : Tests d'export JSON / HTML / PDF

### Tests d'intégration

- `tests/gui/integration/test_integration_gui.py` : Tests de l'interface graphique
- `tests/network/integration/test_network_integration.py` : Tests d'intégration du module réseau
- `tests/system/integration/test_system_integration.py` : Tests d'intégration du module système

### Tests utilitaires

- `tests/test_cyberdiag_main.py` : Tests du point d'entrée principal
- `tests/test_logging_config.py` : Tests de la configuration du logging
- `tests/test_conftest_helpers.py` : Tests des fonctions helpers de conftest

Pour lancer tous les tests :

```sh
make test

# Avec couverture de code
env PYTHONPATH=. .venv/bin/pytest tests/ --cov=. --cov-report=html
```

Documentation des tests : [test_applicatif.pdf](docs/test_applicatif.pdf)

---

## Sécurité et conformité

- Recommandations alignées sur les **référentiels ANSSI**
- Scan des ports ouverts et services vulnérables
- Vérification des permissions fichiers et configurations SSH
- Audit des mises à jour de sécurité manquantes
- Détection de mots de passe faibles et comptes inactifs

---

## CI/CD

Le projet utilise GitLab CI/CD pour l'automatisation des tests, de l'assurance qualité et de la distribution.

- **Documentation de compilation** : voir [BUILD.md](docs/BUILD.md) pour les instructions de configuration de
  l'environnement et de création des paquets autonomes.
- **Documentation du pipeline** : voir [PIPELINE.md](docs/PIPELINE.md) pour le détail des étapes et des jobs CI/CD.
- **Automatisation** : exécution automatique des tests, des linters et de la génération d'artefacts à chaque push et
  merge request.
- **Releases sur tag** : lors d'un tag Git, le pipeline publie les livrables (binaire Linux, AppImage, documentation)
  dans la GitLab Generic Package Registry, puis les relie directement à la release GitLab.

---

## Auteurs

**Équipe CyberDiag BUT2 Info :**

- Victor BOUTROS : SCRUM Master, développeur backend
- Yann CLOAREC : développeur fullstack
- Luke BAFFAIT : UX Designer & développeur frontend
- Tiya BAUDIN : développeuse backend
- Kyliann FONTAINE : testeur et développeur backend
