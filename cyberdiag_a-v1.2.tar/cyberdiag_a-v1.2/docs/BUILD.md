# Building CyberDiag

This document provides instructions on how to set up the development environment and build CyberDiag into different
formats (Standalone Binary and AppImage).

## 1. Prerequisites

CyberDiag depends on several system-level libraries for its graphical interface (GTK3 and WebKit2GTK) and its security
analysis tools (`nmap` and `lynis`).

The following packages are required on most Linux distributions:

- **Python 3.10+** (the GitLab CI pipeline currently uses Python 3.12 on Ubuntu 24.04)
- **Make** (required - mandatory for all build, setup, and packaging operations)
- **Sudo** (required for installing system dependencies)
- **GTK 3.0**
- **WebKit2GTK** (4.0, 4.1, or 6.0)
- **GObject Introspection**
- **Nmap**
- **Lynis**

### Installing Make

If `make` is not already installed on your system, install it using your distribution's package manager:

**Ubuntu/Debian:**
```bash
sudo apt-get update && sudo apt-get install -y build-essential
```

**Fedora:**
```bash
sudo dnf install -y make
```

**Arch Linux:**
```bash
sudo pacman -S make
```

## 2. Environment Setup

To simplify setup, use `make` as the single supported entrypoint. It installs system dependencies, recreates `.venv`,
and delegates all build outputs to one orchestrator (`build/build.sh`).

```bash
# Install system and python dependencies (non-interactive)
make setup

# Optional: same setup, then open an activated shell
make dev
```

This command will:

1. Install system-level dependencies (requires sudo/root).
2. Recreate a `.venv` virtual environment.
3. Link system-only GTK Python bindings (`gi`, `cairo`) inside `.venv` when available.
4. Install the project in editable mode with development extras (`pip install -e .[dev]`).
5. Verify all imports work correctly.

Once the setup is complete, you can launch the application in development mode:

```bash
.venv/bin/cyberdiag
```

## 3. Building a Standalone Binary (PyInstaller)

CyberDiag can be compiled into a single standalone executable using PyInstaller. This binary includes all Python
dependencies but still requires system-level GTK and WebKit libraries to be present on the host system.

The build process is handled by `build/build.sh` with explicit subcommands, and `make` calls it for you.

```bash
# Optional: prepare env explicitly
make setup

# Build (auto-creates .venv if missing)
make build
```

**Output:**

- `dist/cyberdiag`: The standalone executable.
- `dist/`: Also contains installation resources (`install.sh`, `uninstall.sh`, etc.).

Temporary PyInstaller work files are removed automatically, while final artifacts stay in `dist/`.

## 4. Building an AppImage

The AppImage format is a portable Linux package that runs on many distributions. Our AppImage build process uses the
PyInstaller binary created in the previous step.

```bash
# Build binary and package it as AppImage
make build-appimage

# Recommended one-command release build
make release
```

**Output:**

- `dist/CyberDiag-x86_64.AppImage`: The final AppImage package.

**Note:** In CI/Docker, the orchestrator extracts `appimagetool` before packaging to bypass FUSE requirements.

Temporary packaging directories are cleaned automatically after `make build-appimage` and `make release` complete.

## 5. Build Commands Summary

| Command               | Description                                                               |
|:----------------------|:--------------------------------------------------------------------------|
| `make setup`          | Installs system dependencies and recreates the Python virtual environment. |
| `make dev`            | Runs `make setup`, then opens an activated shell for development. |
| `make build`          | Compiles the application into a single executable using PyInstaller. |
| `make build-appimage` | Builds the AppImage, auto-builds the binary if missing. |
| `make release`        | Recommended release command (`build` + `build-appimage`). |
| `make clean`          | Removes build artifacts, caches, and the local `.venv` development environment. |
| `make test`           | Runs the test suite using `pytest`.                                       |
| `make lint`           | Runs the quick flake8 error gate used locally.                            |

To run the same extended linters as CI locally, use the virtual environment directly:

```bash
env PYTHONPATH=. .venv/bin/flake8 cyberdiag.py gui/ network/ system/ tests/ --count --statistics --max-line-length=120 --exclude=.venv,__pycache__
env PYTHONPATH=. .venv/bin/black --check --diff cyberdiag.py gui/ network/ system/ tests/ --exclude=.venv
env PYTHONPATH=. .venv/bin/pylint cyberdiag.py gui/*.py network/*.py system/*.py --disable=C0111,W1203,R0903,R0913
```

## 6. Installation and Uninstallation

### Installing the built package

Once you've built the standalone package in `dist/`, you can install it on your system using the provided script:

```bash
sudo ./dist/install.sh
```

This will:

1. Verify and install system dependencies (nmap, lynis, GTK3, WebKit2GTK).
2. Install the `cyberdiag` binary to `/usr/local/bin/`.
3. Install a desktop entry and application icon.

### Uninstalling

To remove the installed application:

```bash
sudo /usr/local/bin/uninstall-cyberdiag.sh
# OR from the dist folder:
sudo ./dist/uninstall.sh
```

## 7. Troubleshooting

### FUSE issues (AppImage)

If you encounter errors related to FUSE when running the AppImage, you can either:

1. Install FUSE on your system (e.g., `sudo apt install fuse`).
2. Extract the AppImage and run it manually:
   ```bash
   ./CyberDiag-x86_64.AppImage --appimage-extract
   ./squashfs-root/AppRun
   ```

### Missing GObject Introspection (`gi`)

If you get an error saying `No module named 'gi'`, ensure you have run `make setup` (or `make build`) and are
using the `.venv` it created. The setup script links required system GTK bindings into `.venv` after creation.

### Build artifacts locations

- **Build scripts**: `build/` (specifically `build/build.sh`)
- **Spec file**: `build/cyberdiag.spec`
- **Temporary build files**: `build/temp/`
- **Final distribution files**: `dist/`
