# CyberDiag CI/CD Pipeline Documentation

This document describes the CI/CD pipeline for the CyberDiag project. The pipeline is configured using GitLab CI/CD and
is defined in the `.gitlab-ci.yml` file.

## Pipeline Overview

The pipeline is designed to ensure code quality, security, verify functionality through tests, build the application,
and prepare distribution packages. It consists of 9 stages:

1. **Dependencies**: Environment setup and dependency installation.
2. **Lint**: Code style and quality checks.
3. **Security**: Static Application Security Testing (SAST) and dependency vulnerability scanning.
4. **Test**: Unit and integration tests (including privilege check and coverage).
5. **Build**: Application compilation with PyInstaller (requires `make`).
6. **Package**: Creating distributable packages (requires `make`).
7. **Distro-Lifecycle**: Development-environment setup, launch, and cleanup verification on different distributions (requires `make`).
8. **Deploy**: Documentation generation and packaging.
9. **Release**: Publish release assets and create the GitLab release.

**Note:** The build, package, and distro-lifecycle stages require `make` to be available on the system. The CI/CD 
pipeline automatically installs `make` in all distro-specific jobs.

---

## Stages and Jobs

### 1. Dependencies (`dependencies`)

* **`setup-dependencies`**:
    * **Purpose**: Prepares the build environment.
    * **Actions**:
        * Installs system dependencies (Python 3.12, GTK3, WebKit2GTK, nmap, lynis).
        * Creates a Python virtual environment (`.venv`).
        * Installs Python requirements (`pywebview`, `pyinstaller`, `pytest`, `flake8`, `black`, `pylint`).
        * Verifies installation integrity with `pip check`.
    * **Artifacts**: The `.venv/` directory is cached and passed as an artifact to subsequent jobs.
    * **Caching**: Uses content-based caching with fallback keys for optimal performance.

### 2. Lint (`lint`)

This stage ensures the code follows established style guidelines. All jobs in this stage are **informational only** and
will always succeed regardless of linting results. This is achieved through `allow_failure: true` and `|| true` on all
lint commands. Jobs run in parallel using the `needs` keyword for dependency management.

* **`flake8-lint`**: Checks for PEP 8 compliance with detailed error formatting. Always succeeds.
* **`black-format-check`**: Verifies that the code is formatted using Black with diff output. Always succeeds.
* **`pylint-check`**: Performs static analysis to detect errors and improve code quality. Always succeeds.

### 3. Security (`security`)

This stage performs security analysis on the codebase and dependencies. All jobs are allowed to fail but produce
artifacts for review.

* **`bandit-sast`**: Runs Bandit static application security testing to identify common security issues in Python code.
    * Outputs: `bandit-report.json`, `bandit-report.txt`
    * Integrates with GitLab SAST reporting.
* **`safety-dependency-check`**: Checks installed dependencies against known vulnerability databases.
    * Outputs: `safety-report.json`, `requirements-freeze.txt`
* **`pip-audit`**: Uses pip-audit for additional vulnerability detection in Python packages.
    * Outputs: `pip-audit-report.json`

### 4. Test (`test`)

This stage runs the automated test suite, which is split into several jobs to provide better visibility into which
module or feature fails. All jobs must pass for the pipeline to succeed. Coverage is also monitored to ensure high code
quality.

Each split test job publishes its own JUnit test report and a coverage data fragment (`.coverage.$CI_JOB_NAME`).

* **`test-network`**: Runs unit and integration tests for the network module (`tests/network/`).
    * Unit tests: `test_scan_analysis.py` (XML parsing, vulnerability evaluation, JSON export)
    * Unit tests: `test_nmap_scanner.py` (NmapScanner class, depth levels, command generation)
    * Integration tests: `test_network_integration.py` (end-to-end scan flow)
* **`test-system`**: Runs unit and integration tests for the system module (`tests/system/`).
    * Unit tests: `test_lynis.py` (LynisLogParser, LynisReportParser, LynisAnalyzer, LynisInterface,
      LynisReportGenerator)
    * Integration tests: `test_system_integration.py` (audit-to-report flow)
* **`test-gui`**: Runs unit and integration tests for the GUI module (`tests/gui/`).
    * Unit tests: `test_scan_api.py` (ScanAPI class, helper functions, progress notifications)
    * Integration tests: `test_integration_gui.py` (API initialization, scan listing)
* **`test-security`**: Verifies privilege escalation logic and asset integrity (`tests/security/`).
    * `test_integrity.py`: Verifies GUI assets exist (HTML, CSS, JS, logo)
    * `test_privileges.py`: Tests root privilege escalation via pkexec/sudo
* **`test-core`**: Runs tests for core utilities and the main entry point (`tests/test_*.py`), including logging
  configuration, application bootstrapping, and conftest helper functions.
* **`test-exporters`**: Runs unit tests for the exporters module (`tests/exporters/`).
    * Unit tests: `test_export_manager.py` (checks PDF/HTML/JSON export logic, score computation, stats building)
* **`test-coverage`**: Aggregates coverage data from split test jobs to generate a consolidated coverage report.
    * Downloads artifacts from test jobs through `needs` and combines `.coverage.*` files.
    * Generates a single `coverage.xml` (Cobertura) for GitLab coverage reporting.
    * Does not rerun the full test suite, which avoids duplicate test counting in GitLab.

### 5. Build (`build`)

* **`build-pyinstaller`**:
    * **Purpose**: Compiles the Python application into a standalone executable for Linux.
    * **Dependencies**: Uses `needs` with `optional: true` to wait for the `test-coverage` aggregation result when available.
    * **Artifacts**: Compiled binary in `dist/`.
* **`build-verification`**:
    * **Purpose**: Verifies the health of the compiled PyInstaller binary.
    * **Actions**:
        * Checks for the existence of the binary in `dist/`.
        * Verifies that all required shared libraries are correctly linked using `ldd`.
        * Performs a 10-second trial run using `xvfb` to ensure the application starts without crashes.

### 6. Package (`package`)

* **`package-appimage`**:
    * **Purpose**: Packages the application as an AppImage for easier distribution across different Linux distributions.
    * **Command**: Executes `make build-appimage`.
    * **Dependencies**: Requires successful `build-pyinstaller` and `build-verification` jobs.
    * **Actions**:
        * Prepares an `AppDir` with the PyInstaller binary, desktop file, and icon.
        * Uses `appimagetool` to create a standalone AppImage.
    * **Artifacts**: AppImage files in `dist/` (e.g., `CyberDiag-x86_64.AppImage`).
    * **Triggers**: Only runs on main branch and tags.

### 7. Distro-Lifecycle (`distro-lifecycle`)

This stage verifies that the **development environment** can be prepared, the application can be launched headlessly,
and the workspace can be cleaned up on different Linux distributions using `make setup` (the same workflow as 
`make dev`). It does **not** exercise the packaged `dist/install.sh` installer.

Before running `make setup`, each distro-specific job installs the required system dependencies including **`make`**:

* **`test-install-ubuntu`**: 
    * Tests dev setup, launch, and cleanup on `ubuntu:24.04`.
    * Pre-installs: `make`, `xvfb`, Python, GTK3, WebKit2GTK4, and OpenGL libraries.
* **`test-install-fedora`**: 
    * Tests dev setup, launch, and cleanup on `fedora:41`.
    * Pre-installs: `make`, `xorg-x11-server-Xvfb`, Python, GTK3, WebKit2GTK4, and Mesa libraries.
* **`test-install-arch`**: 
    * Tests dev setup, launch, and cleanup on `archlinux:latest`.
    * Pre-installs: `make`, `xorg-server-xvfb`, Python, GTK3, WebKit2GTK, and Mesa libraries.

These jobs use `timeout` and `xvfb` to verify that the application starts correctly without actually requiring a
physical monitor.

**Failure Policy** (uses `.rules-protected-strict` template):

- On merge requests, develop branch, main branch, and tags: Jobs **must pass** (failure stops the pipeline).
- On other branches: Jobs are **allowed to fail** (failure marked as warning, pipeline continues).

### 8. Deploy (`deploy`)

* **`deploy-documentation`**:
    * **Purpose**: Generates and packages project documentation.
    * **Actions**:
        * Installs `pdoc` and generates API documentation from Python source code.
        * Collects existing PDF documentation and the `README.md`.
        * Creates a `cyberdiag-documentation.zip` archive containing all docs.
    * **Artifacts**: Documentation folder (`docs/`) and the zip archive.
    * **Triggers**: Only runs on tags.

### 9. Release (`release`)

* **`publish-release-assets`**:
    * **Purpose**: Publishes release files to the GitLab Generic Package Registry before creating the release.
    * **Execution Order**: Runs in the final `release` stage, so it starts only after all prior stages complete.
    * **Dependencies**: Downloads artifacts from `build-pyinstaller`, `package-appimage`, and `deploy-documentation`.
    * **Actions**:
        * Verifies required files exist (`dist/cyberdiag`, `dist/CyberDiag-x86_64.AppImage`, `cyberdiag-documentation.zip`).
        * Uploads files to `packages/generic/cyberdiag/$CI_COMMIT_TAG/` using `CI_JOB_TOKEN`.
    * **Published assets**:
        * `cyberdiag-linux-x86_64`
        * `CyberDiag-x86_64.AppImage`
        * `cyberdiag-documentation.zip`
    * **Triggers**: Only runs on tags.
* **`release-on-tag`**:
    * **Purpose**: Automatically creates a GitLab release when a new Git tag is pushed.
    * **Dependencies**: Uses `needs` on `publish-release-assets` to ensure files are published before release creation.
    * **Assets**: Adds links to package-registry files (binary, AppImage, documentation) with release download paths.

Release assets are intentionally served from the Package Registry (not job artifact download URLs). This avoids
release downloads expiring with CI artifact retention policies.

---

## Configuration Details

### Environment Variables

* `PYTHON_VERSION`: "3.12"
* `PIP_CACHE_DIR`: Directory for caching pip packages.
* `VENV_DIR`: Name of the virtual environment directory (".venv").
* `DEBIAN_FRONTEND`: Set to `noninteractive` to suppress interactive prompts during package installation.
* `PYTHONPATH`: Configured to include the project root and sub-modules (`network`, `system`) to ensure correct imports.
* `SECURE_LOG_LEVEL`: Log level for security scanning jobs ("info").
* `GIT_DEPTH`: Shallow clone depth for faster checkout (20).
* `FF_USE_FASTZIP`: Enables fast zip for artifacts ("true").
* `ARTIFACT_COMPRESSION_LEVEL`: Compression level for artifacts ("fast").
* `CACHE_COMPRESSION_LEVEL`: Compression level for cache ("fast").

### Utilities and Optimization

To ensure fast and reliable execution, the pipeline uses several optimizations:

* **.base-apt Template**: A common configuration for jobs that require system dependencies and environment setup.
* **.venv-activate Template**: A lightweight template for jobs that only need to activate the virtual environment and
  pull the pip cache.
* **.lint-base Template**: Common configuration for all lint jobs with `needs` dependency on setup-dependencies.
* **.test-base Template**: Common configuration for all test jobs with Xvfb setup for headless GUI testing.
* **.dist-test-base Template**: Centralizes install/launch/uninstall lifecycle verification logic for cross-distribution
  testing.
* **.rules-default Template**: Reusable rule set for standard job triggers (merge requests, tags, and branches).
* **.rules-protected-strict Template**: Reusable rule set with strict failure policy for protected branches.
* **`needs` Keyword**: Uses DAG (Directed Acyclic Graph) selectively for faster artifact-aware scheduling.
* **`optional: true`**: Allows jobs to proceed even if optional dependencies didn't run.
* **Modular Scripts**: Uses `!reference` tags to reuse script blocks across different jobs, ensuring consistency and
  easier maintenance.
* **Specific Retry Logic**: Jobs include tailored `retry` rules to handle transient network issues (e.g., repository
  sync failures) or runner timeouts.
* **Quiet Installation**: All package managers (`apt`, `dnf`, `pacman`, `pip`) use quiet flags (`-qq`, `-q`, `--quiet`)
  to reduce log overhead.
* **Minimal Dependencies**: `apt-get` uses `--no-install-recommends` to keep the build images lightweight.
* **Non-interactive Mode**: `DEBIAN_FRONTEND: noninteractive` is set globally to avoid pipeline hangs during system
  updates.

### Caching

The pipeline uses GitLab's caching mechanism with content-based keys:

* **Key Strategy**: Uses `pyproject.toml` file hash with branch prefix for cache invalidation.
* **Fallback Keys**: Falls back to `pip-main` or `pip-develop` caches when branch-specific cache is unavailable.
* **Cached Paths**:
    * Pip download cache (`.cache/pip`).
    * Python virtual environment (`.venv/`) - passed as artifact, not cached.

### Triggers

* **Merge Requests**: Stages 1-5 and 7 (Dependencies, Lint, Security, Test, Build, Distro-Lifecycle) run on all merge
  requests.
* **Develop Branch**: Stages 1-5 and 7 (Dependencies, Lint, Security, Test, Build, Distro-Lifecycle) run automatically.
* **Main Branch**: Stages 1-7 run automatically (Dependencies, Lint, Security, Test, Build, Package, Distro-Lifecycle).
* **Tags**: All 9 stages run automatically (Dependencies, Lint, Security, Test, Build, Package, Distro-Lifecycle,
  Deploy, Release).

Tag pipelines are explicitly enabled in `workflow.rules` with `if: '$CI_COMMIT_TAG'`.

---

## How to Run Locally

While the pipeline is designed for GitLab CI, you can replicate most checks locally using the provided `Makefile`.

```bash
# 1. Development environment setup
make dev

# 2. Linting (Flake8, Black, Pylint)
env PYTHONPATH=. .venv/bin/flake8 cyberdiag.py gui/ network/ system/ tests/ --count --statistics --max-line-length=120 --exclude=.venv,__pycache__
env PYTHONPATH=. .venv/bin/black --check --diff cyberdiag.py gui/ network/ system/ tests/ --exclude=.venv
env PYTHONPATH=. .venv/bin/pylint cyberdiag.py gui/*.py network/*.py system/*.py --disable=C0111,W1203,R0903,R0913

# 3. Security scanning
.venv/bin/pip install bandit safety pip-audit
env PYTHONPATH=. .venv/bin/bandit -r cyberdiag.py gui/ network/ system/
.venv/bin/pip freeze > requirements-freeze.txt
.venv/bin/safety check -r requirements-freeze.txt
.venv/bin/pip-audit

# 4. Testing
# Run all tests
make test

# To run specific tests manually:
# Run tests by module
env PYTHONPATH=. .venv/bin/pytest tests/network/      # All network tests
env PYTHONPATH=. .venv/bin/pytest tests/system/       # All system tests
env PYTHONPATH=. .venv/bin/pytest tests/gui/          # All GUI tests
env PYTHONPATH=. .venv/bin/pytest tests/security/     # Security & integrity tests
env PYTHONPATH=. .venv/bin/pytest tests/exporters/    # Export tests
env PYTHONPATH=. .venv/bin/pytest tests/test_*.py     # Core/utility tests

# Run specific test files
env PYTHONPATH=. .venv/bin/pytest tests/network/unit/test_scan_analysis.py   # Network analysis tests
env PYTHONPATH=. .venv/bin/pytest tests/network/unit/test_nmap_scanner.py    # Nmap scanner tests
env PYTHONPATH=. .venv/bin/pytest tests/system/unit/test_lynis.py            # Lynis interface tests
env PYTHONPATH=. .venv/bin/pytest tests/gui/unit/test_scan_api.py            # ScanAPI tests

# Run with coverage
env PYTHONPATH=. .venv/bin/pytest tests/ --cov=. --cov-report=html

# 5. Build verification
.venv/bin/python -c "import webview; print('OK')"

# 6. Running the application (automatically requests elevation)
.venv/bin/cyberdiag
```
