#!/usr/bin/env python3
"""
CyberDiag Security Scanner - Main Entry Point

CyberDiag is a comprehensive security diagnostic tool that provides:
- Network vulnerability scanning using nmap
- System security auditing using Lynis
- Interactive GUI for easy visualization of results

This module serves as the main entry point for launching the application.
It initializes logging and launches the pywebview-based graphical interface.

Example:
    Run the application with root privileges::

        $ sudo python3 cyberdiag.py

Requirements:
    - Python 3.10+
    - Root/Administrator privileges (required for nmap and Lynis)
    - nmap (for network scanning)
    - Lynis (for system auditing)

Author:
    CyberDiag Team
Version:
    1.0
"""

import os
import shutil
import sys

from gui.webview_external import launch_webview
from utils.logging_config import setup_logging, get_logger

logger = get_logger(__name__)


def _build_relaunch_command() -> list[str]:
    """Return the command used to relaunch with elevated privileges."""
    # In PyInstaller/AppImage mode, relaunch the outer AppImage when available.
    # Re-executing the mounted inner binary can fail under pkexec/sudo.
    if getattr(sys, "frozen", False):
        appimage_path = os.environ.get("APPIMAGE")
        if appimage_path and os.path.isfile(appimage_path):
            return [os.path.abspath(appimage_path)] + sys.argv[1:]
        return [os.path.abspath(sys.executable)] + sys.argv[1:]

    return [os.path.abspath(sys.executable), os.path.abspath(sys.argv[0])] + sys.argv[1:]


def _ensure_root() -> None:
    """
    Ensure the application is running with root privileges.

    This function checks if the current process has root (UID 0) privileges.
    If not, it attempts to re-execute the script with elevated privileges
    using pkexec (GUI authentication dialog) or sudo as fallback.

    The function preserves important display-related environment variables
    to ensure the GUI continues to work after privilege elevation:
    - DISPLAY, XAUTHORITY (X11)
    - WAYLAND_DISPLAY, XDG_RUNTIME_DIR (Wayland)
    - DBUS_SESSION_BUS_ADDRESS (D-Bus)

    Notes:
        - On non-POSIX systems (Windows), this function returns immediately
        - If already running as root, returns without action
        - Uses os.execv/execvp to replace the current process
        - Exits with code 1 if privilege elevation fails

    Raises:
        SystemExit: If privilege elevation fails and the script cannot continue.
    """
    if os.name != "posix" or os.geteuid() == 0:
        return

    logger.info("Privileges insufficient. Requesting root access...")

    # Environment variables to preserve for GUI applications
    env_vars_to_keep = [
        "DISPLAY",
        "XAUTHORITY",
        "WAYLAND_DISPLAY",
        "XDG_RUNTIME_DIR",
        "DBUS_SESSION_BUS_ADDRESS",
    ]

    # Build elevation command.
    # We use pkexec for a GUI popup.
    relaunch_cmd = _build_relaunch_command()

    # Check if pkexec is available
    pkexec_path = shutil.which("pkexec")

    if pkexec_path:
        cmd = [pkexec_path, "env"]
        for var in env_vars_to_keep:
            val = os.environ.get(var)
            if val:
                cmd.append(f"{var}={val}")
        cmd.extend(relaunch_cmd)

        try:
            # Re-execute the script and exit the current process
            os.execv(pkexec_path, cmd)
        except Exception as e:
            logger.error(f"pkexec failed: {e}. Falling back to sudo...")

    # Fallback to sudo if pkexec fails or is not available
    cmd = ["sudo", "env"]
    for var in env_vars_to_keep:
        val = os.environ.get(var)
        if val:
            cmd.append(f"{var}={val}")
    cmd.extend(relaunch_cmd)

    try:
        # Re-execute the script and exit the current process
        os.execvp("sudo", cmd)
    except Exception as e:
        logger.error(f"Failed to elevate privileges: {e}")
        sys.exit(1)


def main() -> None:
    """
    Initialize and launch the CyberDiag security scanner application.

    This function performs the following steps:
        1. Sets up the logging configuration for the entire application
        2. Ensures the application is running with root privileges
        3. Launches the pywebview GUI with the main application interface

    Raises:
        SystemExit: If the application is not running with root privileges
    """
    setup_logging()
    _ensure_root()
    launch_webview(window_title="CyberDiag - Analyse de Sécurité v1.0")


if __name__ == "__main__":
    main()
