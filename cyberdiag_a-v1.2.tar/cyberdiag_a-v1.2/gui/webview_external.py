"""
CyberDiag Security Scanner - Backend Interface

This module provides the Python backend for the CyberDiag security analysis tool.
It bridges the HTML/JavaScript frontend with system security scanning tools (nmap, Lynis)
using pywebview to create a native desktop application.

Main components:
- ScanAPI: Core API class exposed to JavaScript for scan operations
- Network scanning: Uses nmap for port scanning and vulnerability detection
- System scanning: Uses Lynis for Linux system auditing
- Progress tracking: Real-time updates sent to frontend during scans

Dependencies:
    - pywebview: Creates native window for web interface
    - nmap: Network scanning (external binary required)
    - Lynis: System auditing (Linux only)
"""

import ipaddress
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
from datetime import datetime
from functools import lru_cache
from pathlib import Path

import webview

# Lazy imports for heavy modules - only load when needed
_networkscan_analysis = None
_LynisInterface = None


def _get_networkscan_analysis():
    """Lazy load network scan analysis module."""
    global _networkscan_analysis
    if _networkscan_analysis is None:
        from network.networkScanAnalysis import networkscan_analysis
        _networkscan_analysis = networkscan_analysis
    return _networkscan_analysis


def _get_lynis_interface():
    """Lazy load Lynis interface module."""
    global _LynisInterface
    if _LynisInterface is None:
        from system.lynis_interface import LynisInterface
        _LynisInterface = LynisInterface
    return _LynisInterface


def _get_export_scan():
    """Lazy load export module."""
    from exporters import export_scan
    return export_scan


from utils.logging_config import get_logger

logger = get_logger(__name__)


def _get_local_network_cidr():
    """
    Detect the local network CIDR range automatically.

    Uses socket connection to external server to determine local IP,
    then assumes a /24 subnet for typical home/office networks.

    Returns:
        str: CIDR notation (e.g., '192.168.1.0/24') or '127.0.0.1' on failure
    """
    try:
        # Create a UDP socket to determine local IP (doesn't actually send data)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # Connect to an external address to find the outbound interface IP
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]

        # Parse the IP and create a /24 network
        ip_obj = ipaddress.ip_address(local_ip)
        # Get network address by applying /24 mask
        network = ipaddress.ip_network(f"{local_ip}/24", strict=False)
        logger.info(f"Detected local network: {network}")
        return str(network)
    except Exception as e:
        logger.warning(f"Could not detect local network: {e}, using localhost")
        return "127.0.0.1"


@lru_cache(maxsize=1)
def _get_project_root():
    """Cache the project root path calculation."""
    return Path(__file__).resolve().parents[1]


# Reference to main window for progress callbacks
_MAIN_WINDOW = None


def _get_window():
    """Get the active pywebview window instance."""
    if _MAIN_WINDOW is not None:
        return _MAIN_WINDOW
    try:
        if webview.windows:
            return webview.windows[0]
    except Exception:
        pass
    return None


def _notify_progress(scan_type, percent, items=0):
    """
    Send real-time progress updates to the frontend.

    Args:
        scan_type: Either 'network' or 'system'
        percent: Completion percentage (0-100)
        items: Optional count of items processed (hosts/ports)
    """
    try:
        win = _get_window()
        if not win:
            return
        pct = float(percent) if percent is not None else 0
        it = int(items) if items else 0
        win.evaluate_js(
            f"if (window.onScanProgress) window.onScanProgress('{scan_type}', {pct}, {it});"
        )
    except Exception:
        pass


def _detect_scan_type(json_file: Path):
    """Infer scan type from the first meaningful JSON token without full parsing."""
    try:
        with open(json_file, "r", encoding="utf-8") as f:
            prefix = f.read(256).lstrip()
    except OSError:
        return None

    if not prefix:
        return None
    if prefix.startswith("["):
        return "network"
    if prefix.startswith("{}"):
        return None
    if prefix.startswith("{"):
        return "system"
    return None


class ScanAPI:
    """
    Main API exposed to JavaScript frontend via pywebview.

    Provides methods for:
    - Launching network/system scans
    - Retrieving scan results
    - Managing scan history

    All methods are automatically accessible from JavaScript through pywebview.api
    """

    def __init__(self):
        self.scan_in_progress = False
        self.scan_cancelled = False
        self.last_network_scan = None
        self.last_system_scan = None
        self._active_processes = []
        self._current_scanner = None

    def cancel_scan(self):
        """
        Cancel the currently running scan.

        Terminates any active scan processes and resets scan state.
        Returns dict with 'success' boolean and 'message' string.
        """
        if not self.scan_in_progress:
            return {"success": False, "message": "Aucun scan en cours"}

        self.scan_cancelled = True

        # Stop active scanner wrapper if exists
        if self._current_scanner:
            try:
                self._current_scanner.stop()
            except Exception as e:
                logger.error(f"Error stopping scanner: {e}")

        # Terminate all active processes (legacy/fallback)
        for proc in self._active_processes[:]:
            try:
                if proc.poll() is None:  # Process still running
                    logger.info(f"Arrêt du processus de scan PID {proc.pid}")
                    proc.terminate()
                    try:
                        proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait()
            except Exception as e:
                logger.error(f"Erreur lors de l'arrêt du processus: {e}")

        self._active_processes.clear()
        self.scan_in_progress = False
        self.scan_cancelled = False

        return {"success": True, "message": "Scan annulé"}

    def get_scan_history(self):
        """
        Retrieve list of all completed scans.

        Returns:
            List of dicts with scan metadata (type, path, filename, date)
        """
        project_root = _get_project_root()
        result_dir = project_root / "results"

        scans = []

        # Emplacement unifié dans results/<scan_id>/data.json
        if result_dir.exists():
            for scan_folder in result_dir.iterdir():
                if scan_folder.is_dir():
                    json_file = scan_folder / "data.json"
                    if json_file.exists():
                        try:
                            scan_type = _detect_scan_type(json_file)
                            if scan_type is None:
                                continue

                            json_mtime = datetime.fromtimestamp(json_file.stat().st_mtime).isoformat()

                            html_file = scan_folder / "report.html"
                            pdf_file = scan_folder / "report.pdf"

                            scans.append({
                                "type": scan_type,
                                "path": str(json_file),
                                "filename": scan_folder.name,
                                "date": json_mtime,
                                "artifacts": {
                                    "html": str(html_file) if html_file.exists() else None,
                                    "pdf": str(pdf_file) if pdf_file.exists() else None,
                                    "date": json_mtime,
                                }
                            })
                        except Exception as e:
                            logger.error(f"Error reading {json_file}: {e}")

        return sorted(scans, key=lambda s: s.get("date", ""), reverse=True)

    def get_scan_data(self, scan_path):
        """
        Load scan results from JSON file.

        Args:
            scan_path: Full path to scan result JSON

        Returns:
            Parsed JSON data or None on error
        """
        try:
            with open(scan_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading {scan_path}: {e}")
            return None

    def start_network_scan(self, target=None, depth=1):
        """
        Launch network security scan using nmap.

        Scans run in background thread with real-time progress updates.
        Results are sent to frontend via window.onScanComplete callback.

        Args:
            target: IP address or CIDR range to scan. If None or 'auto',
                    automatically detects the current local network.
            depth: Scan intensity level:
                   1 = Basic (top 100 ports, fast)
                   2 = Standard (top 1000 ports + vuln scripts)
                   3 = Thorough (all ports, full NSE scripts)

        Returns:
            Dict with 'success' boolean and 'message' string
        """
        if self.scan_in_progress:
            return {"success": False, "message": "Un scan est déjà en cours"}

        # Auto-detect local network if target is None or 'auto'
        if target is None or target == 'auto':
            target = _get_local_network_cidr()
            logger.info(f"Auto-detected network target: {target}")

        self.scan_in_progress = True

        def run_scan():
            xml_file = None
            intermediate_json_file = None
            try:
                # Fix for compatibility issue with shutil.which on Windows before Python 3.12
                nmap_path = shutil.which("nmap")
                project_root = _get_project_root()
                results_dir = project_root / "results"
                results_dir.mkdir(parents=True, exist_ok=True)

                # Only simulate when nmap is not available. On Windows we
                # should still attempt to use the nmap binary if installed.
                if nmap_path is None:
                    # Simulate small scan result so UI can proceed on Windows
                    simulated = [
                        {
                            "ip": "192.168.1.1",
                            "hostname": "host-local",
                            "status": "up",
                            "OS": "unknown",
                            "ports_ouverts": [
                                {
                                    "port": "22",
                                    "protocole": "tcp",
                                    "etat": "open",
                                    "service": "ssh",
                                    "version": "unknown",
                                    "criticite": "MOYENNE",
                                    "nombre_exploits": 0,
                                }
                            ],
                            "vulnerabilities": [],
                        }
                    ]

                    export_fn = _get_export_scan()
                    export_info = export_fn("network", simulated)

                    # send results to frontend
                    simulated_json = json.dumps(simulated, ensure_ascii=False)
                    window_obj = _get_window()
                    if window_obj:
                        # Send simulated flag to frontend so it can show a clear notice
                        js_complete = (
                            "if (window.onScanComplete) { "
                            f"window.onScanComplete('network', {simulated_json}, "
                            "{simulated: true, reason: 'nmap_not_found'}); }"
                        )
                        window_obj.evaluate_js(js_complete)
                    self.last_network_scan = export_info["json"]
                    self.scan_in_progress = False
                    return

                xml_file = (
                        results_dir
                        / f'scan_temp_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xml'
                )

                _notify_progress("network", 5, 0)

                # Execute scan using NmapScanner wrapper
                from network.nmap_call import NmapScanner
                scanner = NmapScanner(target, depth)
                self._current_scanner = scanner

                def on_progress(line, percent):
                    if percent > 0:
                        _notify_progress("network", percent, 0)

                    # Update status text in UI
                    win = _get_window()
                    if win:
                        try:
                            safe_line = json.dumps(line, ensure_ascii=False)
                            win.evaluate_js(
                                f"if(document.getElementById('scan-status')) document.getElementById('scan-status').textContent = {safe_line};"
                            )
                        except Exception:
                            pass

                success = scanner.run(str(xml_file), progress_callback=on_progress)
                self._current_scanner = None

                if not success:
                    if self.scan_cancelled:
                        logger.info("Scan cancelled.")
                        return
                    raise Exception("Nmap scan failed or was interrupted.")

                _notify_progress("network", 80, 0)

                logger.info("Analyzing XML result...")
                networkscan_analysis = _get_networkscan_analysis()
                json_file = networkscan_analysis(
                    str(xml_file), output_dir=str(results_dir)
                )
                intermediate_json_file = Path(json_file)

                _notify_progress("network", 95, 0)

                # Lire le contenu du JSON
                with open(json_file, "r", encoding="utf-8") as f:
                    scan_data = json.load(f)

                logger.debug(f"Scan data loaded: {len(scan_data)} hosts")

                # Exporter dans le module centralisé
                export_fn = _get_export_scan()
                export_info = export_fn("network", scan_data)

                self.last_network_scan = export_info["json"]

                payload_json = json.dumps(scan_data, ensure_ascii=False)

                window_obj = _get_window()
                if window_obj:
                    options_dict = {
                        "simulated": False,
                        "artifacts": {
                            "html": export_info.get("html"),
                            "pdf": export_info.get("pdf"),
                            "date": export_info.get("date")
                        }
                    }
                    js_code = f"""
                        if (window.onScanComplete) {{
                            window.onScanComplete("network", {payload_json}, {json.dumps(options_dict, ensure_ascii=False)});
                        }}
                    """
                    window_obj.evaluate_js(js_code)

                logger.info(f"Network scan completed: {export_info['json']}")

            except Exception as e:
                logger.exception(f"Network scan error: {e}")

                error_msg = json.dumps(str(e), ensure_ascii=False)
                window_obj = _get_window()
                if window_obj:
                    window_obj.evaluate_js(f"""
                        if (window.onScanError) {{
                            window.onScanError("network", {error_msg});
                        }}
                    """)
            finally:
                self._current_scanner = None
                for temp_file, label in (
                        (xml_file, "temporary nmap XML"),
                        (intermediate_json_file, "intermediate network JSON"),
                ):
                    if temp_file and temp_file.exists():
                        try:
                            temp_file.unlink()
                        except OSError as cleanup_error:
                            logger.warning(f"Could not remove {label} file {temp_file}: {cleanup_error}")
                self.scan_in_progress = False

        # Launch scan in separate thread
        thread = threading.Thread(target=run_scan, daemon=True)
        thread.start()

        return {"success": True, "message": "Network scan started"}

    def start_system_scan(self, depth=1):
        """
        Launch system security audit using Lynis.

        Only works on Linux/Unix systems. Lynis performs comprehensive
        security checks including kernel config, services, permissions, etc.

        Args:
            depth: Scan intensity level:
                   1 = Basic (quick scan)
                   2 = Standard (normal audit)
                   3 = Thorough (all test groups)

        Returns:
            Dict with 'success' boolean and 'message' string
        """
        if self.scan_in_progress:
            return {"success": False, "message": "A scan is already in progress"}

        self.scan_in_progress = True

        def run_scan():
            try:
                project_root = _get_project_root()
                sys.path.insert(0, str(project_root))
                sys.path.insert(0, str(project_root / "system"))

                _notify_progress("system", 5, 0)
                if sys.platform == "win32":
                    logger.warning("Lynis n'est pas disponible sur Windows")
                    _notify_progress("system", 0, 0)
                    window_obj = _get_window()
                    if window_obj:
                        window_obj.evaluate_js("""
                            if (window.onScanError) {
                                window.onScanError(
                                    "system",
                                    "Lynis nécessite Linux ou WSL. Utilisez un système Linux pour les scans système."
                                );
                            }
                            """)
                    self.scan_in_progress = False
                    return

                if depth == 1:
                    # Basique: scan rapide, minimal (sans --quiet pour avoir les logs)
                    lynis_options = ["--quick", "--no-colors"]
                    scan_level = "Basique"
                elif depth == 2:
                    # Standard: normal scan without --quick
                    lynis_options = ["--no-colors"]
                    scan_level = "Standard"
                else:
                    # Thorough: full scan with additional tests
                    lynis_options = ["--no-colors", "--tests-from-group", "all"]
                    scan_level = "Thorough"

                logger.info(f"Starting Lynis system scan level {scan_level}...")
                _notify_progress("system", 10, 0)

                LynisInterface = _get_lynis_interface()
                lynis = LynisInterface()

                _notify_progress("system", 15, 0)

                # Check if scan was cancelled before running audit
                if self.scan_cancelled:
                    logger.info("Scan cancelled by user before Lynis audit")
                    self.scan_cancelled = False
                    self.scan_in_progress = False
                    return

                # Define progress callback to forward Lynis progress to frontend
                def lynis_progress_callback(percent, message=""):
                    """Forward Lynis progress to frontend"""
                    # Map Lynis progress (0-100) to our range (15-70)
                    # We reserve 15% for initialization and 70-100% for post-processing
                    mapped_percent = 15 + int(percent * 0.55)  # Maps 0-100 to 15-70
                    _notify_progress("system", mapped_percent, 0)

                    # Also update status text if we have a message
                    if message:
                        try:
                            window_obj = _get_window()
                            if window_obj:
                                safe_msg = message.replace("'", "\\'").replace('"', '\\"')[:100]
                                window_obj.evaluate_js(
                                    "(function(){"
                                    "var el = document.getElementById('scan-status'); "
                                    f"if(el) {{ el.textContent = '{safe_msg}'; }}"
                                    "})()"
                                )
                        except Exception:
                            pass

                logger.info(f"Lynis options: {lynis_options}")
                audit_results = lynis.run_audit(options=lynis_options, progress_callback=lynis_progress_callback)

                # Check if scan was cancelled after audit
                if self.scan_cancelled:
                    logger.info("Scan cancelled by user after Lynis audit")
                    self.scan_cancelled = False
                    self.scan_in_progress = False
                    return

                _notify_progress("system", 70, 0)

                if "error" in audit_results:
                    raise Exception(audit_results["error"])

                logger.info("Transforming results...")
                vulnerabilities_data = []

                for vuln in audit_results.get("vulnerabilities", []):
                    # Map priorities to severity expected by interface
                    priority_map = {
                        "critical": "critical",
                        "high": "high",
                        "medium": "medium",
                        "moderate": "medium",
                        "low": "low",
                    }
                    severity = priority_map.get(vuln.get("priority", "low"), "medium")

                    # Construire un titre lisible avec le test_id
                    test_id = vuln.get("test_id", "UNKNOWN")
                    description = vuln.get("description", "System issue detected")
                    title = f"[{test_id}] {description}"[:150]

                    # Build complete description
                    full_description = description
                    if vuln.get("details"):
                        full_description += f"\n\nDetails: {vuln['details']}"

                    # Solution
                    solution = (
                            vuln.get("solution", "")
                            or "Consult Lynis documentation for details"
                    )

                    vulnerabilities_data.append(
                        {
                            "type": vuln.get("type", "suggestion"),
                            "title": title,
                            "description": full_description,
                            "severity": severity,
                            "solution": solution,
                            "category": "system",
                        }
                    )

                hardening_index = audit_results.get("security_score", 0)
                if hardening_index < 60:
                    severity = "high" if hardening_index < 40 else "medium"
                    vulnerabilities_data.append(
                        {
                            "type": "warning",
                            "title": f"Indice de durcissement: {hardening_index}/100",
                            "description": (
                                "L'indice de durcissement système est de "
                                f"{hardening_index}/100, indiquant que le système nécessite "
                                "des améliorations de sécurité."
                            ),
                            "severity": severity,
                            "solution": "Appliquer les recommandations de durcissement listées ci-dessus",
                            "category": "system",
                        }
                    )

                _notify_progress("system", 85, 0)

                scan_data_for_ui = {
                    "scan_type": "system",
                    "scan_level": scan_level,
                    "timestamp": audit_results.get(
                        "timestamp", datetime.now().isoformat()
                    ),
                    "security_score": hardening_index,
                    "kernel_info": audit_results.get("kernel_info", {}),
                    "services_count": len(audit_results.get("services", [])),
                    "vulnerabilities": vulnerabilities_data,
                    "summary": {
                        "total_tests": len(
                            audit_results.get("log_analysis", {}).get("tests", [])
                        ),
                        "warnings": len(
                            audit_results.get("log_analysis", {}).get("warnings", [])
                        ),
                        "suggestions": len(
                            audit_results.get("log_analysis", {}).get("suggestions", [])
                        ),
                    },
                }

                export_fn = _get_export_scan()
                export_info = export_fn("system", scan_data_for_ui)

                self.last_system_scan = export_info["json"]

                _notify_progress("system", 95, 0)

                logger.info(f"System scan completed: {export_info['json']}")
                logger.info(f"  Security score: {hardening_index}/100")
                logger.info(f"  Vulnerabilities found: {len(vulnerabilities_data)}")

                payload_json = json.dumps(scan_data_for_ui, ensure_ascii=False)

                window_obj = _get_window()
                if window_obj:
                    options_dict = {
                        "simulated": False,
                        "artifacts": {
                            "html": export_info.get("html"),
                            "pdf": export_info.get("pdf"),
                            "date": export_info.get("date")
                        }
                    }
                    window_obj.evaluate_js(f"""
                        if (window.onScanComplete) {{
                            window.onScanComplete("system", {payload_json}, {json.dumps(options_dict, ensure_ascii=False)});
                        }}
                    """)

                _notify_progress("system", 100, 0)

            except Exception as e:
                logger.error(f"System scan error: {e}")
                import traceback

                traceback.print_exc()

                _notify_progress("system", 0, 0)
                error_msg = json.dumps(str(e), ensure_ascii=False)
                window_obj = _get_window()
                if window_obj:
                    window_obj.evaluate_js(f"""
                        if (window.onScanError) {{
                            window.onScanError("system", {error_msg});
                        }}
                    """)
            finally:
                self.scan_in_progress = False

        # Launch scan in separate thread
        thread = threading.Thread(target=run_scan, daemon=True)
        thread.start()

        return {"success": True, "message": "System scan started"}

    def get_last_network_scan(self):
        """Retrieve most recent network scan results."""
        if self.last_network_scan and os.path.exists(self.last_network_scan):
            with open(self.last_network_scan, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    def get_last_system_scan(self):
        """Retrieve most recent system audit results."""
        if self.last_system_scan and os.path.exists(self.last_system_scan):
            with open(self.last_system_scan, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    def save_file_dialog(self, source_path: str, default_filename: str = ""):
        """Opens a save dialog to export a file from source_path."""
        if not os.path.exists(source_path):
            return {"success": False, "message": "Fichier introuvable"}

        window_obj = _get_window()
        if not window_obj:
            return {"success": False, "message": "Erreur d'interface"}

        ext = os.path.splitext(source_path)[1]
        file_types = (f"Documents (*{ext})", "All files (*.*)")

        sudo_user = os.environ.get("SUDO_USER")
        if sudo_user:
            default_directory = os.path.expanduser(f"~{sudo_user}")
        else:
            default_directory = os.path.expanduser("~")

        if not os.path.isdir(default_directory):
            default_directory = "/home"

        try:
            dialog_type = webview.FileDialog.SAVE
        except Exception:
            dialog_type = 1

        result = window_obj.create_file_dialog(
            dialog_type,
            directory=default_directory,
            save_filename=default_filename or os.path.basename(source_path),
            file_types=file_types
        )

        if result and len(result) > 0:
            dest_path = result[0]
            try:
                shutil.copy2(source_path, dest_path)
                return {"success": True, "message": f"Fichier sauvegardé avec succès"}
            except Exception as e:
                logger.error(f"Error copying file: {e}")
                return {"success": False, "message": f"Erreur de copie: {e}"}
        return {"success": False, "message": "Annulé"}

    def list_scans(self, scan_type="all"):
        """Get filtered list of available scans by type ('all', 'network', or 'system')."""
        scans = {"network": [], "system": []}
        for scan in self.get_scan_history():
            kind = scan.get("type")
            if kind not in scans:
                continue
            if scan_type not in ("all", kind):
                continue

            scans[kind].append(
                {
                    "path": scan.get("path"),
                    "name": scan.get("filename") or Path(scan.get("path", "")).name,
                    "date": scan.get("date"),
                }
            )

        return scans


def _cleanup_processes(api: ScanAPI) -> None:
    """
    Terminate any running scan processes gracefully when application exits.

    This function is called when the application window is closed to ensure
    any background scan processes (nmap, lynis) are properly terminated.

    Args:
        api: The ScanAPI instance containing the list of active processes.

    Notes:
        - Attempts graceful termination first (SIGTERM)
        - Falls back to force kill (SIGKILL) after 2 second timeout
        - Clears the active processes list after cleanup
    """
    logger.info("Cleaning up active processes...")

    # Clean up managed scanner instance
    if api._current_scanner:
        try:
            logger.info("Stopping active scanner...")
            api._current_scanner.stop()
        except Exception as e:
            logger.error(f"Error stopping scanner: {e}")

    for proc in api._active_processes[:]:

        try:
            if proc.poll() is None:  # Process still running
                logger.info(f"Arrêt du processus PID {proc.pid}")
                proc.terminate()
                # Wait up to 2 seconds for graceful termination
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    # Force kill if still running
                    proc.kill()
                    proc.wait()
        except Exception as e:
            logger.error(f"Error stopping process: {e}")
    api._active_processes.clear()


def launch_webview(window_title: str = "Ma WebView") -> None:
    """
    Initialize and display the main CyberDiag application window.

    Creates a native desktop window using pywebview and loads the HTML/JS
    frontend interface. Sets up the ScanAPI bridge for Python-JavaScript
    communication and registers cleanup handlers for graceful shutdown.

    Args:
        window_title: The title displayed in the window title bar.
                     Defaults to "Ma WebView".

    Raises:
        FileNotFoundError: If the index.html frontend file is not found.

    Notes:
        - Window is automatically maximized on startup
        - Cleanup handlers ensure scan processes are terminated on exit
        - The ScanAPI instance is exposed to JavaScript as `window.pywebview.api`

    Example:
        >>> launch_webview(window_title="CyberDiag - Security Scanner v1.0")
    """
    os.environ.setdefault("GSETTINGS_BACKEND", "memory")
    os.environ.setdefault("GTK_USE_PORTAL", "0")

    default_html = Path(__file__).resolve().parent / "index.html"

    if not default_html.exists():
        raise FileNotFoundError(f"File not found: {default_html}")

    file_url = default_html.as_uri()

    # Instantiate API and create the window. We pass an API instance (not the class).
    api = ScanAPI()

    window = webview.create_window(
        title=window_title, url=file_url, resizable=True, js_api=api
    )
    window.events.closing += lambda: _cleanup_processes(api)

    def _on_start():
        try:
            global _MAIN_WINDOW
            try:
                _MAIN_WINDOW = window
            except Exception:
                pass
            window.maximize()
        except Exception:
            pass

    def _on_closing():
        """Called when window is closing."""
        _cleanup_processes(api)
        return True

    webview.start(_on_start, debug=False)
