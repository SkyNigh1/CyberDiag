document.addEventListener('DOMContentLoaded', () => {
    initButtonHoverEffects();
    initCardHoverEffects();
    initNavLinkEffects();
});

// Debounce utility for performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Initialize hover effects for buttons using event delegation
 */
function initButtonHoverEffects() {
    // Use event delegation on document body for better performance
    document.body.addEventListener('mouseenter', function (e) {
        const button = e.target.closest('.button, .button-secondary, .button-test');
        if (!button || button._gsapHoverActive) return;
        button._gsapHoverActive = true;
        gsap.to(button, {
            duration: 0.3,
            scale: 1.03,
            y: -2,
            ease: "power2.out"
        });
    }, true);

    document.body.addEventListener('mouseleave', function (e) {
        const button = e.target.closest('.button, .button-secondary, .button-test');
        if (!button || !button._gsapHoverActive) return;
        button._gsapHoverActive = false;
        gsap.to(button, {
            duration: 0.3,
            scale: 1,
            y: 0,
            ease: "power2.out"
        });
    }, true);

    document.body.addEventListener('mousedown', function (e) {
        const button = e.target.closest('.button, .button-secondary, .button-test');
        if (!button) return;
        gsap.to(button, {
            duration: 0.1,
            scale: 0.98,
            ease: "power2.out"
        });
    }, true);

    document.body.addEventListener('mouseup', function (e) {
        const button = e.target.closest('.button, .button-secondary, .button-test');
        if (!button) return;
        gsap.to(button, {
            duration: 0.2,
            scale: 1.03,
            ease: "power2.out"
        });
    }, true);
}

/**
 * Initialize hover effects for cards using event delegation
 */
function initCardHoverEffects() {
    // Event delegation for test cards
    document.body.addEventListener('mouseenter', function (e) {
        const testCard = e.target.closest('.test-card');
        if (testCard) {
            gsap.to(testCard, {
                duration: 0.3,
                y: -5,
                ease: "power2.out"
            });
            return;
        }

        const vulnCard = e.target.closest('.vuln-card');
        if (vulnCard) {
            gsap.to(vulnCard, {
                duration: 0.3,
                scale: 1.03,
                ease: "power2.out"
            });
            return;
        }

        const vulnItem = e.target.closest('.vulnerability-item');
        if (vulnItem) {
            gsap.to(vulnItem, {
                duration: 0.3,
                x: 3,
                ease: "power2.out"
            });
        }
    }, true);

    document.body.addEventListener('mouseleave', function (e) {
        const testCard = e.target.closest('.test-card');
        if (testCard) {
            gsap.to(testCard, {
                duration: 0.3,
                y: 0,
                ease: "power2.out"
            });
            return;
        }

        const vulnCard = e.target.closest('.vuln-card');
        if (vulnCard) {
            gsap.to(vulnCard, {
                duration: 0.3,
                scale: 1,
                ease: "power2.out"
            });
            return;
        }

        const vulnItem = e.target.closest('.vulnerability-item');
        if (vulnItem) {
            gsap.to(vulnItem, {
                duration: 0.3,
                x: 0,
                ease: "power2.out"
            });
        }
    }, true);
}

/**
 * Initialize hover effects for navigation links using event delegation
 */
function initNavLinkEffects() {
    document.body.addEventListener('mouseenter', function (e) {
        const navLink = e.target.closest('.nav-link');
        if (!navLink) return;
        gsap.to(navLink, {
            duration: 0.3,
            y: -2,
            color: "#f8f9fa",
            ease: "power2.out"
        });
    }, true);

    document.body.addEventListener('mouseleave', function (e) {
        const navLink = e.target.closest('.nav-link');
        if (!navLink) return;
        gsap.to(navLink, {
            duration: 0.3,
            y: 0,
            color: "rgba(255, 255, 255, 0.7)",
            ease: "power2.out"
        });
    }, true);
}

/**
 * Animate background blob elements (optimized - only animates visible blobs)
 */
function animateBackgroundBlobs() {
    const blobs = document.querySelectorAll('.background-blob');

    // Use CSS animations instead of GSAP for better performance on background elements
    blobs.forEach((blob, index) => {
        // Only animate if blob is visible
        const rect = blob.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) return;

        gsap.to(blob, {
            duration: 8 + index * 2,
            x: '+=50',
            y: '+=30',
            rotation: '+=15',
            ease: "sine.inOut",
            yoyo: true,
            repeat: -1
        });
        gsap.to(blob, {
            duration: 6 + index * 1.5,
            scale: 1.2,
            ease: "sine.inOut",
            yoyo: true,
            repeat: -1
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Delay blob animation to not interfere with initial page load
    setTimeout(() => {
        animateBackgroundBlobs();
    }, 1500);
});

/**
 * Reinitialize interaction effects after page change
 * With event delegation, we don't need to re-attach listeners
 */
function reinitializeInteractions() {
    // Event delegation handles new elements automatically
    // No action needed
}

if (typeof window !== 'undefined') {
    window.reinitializeInteractions = reinitializeInteractions;
}
