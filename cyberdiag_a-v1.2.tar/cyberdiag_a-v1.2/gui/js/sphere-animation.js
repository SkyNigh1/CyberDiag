/** @type {THREE.Scene|null} */
let sphereScene = null;
/** @type {THREE.PerspectiveCamera|null} */
let sphereCamera = null;
/** @type {THREE.WebGLRenderer|null} */
let sphereRenderer = null;
/** @type {THREE.Points|null} */
let sphereParticles = null;
/** @type {number|null} */
let sphereAnimationId = null;
/** @type {Float32Array|null} */
let particlePositions = null;
/** @type {Float32Array|null} */
let originalPositions = null;
/** @type {boolean} */
let sphereAnimationPaused = false;

/**
 * Check if sphere animation is visible
 * @returns {boolean}
 */
function isSphereVisible() {
    const container = document.getElementById('earth-canvas-container');
    if (!container) return false;
    const rect = container.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 &&
        container.offsetParent !== null &&
        getComputedStyle(container).visibility !== 'hidden';
}

/**
 * Get the appropriate size for the sphere animation based on container
 * @returns {{width: number, height: number}}
 */
function getSphereSize() {
    const container = document.getElementById('earth-canvas-container');
    if (!container) return {width: 560, height: 560};

    // Get container size or use default
    const rect = container.getBoundingClientRect();
    const size = Math.min(rect.width || 560, rect.height || 560, 560);

    // For small screens, use a smaller size
    const windowWidth = window.innerWidth;
    if (windowWidth <= 768) {
        return {width: Math.min(size, 360), height: Math.min(size, 360)};
    }

    return {width: size, height: size};
}

/**
 * Handle window resize for sphere animation
 */
function handleSphereResize() {
    if (!sphereRenderer || !sphereCamera) return;

    const {width, height} = getSphereSize();
    const container = document.getElementById('earth-canvas-container');

    if (container) {
        container.style.width = `${width}px`;
        container.style.height = `${height}px`;
    }

    sphereRenderer.setSize(width, height);
    sphereCamera.aspect = width / height;
    sphereCamera.updateProjectionMatrix();
}

/**
 * Initialize Three.js particle sphere animation
 */
function initSphereAnimation() {
    const container = document.getElementById('earth-canvas-container');
    const canvas = document.getElementById('earth-canvas');

    if (!container || !canvas || typeof THREE === 'undefined') {
        console.warn('Three.js not loaded or canvas not found');
        return;
    }

    const {width, height} = getSphereSize();

    sphereScene = new THREE.Scene();
    sphereCamera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    sphereCamera.position.z = 200;

    // Use device pixel ratio for crisp rendering, but cap it for performance
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);

    sphereRenderer = new THREE.WebGLRenderer({
        canvas: canvas,
        alpha: true,
        antialias: pixelRatio <= 1,  // Disable antialiasing on high DPI for performance
        powerPreference: 'high-performance'
    });
    sphereRenderer.setPixelRatio(pixelRatio);
    sphereRenderer.setSize(width, height);
    sphereRenderer.setClearColor(0x000000, 0);

    // Listen for window resize
    window.addEventListener('resize', handleSphereResize);

    const particlesGeometry = new THREE.BufferGeometry();
    // Reduced particle count for better performance (from 8000 to 4000)
    const particlesCount = 4000;
    const posArray = new Float32Array(particlesCount * 3);
    const colorArray = new Float32Array(particlesCount * 3);

    const radius = 110;
    originalPositions = new Float32Array(particlesCount * 3);

    for (let i = 0; i < particlesCount; i++) {
        const phi = Math.acos(-1 + (2 * i) / particlesCount);
        const theta = Math.sqrt(particlesCount * Math.PI) * phi;

        const x = radius * Math.cos(theta) * Math.sin(phi);
        const y = radius * Math.sin(theta) * Math.sin(phi);
        const z = radius * Math.cos(phi);

        posArray[i * 3] = x;
        posArray[i * 3 + 1] = y;
        posArray[i * 3 + 2] = z;

        originalPositions[i * 3] = x;
        originalPositions[i * 3 + 1] = y;
        originalPositions[i * 3 + 2] = z;

        const colorPos = (phi / Math.PI);
        const shade = 0.95 - colorPos * 0.15;
        colorArray[i * 3] = shade;
        colorArray[i * 3 + 1] = shade;
        colorArray[i * 3 + 2] = shade;
    }

    particlePositions = posArray;
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    particlesGeometry.setAttribute('color', new THREE.BufferAttribute(colorArray, 3));

    const particlesMaterial = new THREE.PointsMaterial({
        size: 2.6,
        vertexColors: true,
        transparent: true,
        opacity: 0.85,
        sizeAttenuation: true,
        blending: THREE.AdditiveBlending
    });

    sphereParticles = new THREE.Points(particlesGeometry, particlesMaterial);
    sphereScene.add(sphereParticles);

    const light = new THREE.PointLight(0xf8f9fa, 1.5, 400);
    light.position.set(100, 0, 100);
    sphereScene.add(light);
    const ambientLight = new THREE.AmbientLight(0xf8f9fa, 0.5);
    sphereScene.add(ambientLight);

    let time = 0;
    let lastFrameTime = 0;
    const targetFPS = 30;
    const frameInterval = 1000 / targetFPS;

    function animateSphere(currentTime) {
        sphereAnimationId = requestAnimationFrame(animateSphere);

        // Skip frames to maintain target FPS
        if (currentTime - lastFrameTime < frameInterval) return;
        lastFrameTime = currentTime;

        // Pause animation when not visible
        if (sphereAnimationPaused || !isSphereVisible()) {
            return;
        }

        time += 0.03;  // Reduced from 0.04 for smoother appearance at lower FPS

        if (sphereParticles && particlePositions && originalPositions) {
            const particleCount = particlePositions.length / 3;
            for (let i = 0; i < particleCount; i++) {
                const i3 = i * 3;

                const ox = originalPositions[i3];
                const oy = originalPositions[i3 + 1];
                const oz = originalPositions[i3 + 2];

                const length = Math.sqrt(ox * ox + oy * oy + oz * oz);
                const invLength = 1 / length;  // Cache division result
                const nx = ox * invLength;
                const ny = oy * invLength;
                const nz = oz * invLength;

                // Simplified noise calculation with fewer operations
                const noise1 = Math.sin(nx * 3 + time) * Math.cos(ny * 3 + time * 0.7);
                const noise2 = Math.cos(nz * 4 - time * 0.8) * Math.sin(nx * 2 + time * 0.5);

                const displacement = (noise1 + noise2 * 0.5) * 12;  // Simplified formula

                particlePositions[i3] = ox + nx * displacement;
                particlePositions[i3 + 1] = oy + ny * displacement;
                particlePositions[i3 + 2] = oz + nz * displacement;
            }

            sphereParticles.geometry.attributes.position.needsUpdate = true;

            sphereParticles.rotation.y += 0.006;  // Slightly reduced
            sphereParticles.rotation.x += 0.002;
        }

        if (sphereRenderer && sphereScene && sphereCamera) {
            sphereRenderer.render(sphereScene, sphereCamera);
        }
    }

    animateSphere(0);
}

/**
 * Stop and cleanup sphere animation
 */
function stopSphereAnimation() {
    // Remove resize listener
    window.removeEventListener('resize', handleSphereResize);

    if (sphereAnimationId) {
        cancelAnimationFrame(sphereAnimationId);
        sphereAnimationId = null;
    }

    if (sphereRenderer) {
        sphereRenderer.dispose();
        sphereRenderer = null;
    }

    if (sphereParticles) {
        sphereParticles.geometry.dispose();
        sphereParticles.material.dispose();
        sphereParticles = null;
    }

    sphereScene = null;
    sphereCamera = null;
    particlePositions = null;
    originalPositions = null;
    sphereAnimationPaused = false;
}

/**
 * Pause sphere animation to save CPU
 */
function pauseSphereAnimation() {
    sphereAnimationPaused = true;
}

/**
 * Resume sphere animation
 */
function resumeSphereAnimation() {
    sphereAnimationPaused = false;
}
