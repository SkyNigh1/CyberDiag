/**
 * @param {string} scanLevel - Scan depth level
 * @param {number} maturityScore - Security maturity score
 */
function showResults(scanLevel, maturityScore) {
    console.log('[showResults] Appelé avec:', {scanLevel, maturityScore});
    console.log('[showResults] Variables globales:', {
        currentScanData: window.currentScanData,
        currentScanType: window.currentScanType,
        currentScanSimulated: window.currentScanSimulated
    });

    showPage('results', true);

    let vulnerabilities = [];
    let usedSimulated = false;

    if (window.currentScanData && window.currentScanType === 'network') {
        usedSimulated = !!window.currentScanSimulated;
        console.log("[showResults] Utilisation des données du scan réseau (simulé=", usedSimulated, ")");
        console.log("[showResults] Données brutes à parser:", window.currentScanData);
        vulnerabilities = parseNetworkScanData(window.currentScanData);
        console.log("[showResults] Vulnérabilités parsées:", vulnerabilities.length);
    } else if (window.currentScanData && window.currentScanType === 'system') {
        usedSimulated = !!window.currentScanSimulated;
        console.log("[showResults] Utilisation des données du scan système (simulé=", usedSimulated, ")");
        console.log("[showResults] Données brutes à parser:", window.currentScanData);
        vulnerabilities = parseSystemScanData(window.currentScanData);
        console.log("[showResults] Vulnérabilités parsées:", vulnerabilities.length);
    } else {
        console.log("[showResults] Utilisation des données simulées (pas de données Python)");
        // Generate mock data based on scan level
        vulnerabilities = generateVulnerabilities(scanLevel, maturityScore);
        usedSimulated = true;
    }

    let securityScore;
    if (window.currentScanType === 'system' && window.currentScanData && Number.isFinite(Number(window.currentScanData.security_score))) {
        securityScore = Math.max(0, Math.min(100, Math.round(Number(window.currentScanData.security_score))));
    } else {
        securityScore = calculateSecurityScore(vulnerabilities, maturityScore);
    }

    const now = new Date();

    const counts = {
        critical: vulnerabilities.filter(v => v.severity === 'critical').length,
        high: vulnerabilities.filter(v => v.severity === 'high').length,
        medium: vulnerabilities.filter(v => v.severity === 'medium').length,
        low: vulnerabilities.filter(v => v.severity === 'low').length
    };

    displayResults({
        score: securityScore,
        vulnerabilities: vulnerabilities,
        counts: counts,
        scanDate: now.toISOString(),
        usedSimulated: usedSimulated
    });

    saveToHistory({
        date: now,
        score: securityScore,
        level: getSecurityLevelName(securityScore),
        scanLevel: scanLevel,
        vulnerabilities: counts
    });
}

/**
 * @param {Object} data - Results data
 * @param {number} data.score - Security score
 * @param {Array} data.vulnerabilities - Vulnerability list
 * @param {Object} data.counts - Vulnerability counts by severity
 * @param {string} data.scanDate - Scan date
 * @param {boolean} data.usedSimulated - Whether simulated data was used
 */
function displayResults(data) {
    console.log('[Results] displayResults called with:', data);
    const {score, vulnerabilities, counts, scanDate, usedSimulated = false} = data;

    console.log('[Results] Score to display:', score);
    console.log('[Results] Counts:', counts);

    // Réinitialiser les styles de tous les éléments de la page résultats
    const elementsToReset = document.querySelectorAll('#page-results .results-container, #page-results .results-header, #page-results .security-score, #page-results .vuln-card, #page-results .vulnerabilities-list, #page-results .results-actions');
    elementsToReset.forEach(el => {
        if (el) {
            gsap.set(el, {clearProps: 'all'});
            el.style.opacity = '1';
            el.style.transform = 'none';
        }
    });

    animateScore(score);

    const date = new Date(scanDate);
    const dateElement = document.getElementById('scan-date');
    if (dateElement) {
        dateElement.textContent = date.toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        console.log('[Results] Date set:', dateElement.textContent);
    }

    const securityLevel = getSecurityLevelName(score);
    const securityDescription = getSecurityDescription(score);

    const levelElement = document.getElementById('security-level');
    const descElement = document.getElementById('security-description');

    if (levelElement) {
        levelElement.textContent = securityLevel;
        console.log('[Results] Security level set:', securityLevel);
    }
    if (descElement) {
        descElement.textContent = securityDescription;
    }

    const criticalElement = document.getElementById('critical-count');
    const highElement = document.getElementById('high-count');
    const mediumElement = document.getElementById('medium-count');
    const lowElement = document.getElementById('low-count');

    if (criticalElement) criticalElement.textContent = counts.critical;
    if (highElement) highElement.textContent = counts.high;
    if (mediumElement) mediumElement.textContent = counts.medium;
    if (lowElement) lowElement.textContent = counts.low;

    console.log('[Results] Vulnerability counts displayed');

    displayVulnerabilities(vulnerabilities);

    // reset
    document.querySelectorAll('.vuln-card').forEach(card => card.classList.remove('active'));
    document.querySelectorAll('.vulnerability-item').forEach(item => item.style.display = 'block');

    initFilterInteraction();

    // clickable buttons only in expert mode
    if (window.userMode === 'novice') {
        document.querySelectorAll('.vuln-card').forEach(card => {
            card.style.cursor = 'default';
            card.style.pointerEvents = 'none';
            card.title = "";
        });
    }

    updateExportButtons();

    animateResultsPageEntry(score);

    if (usedSimulated) {
        const existingBanner = document.querySelector('.simulated-banner');
        if (existingBanner) {
            existingBanner.remove();
        }

        const banner = document.createElement('div');
        banner.className = 'simulated-banner';
        banner.textContent = 'Résultats simulés — nmap non trouvé sur cet appareil. Installez nmap ou testez sur Linux pour des résultats réels.';
        banner.style.background = 'rgba(245, 158, 11, 0.15)';
        banner.style.color = '#fcd34d';
        banner.style.border = '1px solid rgba(245, 158, 11, 0.35)';
        banner.style.padding = '12px';
        banner.style.borderRadius = '8px';
        banner.style.marginBottom = '12px';
        const resultsContainer = document.querySelector('.results-container');
        if (resultsContainer) resultsContainer.prepend(banner);
    }
}

/**
 * Filter display per severity
 * @param {string} severity - Severity to filter (critical, high, medium, low or 'all')
 */
function filterVulnerabilities(severity) {
    const items = document.querySelectorAll('.vulnerability-item');
    const cards = document.querySelectorAll('.vuln-card');

    cards.forEach(card => {
        card.classList.remove('active');
        // add 'active' if not 'all'
        if (severity !== 'all' && card.id === `button-${severity}`) {
            card.classList.add('active');
        }
    });

    items.forEach(item => {
        if (severity === 'all' || item.classList.contains(severity)) {
            item.style.display = 'block';
            gsap.fromTo(item, {opacity: 0, y: 10}, {opacity: 1, y: 0, duration: 0.3});
        } else {
            item.style.display = 'none';
        }
    });
}

function initFilterInteraction() {
    // block novice interaction
    if (window.userMode === 'novice') {
        console.log('[Filters] Interaction désactivée en mode novice');
        return;
    }

    const severities = ['critical', 'high', 'medium', 'low'];

    severities.forEach(sev => {
        const btn = document.getElementById(`button-${sev}`);
        if (btn) {
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);

            newBtn.addEventListener('click', () => {
                // if active -> display all
                if (newBtn.classList.contains('active')) {
                    filterVulnerabilities('all');
                } else {
                    // filter severity
                    filterVulnerabilities(sev);
                }
            });
        }
    });
}

/**
 * @param {number} score - Security score
 * @returns {string} Security level name
 */
function getSecurityLevelName(score) {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Bon";
    if (score >= 40) return "Moyen";
    if (score >= 20) return "Faible";
    return "Critique";
}

/**
 * @param {number} score - Security score
 * @returns {string} Security description
 */
function getSecurityDescription(score) {
    if (score >= 80) {
        return "Votre infrastructure est bien protégée. Continuez vos bonnes pratiques.";
    } else if (score >= 60) {
        return "Votre système est globalement sécurisé, mais quelques améliorations sont recommandées.";
    } else if (score >= 40) {
        return "Plusieurs vulnérabilités nécessitent votre attention pour améliorer votre sécurité.";
    } else if (score >= 20) {
        return "Votre système présente des failles importantes qui doivent être corrigées rapidement.";
    }
    return "Votre système présente des vulnérabilités majeures nécessitant une action immédiate.";
}

/**
 * @param {Object} scanData - Raw network scan data
 * @returns {Array} Parsed vulnerabilities
 */
function parseNetworkScanData(scanData) {
    console.log('[parseNetworkScanData] Données reçues:', scanData);
    console.log('[parseNetworkScanData] Type:', typeof scanData, 'IsArray:', Array.isArray(scanData));

    const vulnerabilities = [];

    if (!scanData || !Array.isArray(scanData)) {
        console.warn("[parseNetworkScanData] Format de données de scan invalide");
        return vulnerabilities;
    }

    console.log(`[parseNetworkScanData] Traitement de ${scanData.length} hôtes`);

    // Stocker les métadonnées du scan pour affichage
    window.scanMetadata = {
        totalHosts: scanData.length,
        totalPorts: 0,
        totalExploits: 0,
        hostsWithIssues: 0,
        hosts: [] // données brutes par hôte pour l'affichage enrichie
    };

    // Map criticality levels from Python to severity
    const criticalityMap = {
        'CRITIQUE': 'critical',
        'ELEVEE': 'high',
        'MOYENNE': 'medium',
        'FAIBLE': 'low'
    };

    scanData.forEach((host, hostIndex) => {
        console.log(`[parseNetworkScanData] Hôte ${hostIndex}:`, host);
        const hostIp = host.ip || 'IP inconnue';
        const hostname = host.hostname || hostIp;
        const hostOS = host.OS || 'OS inconnu';
        let hostHasIssues = false;

        // Stocker les données brutes de l'hôte pour l'affichage enrichie
        window.scanMetadata.hosts.push({
            ip: hostIp,
            hostname: host.hostname,
            os: hostOS,
            status: host.status,
            tcpsequence_difficulty: host.tcpsequence_difficulty,
            criticite_tcpsequence: host.criticite_tcpsequence,
            ipid_class: host.ipid_class,
            criticite_ipidsequence: host.criticite_ipidsequence,
            portsCount: (host.ports_ouverts || []).length,
            vulnsCount: (host.vulnerabilities || []).length
        });

        // Process vulnerabilities (NSE scripts)
        if (host.vulnerabilities && Array.isArray(host.vulnerabilities)) {
            console.log(`[parseNetworkScanData] ${host.vulnerabilities.length} vulnérabilités pour ${hostname}`);
            host.vulnerabilities.forEach(vuln => {
                hostHasIssues = true;
                vulnerabilities.push({
                    title: `${vuln.script || 'Vulnérabilité détectée'} sur ${hostname}`,
                    description: vuln.description || 'Aucune description disponible',
                    severity: criticalityMap[vuln.criticite] || 'medium',
                    solution: `Correction recommandée pour le script ${vuln.script}. Consultez la documentation de sécurité pour plus de détails.`,
                    host: hostIp,
                    hostname: hostname,
                    hostOS: hostOS,
                    script: vuln.script
                });
            });
        }

        // Process open ports — tous les ports (y compris FAIBLE)
        if (host.ports_ouverts && Array.isArray(host.ports_ouverts)) {
            console.log(`[parseNetworkScanData] ${host.ports_ouverts.length} ports ouverts pour ${hostname}`);
            window.scanMetadata.totalPorts += host.ports_ouverts.length;

            host.ports_ouverts.forEach(port => {
                if (port.nombre_exploits > 0) {
                    window.scanMetadata.totalExploits += port.nombre_exploits;
                }

                const exploitInfo = port.nombre_exploits > 0
                    ? ` ${port.nombre_exploits} exploit(s) connu(s).`
                    : '';

                if (port.criticite !== 'FAIBLE') {
                    hostHasIssues = true;
                }

                vulnerabilities.push({
                    title: `Port ${port.port}/${port.protocole} ouvert sur ${hostname}`,
                    description: `Service ${port.service} (${port.version || 'version inconnue'}) en état ${port.etat}.${exploitInfo}`,
                    severity: criticalityMap[port.criticite] || 'medium',
                    solution: `Vérifiez si le service ${port.service} sur le port ${port.port} est nécessaire. Si non, fermez-le. Sinon, assurez-vous qu'il est à jour et correctement configuré.`,
                    host: hostIp,
                    hostname: hostname,
                    hostOS: hostOS,
                    port: port.port,
                    service: port.service,
                    version: port.version || null,
                    nombre_exploits: port.nombre_exploits || 0,
                    exploits_details: port.exploits_details || []
                });
            });
        }

        // Process TCP sequence predictability — toujours inclure pour info
        if (host.tcpsequence_difficulty) {
            const tcpSeverity = criticalityMap[host.criticite_tcpsequence] || 'low';
            if (tcpSeverity !== 'low') hostHasIssues = true;
            vulnerabilities.push({
                title: `Séquence TCP : ${host.tcpsequence_difficulty}`,
                description: `La difficulté de prédiction de séquence TCP est « ${host.tcpsequence_difficulty} ». ${tcpSeverity === 'low' ? 'Niveau acceptable.' : 'Ce niveau peut faciliter les attaques de type spoofing.'}`,
                severity: tcpSeverity,
                solution: tcpSeverity === 'low' ? "Aucune action requise. La séquence TCP est suffisamment aléatoire." : "Activez la randomisation des séquences TCP dans les paramètres du noyau système.",
                host: hostIp,
                hostname: hostname,
                hostOS: hostOS,
                type: 'tcp_sequence'
            });
        }

        // Process IPID sequence predictability — toujours inclure pour info
        if (host.ipid_class) {
            const ipidSeverity = criticalityMap[host.criticite_ipidsequence] || 'low';
            if (ipidSeverity !== 'low') hostHasIssues = true;
            vulnerabilities.push({
                title: `Séquence IPID : ${host.ipid_class}`,
                description: `La classe de séquence IPID est « ${host.ipid_class} ». ${ipidSeverity === 'low' ? 'Niveau acceptable.' : 'Ce niveau peut permettre le scan furtif ou le spoofing.'}`,
                severity: ipidSeverity,
                solution: ipidSeverity === 'low' ? "Aucune action requise. La séquence IPID est suffisamment sécurisée." : "Configurez le système pour utiliser des IPID randomisés.",
                host: hostIp,
                hostname: hostname,
                hostOS: hostOS,
                type: 'ipid_sequence'
            });
        }

        if (hostHasIssues) window.scanMetadata.hostsWithIssues++;
    });

    console.log(`${vulnerabilities.length} vulnérabilités extraites des données de scan`);
    return vulnerabilities;
}

/**
 * @param {number} securityScore - Security score for animation
 */
function animateResultsPageEntry(securityScore) {
    // Réinitialiser tous les styles GSAP potentiellement modifiés par des sessions précédentes
    const resultsContainer = document.querySelector('.results-container');
    if (resultsContainer) {
        gsap.set(resultsContainer, {clearProps: 'all'});
        resultsContainer.style.opacity = '1';
    }

    const timeline = gsap.timeline({
        onComplete: () => {
            // Reinitialize interactions after animation
            if (typeof reinitializeInteractions === 'function') {
                reinitializeInteractions();
            }
        }
    });

    // Background blobs
    const blobs = document.querySelectorAll('#page-results .background-blob');
    gsap.set(blobs, {scale: 0, opacity: 0});
    timeline.to(blobs, {
        duration: 0.8,
        scale: 1,
        opacity: 1,
        ease: "power2.out",
        stagger: 0.1
    }, 0);

    // Header
    const header = document.querySelector('.results-header');
    gsap.set(header, {opacity: 0, y: -30});
    timeline.to(header, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.2);

    // Score circle with simplified animation
    const scoreCircle = document.querySelector('.security-score');
    gsap.set(scoreCircle, {scale: 0.8, opacity: 0});
    timeline.to(scoreCircle, {
        duration: 0.8,
        scale: 1,
        opacity: 1,
        ease: "back.out(1.2)"
    }, 0.4);

    // Vulnerability cards
    const vulnCards = document.querySelectorAll('.vuln-card');
    gsap.set(vulnCards, {opacity: 0, y: 30});
    timeline.to(vulnCards, {
        duration: 0.5,
        opacity: 1,
        y: 0,
        stagger: 0.08,
        ease: "power2.out"
    }, 0.6);

    // Animate vulnerability counters
    vulnCards.forEach((card, index) => {
        const counter = card.querySelector('.vuln-count');
        const finalValue = parseInt(counter.textContent);
        counter.textContent = '0';

        timeline.to({value: 0}, {
            duration: 0.8,
            value: finalValue,
            ease: "power2.out",
            onUpdate: function () {
                counter.textContent = Math.floor(this.targets()[0].value);
            }
        }, 0.8 + (index * 0.05));
    });

    // Vulnerability list
    const vulnList = document.querySelectorAll('.vulnerability-item');
    gsap.set(vulnList, {opacity: 0, x: -30});
    timeline.to(vulnList, {
        duration: 0.4,
        opacity: 1,
        x: 0,
        stagger: 0.05,
        ease: "power2.out"
    }, 1);

    // Action button
    const actionButton = document.querySelector('.results-actions');
    gsap.set(actionButton, {opacity: 0, y: 20});
    timeline.to(actionButton, {
        duration: 0.5,
        opacity: 1,
        y: 0,
        ease: "power2.out",
        onComplete: () => {
            // Force opacity to 1 after animation to prevent visibility issues
            if (actionButton) actionButton.style.opacity = '1';
        }
    }, 1.2);

    // Ensure all elements are visible after timeline completes
    timeline.eventCallback('onComplete', () => {
        document.querySelectorAll('#page-results .background-blob, .results-header, .security-score, .vuln-card, .vulnerability-item, .results-actions').forEach(el => {
            if (el) el.style.opacity = '1';
        });
    });
}

/**
 * @param {string} scanLevel - Scan depth level
 * @param {number} maturityScore - Security maturity score
 * @returns {Array} Generated vulnerabilities
 */
function generateVulnerabilities(scanLevel, maturityScore) {
    const allVulnerabilities = [
        {
            title: "Ports réseau non sécurisés détectés",
            description: "Plusieurs ports sensibles (21, 23, 445) sont ouverts et accessibles depuis l'extérieur, augmentant la surface d'attaque.",
            severity: "critical",
            solution: "Fermez les ports non utilisés et configurez un pare-feu pour restreindre l'accès aux ports sensibles uniquement aux adresses IP autorisées."
        },
        {
            title: "Certificats SSL expirés ou non valides",
            description: "Certains services utilisent des certificats SSL expirés ou auto-signés, compromettant la sécurité des communications.",
            severity: "high",
            solution: "Renouvelez immédiatement vos certificats SSL auprès d'une autorité de certification reconnue et configurez des alertes de renouvellement automatique."
        },
        {
            title: "Versions obsolètes de logiciels détectées",
            description: "Des logiciels critiques (serveur web, base de données) utilisent des versions anciennes contenant des vulnérabilités connues.",
            severity: "high",
            solution: "Planifiez une mise à jour vers les versions les plus récentes et stable. Mettez en place un processus de mise à jour régulier."
        },
        {
            title: "Authentification faible sur services critiques",
            description: "Certains services n'utilisent pas d'authentification multi-facteurs et acceptent des mots de passe faibles.",
            severity: "critical",
            solution: "Activez l'authentification multi-facteurs (MFA) sur tous les services critiques et imposez une politique de mots de passe robuste (12+ caractères, complexité)."
        },
        {
            title: "Permissions excessives sur fichiers système",
            description: "De nombreux fichiers système ont des permissions trop permissives, permettant à des utilisateurs non autorisés de les modifier.",
            severity: "medium",
            solution: "Révisez et restreignez les permissions des fichiers sensibles selon le principe du moindre privilège. Auditez régulièrement les accès."
        },
        {
            title: "Absence de système de détection d'intrusion",
            description: "Aucun IDS/IPS n'est configuré pour surveiller et alerter sur les activités suspectes.",
            severity: "medium",
            solution: "Déployez un système de détection d'intrusion (IDS) comme Snort ou Suricata, et configurez des règles adaptées à votre environnement."
        },
        {
            title: "Sauvegardes non chiffrées ou inexistantes",
            description: "Les sauvegardes ne sont pas chiffrées ou sont stockées au même emplacement que les données sources.",
            severity: "high",
            solution: "Mettez en place une stratégie de sauvegarde 3-2-1 avec chiffrement AES-256. Testez régulièrement la restauration des sauvegardes."
        },
        {
            title: "Journalisation insuffisante des événements",
            description: "Les logs système ne capturent pas suffisamment d'informations pour une analyse forensique efficace.",
            severity: "medium",
            solution: "Configurez une journalisation complète des événements de sécurité et centralisez les logs avec un SIEM. Définissez une politique de rétention."
        },
        {
            title: "Connexions non chiffrées détectées",
            description: "Certains services transmettent des données sensibles en clair (HTTP, FTP, Telnet).",
            severity: "high",
            solution: "Migrez tous les services vers leurs équivalents sécurisés (HTTPS, SFTP, SSH). Désactivez les protocoles non chiffrés."
        },
        {
            title: "Configuration par défaut non modifiée",
            description: "Plusieurs services utilisent encore leurs identifiants et configurations par défaut.",
            severity: "critical",
            solution: "Changez immédiatement tous les identifiants par défaut et personnalisez les configurations selon les bonnes pratiques de sécurité."
        },
        {
            title: "Absence de segmentation réseau",
            description: "Le réseau n'est pas segmenté, tous les systèmes peuvent communiquer librement.",
            severity: "medium",
            solution: "Implémentez une segmentation réseau avec des VLANs pour isoler les systèmes critiques et limiter la propagation d'attaques."
        },
        {
            title: "Mises à jour de sécurité manquantes",
            description: "Des correctifs de sécurité critiques n'ont pas été appliqués depuis plusieurs mois.",
            severity: "high",
            solution: "Appliquez immédiatement les mises à jour de sécurité critiques et configurez des mises à jour automatiques pour les correctifs de sécurité."
        },
        {
            title: "Absence de politique de mot de passe",
            description: "Aucune exigence de complexité ou d'expiration n'est imposée pour les mots de passe.",
            severity: "medium",
            solution: "Définissez et appliquez une politique de mots de passe stricte : minimum 12 caractères, complexité, expiration tous les 90 jours."
        },
        {
            title: "Services inutiles en fonctionnement",
            description: "De nombreux services non essentiels sont actifs, augmentant la surface d'attaque.",
            severity: "low",
            solution: "Identifiez et désactivez tous les services non nécessaires. Suivez le principe de minimisation des services."
        },
        {
            title: "Protection anti-malware insuffisante",
            description: "L'antivirus n'est pas à jour ou absent sur certains postes de travail.",
            severity: "medium",
            solution: "Déployez une solution anti-malware moderne avec protection en temps réel sur tous les postes. Activez les mises à jour automatiques."
        }
    ];

    // Select vulnerabilities based on scan level and maturity
    let numVulnerabilities = 15;
    if (scanLevel === 'Basique') numVulnerabilities = 6;
    else if (scanLevel === 'Standard') numVulnerabilities = 10;

    // Adjust based on maturity score
    const maturityFactor = 1 - (maturityScore / 100);
    numVulnerabilities = Math.floor(numVulnerabilities * (0.5 + maturityFactor));

    // Shuffle and select
    const shuffled = [...allVulnerabilities].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, numVulnerabilities);
}

/**
 * @param {Array} vulnerabilities - Vulnerability list
 * @param {number} maturityScore - Base maturity score
 * @returns {number} Calculated security score
 */
function calculateSecurityScore(vulnerabilities, maturityScore = 50) {
    const criticalCount = vulnerabilities.filter(v => v.severity === 'critical').length;
    const highCount = vulnerabilities.filter(v => v.severity === 'high').length;
    const mediumCount = vulnerabilities.filter(v => v.severity === 'medium').length;
    const lowCount = vulnerabilities.filter(v => v.severity === 'low').length;

    // Score based on vulnerabilities (more vulnerabilities lower the score)
    let score = 100;
    score -= criticalCount * 20;
    score -= highCount * 12;
    score -= mediumCount * 6;
    score -= lowCount * 1;

    if (window.currentScanType === 'network' && window.scanMetadata) {
        const totalExploits = Number(window.scanMetadata.totalExploits || 0);
        const hostsWithIssues = Number(window.scanMetadata.hostsWithIssues || 0);
        const totalHosts = Math.max(1, Number(window.scanMetadata.totalHosts || 1));

        if (totalExploits > 0) {
            const exploitPenalty = Math.min(25, Math.round(Math.log1p(totalExploits) * 6));
            score -= exploitPenalty;
        }

        const hostRiskRatio = hostsWithIssues / totalHosts;
        score -= Math.round(hostRiskRatio * 10);
    }

    // If maturityScore is provided, factor it in
    if (maturityScore && maturityScore !== 50) {
        score = score * 0.6 + maturityScore * 0.4;
    }

    return Math.max(0, Math.min(100, Math.round(score)));
}

/**
 * @param {number} targetScore - Target score to animate to
 */
function animateScore(targetScore) {
    console.log('[Results] animateScore called with targetScore:', targetScore);

    const scoreElement = document.getElementById('security-score');
    const circle = document.getElementById('score-circle');

    // Defensive defaults
    if (!scoreElement) {
        console.error('[Results] security-score element not found!');
        return;
    }
    if (!circle) {
        console.error('[Results] score-circle element not found!');
        return;
    }

    // Ensure targetScore is a number between 0 and 100
    if (typeof targetScore !== 'number' || isNaN(targetScore)) targetScore = 0;
    targetScore = Math.max(0, Math.min(100, Math.round(targetScore)));

    // Immediately set displayed value to avoid a visible stale value
    scoreElement.textContent = 0;

    // Prepare SVG stroke values (match CSS stroke-dasharray / radius)
    const radius = 85;
    const circumference = 2 * Math.PI * radius;
    // Ensure strokeDasharray is set
    if (!circle.style.strokeDasharray) {
        circle.style.strokeDasharray = String(Math.round(circumference));
    }
    // Initialize offset to full circle
    circle.style.strokeDashoffset = String(Math.round(circumference));

    let currentScore = 0;
    const duration = 1200; // shorter, snappier animation
    const startTime = Date.now();

    if (window._scoreAnimationFrameId) {
        cancelAnimationFrame(window._scoreAnimationFrameId);
        window._scoreAnimationFrameId = null;
    }

    function animate() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);

        currentScore = Math.floor(targetScore * progress);
        scoreElement.textContent = currentScore;

        const offset = circumference - (currentScore / 100) * circumference;
        circle.style.strokeDashoffset = String(Math.round(offset));

        if (progress < 1) {
            window._scoreAnimationFrameId = requestAnimationFrame(animate);
        } else {
            // Ensure final values are exact
            scoreElement.textContent = targetScore;
            circle.style.strokeDashoffset = String(Math.round(circumference - (targetScore / 100) * circumference));
            window._scoreAnimationFrameId = null;
            console.log('[Results] Score animation complete:', targetScore);
        }
    }

    // Add SVG gradient if needed (keeps original behaviour)
    if (!document.querySelector('#scoreGradient')) {
        const svg = document.querySelector('.score-svg');
        if (svg) {
            const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
            const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
            gradient.id = 'scoreGradient';
            gradient.innerHTML = `
                <stop offset="0%" stop-color="#f5f5f5"/>
                <stop offset="100%" stop-color="#585858ff"/>
            `;
            defs.appendChild(gradient);
            svg.insertBefore(defs, svg.firstChild);
        }
    }

    animate();
}

/**
 * Configure la visibilité et l'action des boutons d'export
 */
function updateExportButtons() {
    const btnHtml = document.getElementById('btn-export-html');
    const btnPdf = document.getElementById('btn-export-pdf');

    if (btnHtml && btnPdf) {
        if (window.currentArtifacts) {
            const scanDateTimeRaw = window.currentArtifacts.date
                ? String(window.currentArtifacts.date)
                : new Date().toISOString();
            const [datePart, timePartRaw = '00:00:00'] = scanDateTimeRaw.split('T');
            const timePart = timePartRaw.split('.')[0].replace(/:/g, '-');
            const dateTimePart = `${datePart}_${timePart}`;
            const defaultHtmlName = `rapport_scan_${window.currentScanType}_${dateTimePart}.html`;
            const defaultPdfName = `rapport_scan_${window.currentScanType}_${dateTimePart}.pdf`;

            if (window.currentArtifacts.html) {
                btnHtml.style.display = 'inline-flex';
                btnHtml.onclick = () => {
                    if (window.pywebview && window.pywebview.api) {
                        window.pywebview.api.save_file_dialog(window.currentArtifacts.html, defaultHtmlName)
                            .then(res => console.log('Export HTML:', res));
                    }
                };
            } else {
                btnHtml.style.display = 'none';
            }

            if (window.currentArtifacts.pdf) {
                btnPdf.style.display = 'inline-flex';
                btnPdf.onclick = () => {
                    if (window.pywebview && window.pywebview.api) {
                        window.pywebview.api.save_file_dialog(window.currentArtifacts.pdf, defaultPdfName)
                            .then(res => console.log('Export PDF:', res));
                    }
                };
            } else {
                btnPdf.style.display = 'none';
            }
        } else {
            console.log("No artifacts found for this scan via window.currentArtifacts.");
            btnHtml.style.display = 'none';
            btnPdf.style.display = 'none';
        }
    }
}

/**
 * @param {Array} vulnerabilities - List of vulnerabilities to display
 */
function displayVulnerabilities(vulnerabilities) {
    const container = document.getElementById('vulnerabilities-list');
    container.innerHTML = '';

    // Afficher le résumé du scan si disponible
    if (window.scanMetadata && window.currentScanType === 'network') {
        const meta = window.scanMetadata;
        const summaryDiv = document.createElement('div');
        summaryDiv.className = 'scan-summary-banner';
        summaryDiv.style.cssText = `
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 12px;
            margin-bottom: 24px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
        `;

        const stats = [
            {label: 'Hôtes détectés', value: meta.totalHosts},
            {label: 'Ports ouverts', value: meta.totalPorts},
            {label: 'Exploits connus', value: meta.totalExploits, color: meta.totalExploits > 0 ? '#aeb7c6' : null},
            {label: 'Hôtes à risque', value: meta.hostsWithIssues, color: meta.hostsWithIssues > 0 ? '#aeb7c6' : null}
        ];

        stats.forEach(stat => {
            const statEl = document.createElement('div');
            statEl.style.cssText = 'text-align: center; padding: 10px;';
            statEl.innerHTML = `
                <div style="font-size: 28px; font-weight: 700; color: ${stat.color || '#fff'}; margin-bottom: 4px;">${stat.value}</div>
                <div style="font-size: 12px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 0.5px;">${stat.label}</div>
            `;
            summaryDiv.appendChild(statEl);
        });

        container.appendChild(summaryDiv);
    }

    // Vérifier le mode utilisateur
    const isNoviceMode = window.userMode === 'novice';

    if (isNoviceMode) {
        // Mode novice: afficher un résumé clair avec recommandations
        displayVulnerabilitiesNoviceMode(vulnerabilities, container);
    } else {
        // Mode expert: afficher la liste détaillée normale
        displayVulnerabilitiesExpertMode(vulnerabilities, container);
    }
}

/**
 * Affichage simplifié pour le mode novice
 */
function displayVulnerabilitiesNoviceMode(vulnerabilities, container) {
    // Compter les vulnérabilités par niveau
    const counts = {
        critical: vulnerabilities.filter(v => v.severity === 'critical').length,
        high: vulnerabilities.filter(v => v.severity === 'high').length,
        medium: vulnerabilities.filter(v => v.severity === 'medium').length,
        low: vulnerabilities.filter(v => v.severity === 'low').length
    };

    // Créer l'affichage des compteurs
    const summaryDiv = document.createElement('div');
    summaryDiv.style.display = 'grid';
    summaryDiv.style.gridTemplateColumns = 'repeat(auto-fit, minmax(250px, 1fr))';
    summaryDiv.style.gap = '20px';
    summaryDiv.style.marginBottom = '30px';

    const severityLevels = [
        {key: 'critical', label: 'Critiques', color: '#ef4444'},
        {key: 'high', label: 'Élevées', color: '#f97316'},
        {key: 'medium', label: 'Moyennes', color: '#3b82f6'},
        {key: 'low', label: 'Faibles', color: '#64748b'}
    ];

    severityLevels.forEach(level => {
        const card = document.createElement('div');
        card.style.background = 'rgba(15, 23, 42, 0.6)';
        card.style.backdropFilter = 'blur(8px)';
        card.style.border = '1px solid rgba(148, 163, 184, 0.22)';
        card.style.borderRadius = '12px';
        card.style.padding = '20px';
        card.style.textAlign = 'center';
        card.style.transition = 'all 0.25s ease';

        card.innerHTML = `
            <div style="margin-bottom: 10px;">
                <svg width="36" height="36" viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" fill="${level.color}"/>
                </svg>
            </div>
            <div style="font-size: 34px; font-weight: 700; color: ${level.color}; margin-bottom: 8px;">
                ${counts[level.key]}
            </div>
            <div style="font-size: 16px; color: rgba(255, 255, 255, 0.8); font-weight: 500;">
                Faille${counts[level.key] > 1 ? 's' : ''} ${level.label}
            </div>
        `;

        summaryDiv.appendChild(card);
    });

    container.appendChild(summaryDiv);

    // Pas de pop-up bloquant: on garde un affichage sobre dans la page

    // Section recommandations contextuelles
    const recoDiv = document.createElement('div');
    recoDiv.style.cssText = `
        background: rgba(15, 23, 42, 0.62);
        border: 1px solid rgba(148, 163, 184, 0.22);
        border-radius: 12px;
        padding: 24px;
        margin-top: 24px;
        color: rgba(255, 255, 255, 0.9);
        font-size: 14px;
        line-height: 1.8;
    `;

    let recoItems = [];
    if (counts.critical > 0) {
        recoItems.push('<span style="color: #ef4444; font-weight: 700;">Critique</span> — Des failles critiques ont été détectées. Contactez un professionnel de la cybersécurité.');
    }
    if (counts.high > 0) {
        recoItems.push('<span style="color: #f97316; font-weight: 700;">Élevé</span> — Certains services exposés présentent un risque élevé. Vérifiez qu\'ils sont nécessaires et à jour.');
    }
    if (counts.medium > 0) {
        recoItems.push('<span style="color: #3b82f6; font-weight: 700;">Moyen</span> — Des ports réseau sont ouverts sur vos appareils. Fermez ceux qui ne sont pas indispensables.');
    }
    if (counts.low > 0) {
        recoItems.push('<span style="color: #64748b; font-weight: 700;">Info</span> — Quelques points d\'information ont été relevés, sans risque immédiat.');
    }
    if (recoItems.length === 0) {
        recoItems.push('<span style="color: #22c55e; font-weight: 700;">OK</span> — Aucun problème significatif détecté. Continuez vos bonnes pratiques !');
    }

    recoDiv.innerHTML = `
        <strong style="margin-bottom: 14px; font-size: 17px; display: block; color: #fff;">
            Ce que ça signifie pour vous
        </strong>
        <ul style="list-style: none; padding: 0; margin: 0;">
            ${recoItems.map(r => `<li style="margin-bottom: 10px; padding-left: 0; line-height: 1.6;">${r}</li>`).join('')}
        </ul>
    `;
    container.appendChild(recoDiv);

    // Note mode novice
    const infoDiv = document.createElement('div');
    infoDiv.style.cssText = `
        text-align: center;
        margin-top: 16px;
        padding: 12px;
        color: rgba(255, 255, 255, 0.5);
        font-size: 12px;
    `;
    infoDiv.textContent = 'Pour voir les détails techniques complets, relancez un scan en mode expert.';
    container.appendChild(infoDiv);
}

/**
 * Afficher une alerte critique
 */
function showCriticalAlert(criticalCount) {
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.background = 'rgba(0, 0, 0, 0.8)';
    overlay.style.backdropFilter = 'blur(10px)';
    overlay.style.display = 'flex';
    overlay.style.alignItems = 'center';
    overlay.style.justifyContent = 'center';
    overlay.style.zIndex = '10000';
    overlay.style.animation = 'fadeIn 0.3s ease';

    const modal = document.createElement('div');
    modal.style.background = 'linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(245, 158, 11, 0.2))';
    modal.style.backdropFilter = 'blur(20px)';
    modal.style.border = '2px solid #ef4444';
    modal.style.borderRadius = '20px';
    modal.style.padding = '40px';
    modal.style.maxWidth = '500px';
    modal.style.textAlign = 'center';
    modal.style.boxShadow = '0 20px 60px rgba(239, 68, 68, 0.3)';
    modal.style.animation = 'scaleIn 0.3s ease';

    modal.innerHTML = `
        <div style="margin-bottom: 20px;">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/>
                <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
        </div>
        <h2 style="color: #ef4444; font-size: 28px; margin-bottom: 15px; font-weight: 700;">
            Alerte Critique
        </h2>
        <p style="color: rgba(255, 255, 255, 0.9); font-size: 18px; line-height: 1.6; margin-bottom: 25px;">
            <strong>${criticalCount}</strong> faille${criticalCount > 1 ? 's' : ''} critique${criticalCount > 1 ? 's' : ''} 
            ${criticalCount > 1 ? 'ont' : 'a'} été détectée${criticalCount > 1 ? 's' : ''} sur votre système.
        </p>
        <p style="color: rgba(255, 255, 255, 0.8); font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
            Il est <strong>fortement recommandé</strong> de contacter votre administrateur système 
            immédiatement pour corriger ces vulnérabilités.
        </p>
        <button id="close-critical-alert" style="
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: white;
            padding: 15px 40px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Space Grotesk', sans-serif;
            text-transform: uppercase;
            letter-spacing: 1px;
        ">
            Compris
        </button>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Ajouter les animations CSS si elles n'existent pas
    if (!document.getElementById('critical-alert-animations')) {
        const style = document.createElement('style');
        style.id = 'critical-alert-animations';
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            @keyframes scaleIn {
                from { transform: scale(0.8); opacity: 0; }
                to { transform: scale(1); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }

    // Fermer le modal
    document.getElementById('close-critical-alert').addEventListener('click', () => {
        overlay.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => overlay.remove(), 300);
    });

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => overlay.remove(), 300);
        }
    });
}

/**
 * Affichage détaillé pour le mode expert
 */
function displayVulnerabilitiesExpertMode(vulnerabilities, container) {
    // Group vulnerabilities by host
    const hostGroups = {};
    const otherVulns = [];

    vulnerabilities.forEach(vuln => {
        if (vuln.host) {
            if (!hostGroups[vuln.host]) {
                hostGroups[vuln.host] = {
                    ports: [],
                    otherIssues: [],
                    hostname: vuln.hostname || vuln.host,
                    hostOS: vuln.hostOS || 'OS inconnu'
                };
            }

            if (vuln.port) {
                // Open port
                hostGroups[vuln.host].ports.push(vuln);
            } else {
                // Another host vulnerability
                hostGroups[vuln.host].otherIssues.push(vuln);
            }
        } else {
            // General vulnerability (not tied to specific host)
            otherVulns.push(vuln);
        }
    });

    // Display hosts with vulnerabilities
    Object.keys(hostGroups).forEach((hostIp, hostIndex) => {
        const hostData = hostGroups[hostIp];
        const hostItem = document.createElement('div');
        hostItem.className = 'host-group';

        // Determine highest severity for this host
        const allHostVulns = [...hostData.ports, ...hostData.otherIssues];
        const severities = allHostVulns.map(v => v.severity);
        let hostSeverity = 'low';
        if (severities.includes('critical')) hostSeverity = 'critical';
        else if (severities.includes('high')) hostSeverity = 'high';
        else if (severities.includes('medium')) hostSeverity = 'medium';

        // Determine border color based on severity
        let borderColor = '#64748b';
        if (hostSeverity === 'critical') borderColor = '#ef4444';
        else if (hostSeverity === 'high') borderColor = '#f97316';
        else if (hostSeverity === 'medium') borderColor = '#3b82f6';

        // Récupérer les métadonnées de l'hôte
        const hostMeta = (window.scanMetadata && window.scanMetadata.hosts)
            ? window.scanMetadata.hosts.find(h => h.ip === hostIp)
            : null;
        const tcpDiff = hostMeta ? hostMeta.tcpsequence_difficulty : null;
        const ipidClass = hostMeta ? hostMeta.ipid_class : null;
        const tcpCrit = hostMeta ? hostMeta.criticite_tcpsequence : null;
        const ipidCrit = hostMeta ? hostMeta.criticite_ipidsequence : null;

        // Couleur du badge TCP/IPID
        function getCritColor(crit) {
            if (crit === 'CRITIQUE') return '#ef4444';
            if (crit === 'ELEVEE') return '#f97316';
            if (crit === 'MOYENNE') return '#3b82f6';
            return '#64748b';
        }

        // Compter les exploits sur cet hôte
        const hostExploits = hostData.ports.reduce((sum, p) => sum + (p.nombre_exploits || 0), 0);

        hostItem.innerHTML = `
            <div class="host-toggle" style="position: absolute; left: 15px; top: 15px; cursor: pointer; font-size: 22px; user-select: none; color: #fff;">
                <span class="host-arrow">&#9654;</span>
            </div>
            <div style="padding-left: 45px;">
                <h3 class="host-title" style="margin-bottom: 8px;">
                    ${hostData.hostname !== hostIp ? hostData.hostname + ' — ' : ''}${hostIp}
                </h3>
                <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px;">
                    <span style="background: rgba(100, 116, 139, 0.25); color: #e2e8f0; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 500;">${hostData.hostOS}</span>
                    ${hostExploits > 0 ? `<span style="background: rgba(239, 68, 68, 0.18); color: #fca5a5; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600;">${hostExploits} exploit(s)</span>` : ''}
                </div>
                <div class="host-stats" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
                    <span class="host-stat">${hostData.ports.length} port(s) ouvert(s)</span>
                    <span class="host-stat">${hostData.otherIssues.length} vulnérabilité(s)</span>
                    <span class="host-severity ${hostSeverity}">${getSeverityLabel(hostSeverity)}</span>
                </div>
            </div>
            <div class="host-details" style="display: none; overflow: visible;">
                <div class="host-info-section" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; padding: 12px; background: rgba(255,255,255,0.02); border-radius: 10px;">
                    <div style="font-size: 12px; color: rgba(255,255,255,0.7);">
                        <span style="color: rgba(255,255,255,0.4);">TCP Seq :</span> 
                        <span style="color: ${getCritColor(tcpCrit)}; font-weight: 500;">${tcpDiff || '—'}</span>
                    </div>
                    <div style="font-size: 12px; color: rgba(255,255,255,0.7);">
                        <span style="color: rgba(255,255,255,0.4);">IPID :</span> 
                        <span style="color: ${getCritColor(ipidCrit)}; font-weight: 500;">${ipidClass || '—'}</span>
                    </div>
                </div>
                <div class="host-ports"></div>
                <div class="host-exploits"></div>
                <div class="host-issues"></div>
            </div>
        `;

        hostItem.style.position = 'relative';
        hostItem.style.background = 'rgba(15, 23, 42, 0.6)';
        hostItem.style.backdropFilter = 'blur(8px)';
        hostItem.style.border = '1px solid rgba(148, 163, 184, 0.2)';
        hostItem.style.borderLeft = `3px solid ${borderColor}`;
        hostItem.style.borderRadius = '12px';
        hostItem.style.padding = '20px';
        hostItem.style.marginBottom = '20px';
        hostItem.style.cursor = 'pointer';
        hostItem.style.transition = 'all 0.3s ease';

        const arrow = hostItem.querySelector('.host-arrow');
        const details = hostItem.querySelector('.host-details');
        const toggle = hostItem.querySelector('.host-toggle');
        const portsContainer = hostItem.querySelector('.host-ports');
        const exploitsContainer = hostItem.querySelector('.host-exploits');
        const issuesContainer = hostItem.querySelector('.host-issues');

        // Section Exploits dédiée — liste chaque exploit individuellement
        const portsWithExploits = hostData.ports.filter(p => (p.nombre_exploits || 0) > 0);
        if (portsWithExploits.length > 0) {
            const exploitsTitle = document.createElement('h4');
            exploitsTitle.textContent = 'Exploits connus';
            exploitsTitle.style.cssText = 'color: rgba(255, 255, 255, 0.92); margin-bottom: 12px; font-size: 16px;';
            exploitsContainer.appendChild(exploitsTitle);

            portsWithExploits.forEach(port => {
                // En-tête du port concerné
                const portHeader = document.createElement('div');
                portHeader.style.cssText = 'margin-bottom: 8px; padding: 8px 0;';
                portHeader.innerHTML = `
                    <span style="font-weight: 600; color: #fff;">Port ${port.port}/${port.service || '?'}</span>
                    ${port.version ? `<span style="color: rgba(255,255,255,0.5); font-weight: 400; font-size: 12px; margin-left: 8px;">v${port.version}</span>` : ''}
                    <span style="color: rgba(255,255,255,0.4); font-size: 12px; margin-left: 8px;">${port.nombre_exploits} exploit${port.nombre_exploits > 1 ? 's' : ''}</span>
                `;
                exploitsContainer.appendChild(portHeader);

                // Liste détaillée des exploits
                const details = port.exploits_details || [];
                if (details.length > 0) {
                    const table = document.createElement('div');
                    table.style.cssText = 'display: flex; flex-direction: column; gap: 4px; margin-bottom: 16px;';

                    // En-tête du tableau
                    const headerRow = document.createElement('div');
                    headerRow.style.cssText = `
                        display: grid;
                        grid-template-columns: 1fr 80px 120px;
                        gap: 8px;
                        padding: 8px 12px;
                        font-size: 11px;
                        color: rgba(255,255,255,0.4);
                        text-transform: uppercase;
                        letter-spacing: 0.5px;
                    `;
                    headerRow.innerHTML = '<span>Identifiant</span><span style="text-align: center;">CVSS</span><span style="text-align: right;">Source</span>';
                    table.appendChild(headerRow);

                    details.forEach(exploit => {
                        const row = document.createElement('div');

                        // Couleur CVSS selon le score
                        let cvssColor = '#94a3b8';
                        if (exploit.cvss >= 9.0) cvssColor = '#ef4444';
                        else if (exploit.cvss >= 7.0) cvssColor = '#f97316';
                        else if (exploit.cvss >= 4.0) cvssColor = '#3b82f6';

                        row.style.cssText = `
                            display: grid;
                            grid-template-columns: 1fr 80px 120px;
                            gap: 8px;
                            padding: 8px 12px;
                            background: rgba(255, 255, 255, 0.03);
                            border: 1px solid rgba(255, 255, 255, 0.08);
                            border-radius: 8px;
                            align-items: center;
                        `;
                        row.innerHTML = `
                            <span style="font-size: 12px; color: rgba(255,255,255,0.8); font-family: monospace; word-break: break-all;">${exploit.id}</span>
                            <span style="text-align: center; font-weight: 700; font-size: 13px; color: ${cvssColor};">${exploit.cvss.toFixed(1)}</span>
                            <span style="text-align: right; font-size: 11px; color: rgba(255,255,255,0.5); text-transform: uppercase;">${exploit.type}</span>
                        `;
                        table.appendChild(row);
                    });

                    exploitsContainer.appendChild(table);
                } else {
                    // Pas de détails disponibles (ancien format de données)
                    const fallback = document.createElement('div');
                    fallback.style.cssText = `
                        background: rgba(255, 255, 255, 0.04);
                        border: 1px solid rgba(255, 255, 255, 0.08);
                        border-radius: 8px;
                        padding: 10px 12px;
                        margin-bottom: 16px;
                        font-size: 12px;
                        color: rgba(255,255,255,0.5);
                    `;
                    fallback.textContent = `${port.nombre_exploits} exploit(s) connu(s) — relancez un scan pour obtenir les détails.`;
                    exploitsContainer.appendChild(fallback);
                }
            });
        }

        // Display open ports in a simple list
        if (hostData.ports.length > 0) {
            const portsTitle = document.createElement('h4');
            portsTitle.textContent = 'Ports ouverts';
            portsTitle.style.color = 'rgba(255, 255, 255, 0.9)';
            portsTitle.style.marginBottom = '12px';
            portsTitle.style.fontSize = '16px';
            portsContainer.appendChild(portsTitle);

            const portsList = document.createElement('div');
            portsList.className = 'ports-list';
            portsList.style.display = 'grid';
            portsList.style.gridTemplateColumns = 'repeat(auto-fill, minmax(300px, 1fr))';
            portsList.style.gap = '10px';
            portsList.style.marginBottom = '20px';

            hostData.ports.forEach(port => {
                const portItem = document.createElement('div');
                portItem.className = `port-item ${port.severity}`;
                portItem.style.cssText = `
                    background: rgba(255, 255, 255, 0.05);
                    padding: 14px 16px;
                    border-radius: 10px;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    gap: 12px;
                `;

                const versionStr = port.version ? port.version : null;
                const exploitCount = port.nombre_exploits || 0;

                const portInfo = document.createElement('div');
                portInfo.style.flex = '1';
                portInfo.innerHTML = `
                    <div style="font-weight: 600; color: #fff; margin-bottom: 4px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        <span>Port ${port.port}/${port.service || '?'}</span>
                        ${versionStr ? `<span style="background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.7); padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 400;">v${versionStr}</span>` : ''}
                        ${exploitCount > 0 ? `<span style="background: rgba(239, 68, 68, 0.2); color: #ef4444; padding: 2px 8px; border-radius: 10px; font-size: 10px; font-weight: 600;">${exploitCount} exploit${exploitCount > 1 ? 's' : ''}</span>` : ''}
                    </div>
                    <div style="font-size: 12px; color: rgba(255,255,255,0.5);">
                        ${getPortDescription(port.port, port.service)}
                    </div>
                `;

                const badgesDiv = document.createElement('div');
                badgesDiv.style.cssText = 'display: flex; flex-direction: column; align-items: flex-end; gap: 4px;';

                const severityBadge = document.createElement('span');
                severityBadge.className = `port-severity ${port.severity}`;
                severityBadge.textContent = getSeverityLabel(port.severity);
                severityBadge.style.cssText = 'padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; white-space: nowrap;';
                badgesDiv.appendChild(severityBadge);

                portItem.appendChild(portInfo);
                portItem.appendChild(badgesDiv);
                portsList.appendChild(portItem);
            });

            portsContainer.appendChild(portsList);
        }

        // Display other host issues as expandable items
        if (hostData.otherIssues.length > 0) {
            const issuesTitle = document.createElement('h4');
            issuesTitle.textContent = 'Problèmes et informations détectés';
            issuesTitle.style.color = 'rgba(255, 255, 255, 0.9)';
            issuesTitle.style.marginBottom = '12px';
            issuesTitle.style.fontSize = '16px';
            issuesContainer.appendChild(issuesTitle);

            hostData.otherIssues.forEach(vuln => {
                const vulnItem = createVulnerabilityItem(vuln, details);
                issuesContainer.appendChild(vulnItem);
            });
        }

        // Toggle host details
        toggle.addEventListener('click', (e) => {
            e.stopPropagation();
            const isOpen = details.style.display !== 'none';

            if (isOpen) {
                gsap.to(details, {
                    duration: 0.3,
                    height: 0,
                    opacity: 0,
                    ease: "power2.in",
                    onComplete: () => {
                        details.style.display = 'none';
                        details.style.height = 'auto';
                    }
                });
                gsap.to(arrow, {
                    duration: 0.3,
                    rotation: 0,
                    ease: "power2.inOut"
                });
            } else {
                details.style.display = 'block';
                details.style.height = 'auto';
                const fullHeight = details.scrollHeight;
                details.style.height = '0px';
                gsap.to(details, {
                    duration: 0.4,
                    height: fullHeight,
                    opacity: 1,
                    ease: "power2.out"
                });
                gsap.to(arrow, {
                    duration: 0.3,
                    rotation: 90,
                    ease: "power2.inOut"
                });
            }
        });

        container.appendChild(hostItem);
    });

    // Display other vulnerabilities (not tied to specific hosts)
    if (otherVulns.length > 0) {
        const generalSection = document.createElement('div');
        generalSection.className = 'general-vulnerabilities';
        generalSection.style.marginTop = '30px';

        const generalTitle = document.createElement('h3');
        generalTitle.textContent = 'Vulnérabilités générales';
        generalTitle.style.color = 'rgba(255, 255, 255, 0.9)';
        generalTitle.style.marginBottom = '20px';
        generalTitle.style.fontSize = '20px';
        generalSection.appendChild(generalTitle);

        otherVulns.forEach(vuln => {
            const vulnItem = createVulnerabilityItem(vuln);
            generalSection.appendChild(vulnItem);
        });

        container.appendChild(generalSection);
    }
}

/**
 * @param {Object} vuln - Vulnerability object
 * @param {HTMLElement} parentContainer - Parent container element
 * @returns {HTMLElement} Vulnerability item element
 */
function createVulnerabilityItem(vuln, parentContainer = null) {
    const severityRiskText = {
        critical: 'Risque critique: compromission probable ou impact majeur immédiat.',
        high: 'Risque élevé: exploitation plausible avec impact important.',
        medium: 'Risque moyen: faiblesse exploitable selon le contexte.',
        low: 'Risque faible: point de vigilance à traiter progressivement.'
    };

    const contextParts = [];
    if (vuln.host) contextParts.push(`<strong>Hôte:</strong> ${vuln.host}`);
    if (vuln.hostOS) contextParts.push(`<strong>OS:</strong> ${vuln.hostOS}`);
    if (vuln.port) contextParts.push(`<strong>Port:</strong> ${vuln.port}`);
    if (vuln.service) contextParts.push(`<strong>Service:</strong> ${vuln.service}`);
    if (vuln.version) contextParts.push(`<strong>Version:</strong> ${vuln.version}`);
    if (vuln.script) contextParts.push(`<strong>Script:</strong> ${vuln.script}`);
    if (vuln.category) contextParts.push(`<strong>Catégorie:</strong> ${vuln.category}`);
    if (vuln.type) contextParts.push(`<strong>Type:</strong> ${vuln.type}`);

    const contextHtml = contextParts.length > 0
        ? `<div class="vuln-context" style="margin:10px 0 8px 0; color: rgba(255,255,255,0.82); font-size: 13px; line-height:1.6;">${contextParts.join(' &nbsp;•&nbsp; ')}</div>`
        : '';

    const exploitCount = Number(vuln.nombre_exploits || 0);
    const exploitDetails = Array.isArray(vuln.exploits_details) ? vuln.exploits_details : [];
    const topCvss = exploitDetails
        .map(e => Number(e.cvss || 0))
        .filter(v => !Number.isNaN(v))
        .sort((a, b) => b - a)[0];

    const evidenceRows = exploitDetails.slice(0, 5).map(exploit => `
        <tr>
            <td>${exploit.id || 'N/A'}</td>
            <td>${exploit.cvss ?? 'N/A'}</td>
            <td>${String(exploit.type || 'N/A').toUpperCase()}</td>
        </tr>
    `).join('');

    const exploitEvidenceHtml = exploitCount > 0
        ? `
            <div style="margin: 10px 0 8px 0; padding: 10px; border-radius: 10px; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25);">
                <strong>Preuves d'exposition:</strong> ${exploitCount} exploit(s) connu(s)
                ${topCvss ? ` — CVSS max observé: <strong>${topCvss}</strong>` : ''}
            </div>
            ${evidenceRows ? `
                <table style="width:100%; border-collapse: collapse; margin-bottom: 10px; font-size: 12px;">
                    <thead>
                        <tr>
                            <th style="text-align:left; padding:6px; border-bottom:1px solid rgba(255,255,255,0.2);">Identifiant</th>
                            <th style="text-align:left; padding:6px; border-bottom:1px solid rgba(255,255,255,0.2);">CVSS</th>
                            <th style="text-align:left; padding:6px; border-bottom:1px solid rgba(255,255,255,0.2);">Source</th>
                        </tr>
                    </thead>
                    <tbody>${evidenceRows}</tbody>
                </table>
            ` : ''}
        `
        : '';

    const item = document.createElement('div');
    item.className = `vulnerability-item ${vuln.severity}`;
    item.innerHTML = `
        <div class="vuln-toggle" style="position: absolute; left: 10px; top: 10px; cursor: pointer; font-size: 20px; user-select: none;">
            <span class="vuln-arrow">&#9654;</span>
        </div>
        <div class="vuln-header" style="padding-left: 30px;">
            <h3 class="vuln-title">${vuln.title}</h3>
            <span class="vuln-severity ${vuln.severity}">${getSeverityLabel(vuln.severity)}</span>
        </div>
        <div class="vuln-details" style="display: none;">
            <p class="vuln-description">${vuln.description}</p>
            ${contextHtml}
            <div style="margin-bottom: 10px; color: rgba(255,255,255,0.9);">
                <strong>Pourquoi c'est un risque :</strong>
                ${severityRiskText[vuln.severity] || severityRiskText.medium}
            </div>
            ${exploitEvidenceHtml}
            <div class="vuln-solution">
                <strong>Solution recommandée :</strong>
                ${vuln.solution}
            </div>
        </div>
    `;
    item.style.position = 'relative';
    item.style.background = 'rgba(255, 255, 255, 0.03)';
    item.style.backdropFilter = 'blur(20px)';
    item.style.border = '1px solid rgba(255, 255, 255, 0.1)';
    item.style.borderRadius = '12px';
    item.style.padding = '15px';
    item.style.marginBottom = '15px';

    const arrow = item.querySelector('.vuln-arrow');
    const details = item.querySelector('.vuln-details');
    const toggle = item.querySelector('.vuln-toggle');

    // Function to recalculate parent height
    function updateParentHeight() {
        if (parentContainer && parentContainer.style.height !== 'auto') {
            const newHeight = parentContainer.scrollHeight;
            gsap.to(parentContainer, {
                duration: 0.3,
                height: newHeight,
                ease: "power2.out"
            });
        }
    }

    toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = details.style.display !== 'none';

        if (isOpen) {
            gsap.to(details, {
                duration: 0.3,
                height: 0,
                opacity: 0,
                ease: "power2.in",
                onComplete: () => {
                    details.style.display = 'none';
                    details.style.height = 'auto';
                    updateParentHeight();
                }
            });
            gsap.to(arrow, {
                duration: 0.3,
                rotation: 0,
                ease: "power2.inOut"
            });
        } else {
            details.style.display = 'block';
            details.style.height = 'auto';
            const fullHeight = details.scrollHeight;
            details.style.height = '0px';
            gsap.to(details, {
                duration: 0.4,
                height: fullHeight,
                opacity: 1,
                ease: "power2.out",
                onUpdate: updateParentHeight,
                onComplete: () => {
                    details.style.height = 'auto';
                    updateParentHeight();
                }
            });
            gsap.to(arrow, {
                duration: 0.3,
                rotation: 90,
                ease: "power2.inOut"
            });

            const description = details.querySelector('.vuln-description');
            const solution = details.querySelector('.vuln-solution');
            gsap.from([description, solution], {
                duration: 0.4,
                opacity: 0,
                y: -10,
                stagger: 0.1,
                ease: "power2.out"
            });
        }
    });

    return item;
}

/**
 * @param {number} port - Port number
 * @param {string} service - Service name
 * @returns {string} Port description
 */
function getPortDescription(port, service) {
    const portDescriptions = {
        '21': 'Transfert de fichiers (FTP)',
        '22': 'Connexion SSH sécurisée',
        '23': 'Telnet (non sécurisé)',
        '25': 'Envoi d\'emails (SMTP)',
        '53': 'Résolution DNS',
        '80': 'Serveur web HTTP',
        '110': 'Réception emails (POP3)',
        '111': 'Appels de procédures distantes (RPC)',
        '135': 'Microsoft RPC (DCOM)',
        '139': 'Partage réseau NetBIOS',
        '143': 'Réception emails (IMAP)',
        '161': 'Supervision réseau (SNMP)',
        '443': 'Serveur web HTTPS',
        '445': 'Partage fichiers Windows (SMB)',
        '465': 'SMTP sécurisé',
        '514': 'Journalisation distante (Syslog)',
        '554': 'Streaming vidéo (RTSP)',
        '587': 'Soumission email',
        '631': 'Impression réseau (CUPS/IPP)',
        '993': 'IMAP sécurisé',
        '995': 'POP3 sécurisé',
        '1433': 'Base de données SQL Server',
        '1521': 'Base de données Oracle',
        '1883': 'Messagerie IoT (MQTT)',
        '2049': 'Partage de fichiers NFS',
        '3306': 'Base de données MySQL',
        '3367': 'Service réseau (Conférence/DVB)',
        '3389': 'Bureau à distance Windows (RDP)',
        '5000': 'Services divers / AirPlay / UPnP',
        '5060': 'Téléphonie VoIP (SIP)',
        '5222': 'Messagerie instantanée (XMPP)',
        '5357': 'Découverte réseau (WSD)',
        '5432': 'Base de données PostgreSQL',
        '5900': 'VNC (contrôle distant)',
        '5984': 'Base de données CouchDB',
        '6000': 'Affichage distant (X11)',
        '6379': 'Base de données Redis',
        '7000': 'Services divers / AirPlay / Cassandra',
        '8080': 'Serveur web / proxy HTTP alternatif',
        '8090': 'Interface web d\'administration',
        '8443': 'HTTPS alternatif',
        '8888': 'Interface web / proxy alternatif',
        '9080': 'Interface web d\'administration',
        '9090': 'Proxy web / console d\'administration',
        '9091': 'Interface web d\'administration',
        '9200': 'Base Elasticsearch',
        '11211': 'Cache mémoire (Memcached)',
        '27017': 'Base de données MongoDB'
    };

    return portDescriptions[port] || (service ? `Service ${service}` : 'Usage non documenté');
}

/**
 * @param {string} severity - Severity level
 * @returns {string} Localized severity label
 */
function getSeverityLabel(severity) {
    const labels = {
        critical: 'Critique',
        high: 'Élevé',
        medium: 'Moyen',
        low: 'Faible'
    };
    return labels[severity] || severity;
}

document.getElementById('new-scan')?.addEventListener('click', () => {
    // Transition animation to home
    const timeline = gsap.timeline({
        onComplete: () => {
            showPage('home');
        }
    });

    // Results page elements
    const header = document.querySelector('.results-header');
    const scoreCircle = document.querySelector('.security-score');
    const vulnCards = document.querySelectorAll('.vuln-card');
    const vulnList = document.querySelectorAll('.vulnerability-item');
    const actionButton = document.querySelector('.results-actions');
    const blobs = document.querySelectorAll('#page-results .background-blob');

    // Exit animation
    timeline.to(actionButton, {
        duration: 0.3,
        opacity: 0,
        scale: 0.5,
        y: 30,
        ease: "power2.in"
    }, 0);

    timeline.to(vulnList, {
        duration: 0.4,
        opacity: 0,
        x: 50,
        rotateY: 10,
        stagger: 0.03,
        ease: "power2.in"
    }, 0.1);

    timeline.to(vulnCards, {
        duration: 0.4,
        opacity: 0,
        y: -50,
        scale: 0.8,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.2);

    timeline.to(scoreCircle, {
        duration: 0.6,
        scale: 0,
        opacity: 0,
        rotateZ: 180,
        ease: "power2.in"
    }, 0.3);

    timeline.to(header, {
        duration: 0.4,
        opacity: 0,
        y: -50,
        ease: "power2.in"
    }, 0.3);

    timeline.to(blobs, {
        duration: 0.5,
        scale: 0.5,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.08
    }, 0.4);
});

/**
 * @param {Object} data - System scan data
 * @returns {Array} Parsed vulnerabilities
 */
function parseSystemScanData(data) {
    const vulnerabilities = [];

    console.log('[Results] parseSystemScanData called with:', data);

    try {
        // Le nouveau format inclut directement un tableau 'vulnerabilities'
        if (data.vulnerabilities && Array.isArray(data.vulnerabilities)) {
            data.vulnerabilities.forEach(vuln => {
                vulnerabilities.push({
                    title: vuln.title || vuln.description || 'Problème système',
                    description: vuln.description || 'Aucune description disponible',
                    severity: vuln.severity || 'medium',
                    solution: vuln.solution || 'Consulter la documentation Lynis',
                    category: vuln.category || 'system',
                    type: vuln.type || 'suggestion'
                });
            });
        }

        // Backward compatibility with old format (separate warnings/suggestions)
        if (data.warnings && Array.isArray(data.warnings)) {
            data.warnings.forEach(warning => {
                vulnerabilities.push({
                    title: warning.title || 'Avertissement système',
                    description: warning.description || warning.message || '',
                    severity: warning.severity || 'medium',
                    solution: warning.solution || 'Vérifier la configuration système',
                    category: 'system'
                });
            });
        }

        if (data.suggestions && Array.isArray(data.suggestions)) {
            data.suggestions.forEach(suggestion => {
                vulnerabilities.push({
                    title: suggestion.title || 'Suggestion d\'amélioration',
                    description: suggestion.description || suggestion.message || '',
                    severity: 'low',
                    solution: suggestion.action || 'Appliquer la suggestion',
                    category: 'system'
                });
            });
        }

        // Support ancien format avec hardening_index direct
        if (data.hardening_index !== undefined && data.hardening_index < 60) {
            vulnerabilities.push({
                title: 'Indice de durcissement faible',
                description: `L'indice de durcissement système est de ${data.hardening_index}/100, ce qui indique que le système pourrait être mieux sécurisé.`,
                severity: data.hardening_index < 40 ? 'high' : 'medium',
                solution: 'Appliquer les recommandations de durcissement système',
                category: 'system'
            });
        }

        console.log(`[Results] ${vulnerabilities.length} vulnérabilités système extraites`);

    } catch (error) {
        console.error('[Results] Erreur lors du parsing des données système:', error);
    }

    return vulnerabilities;
}

