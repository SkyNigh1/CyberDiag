document.getElementById('start-diagnostic')?.addEventListener('click', () => {
    animateHomeToModeSelection();
});

document.getElementById('view-history')?.addEventListener('click', () => {
    showPage('history');
    loadHistory();
});

/**
 * Animate transition from home to mode selection page
 */
function animateHomeToModeSelection() {
    const timeline = gsap.timeline({
        onComplete: () => {
            showPage('mode-selection', true);
            animateModeSelectionEntry();
        }
    });

    const title = document.querySelector('#page-home h1');
    const subtitle = document.querySelector('#page-home .subtitle');
    const buttons = document.querySelectorAll('#page-home .button');
    const blobs = document.querySelectorAll('#page-home .background-blob');

    timeline.to(title, {
        duration: 0.5,
        opacity: 0,
        y: -100,
        scale: 1.2,
        ease: "power2.in"
    }, 0);

    timeline.to(subtitle, {
        duration: 0.4,
        opacity: 0,
        y: -50,
        ease: "power2.in"
    }, 0.1);

    timeline.to(buttons, {
        duration: 0.5,
        opacity: 0,
        scale: 0.5,
        y: 100,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.1);

    timeline.to(blobs, {
        duration: 0.6,
        scale: 2,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.08
    }, 0.2);
}

/**
 * Animate mode selection page entry
 */
function animateModeSelectionEntry() {
    const timeline = gsap.timeline({
        onComplete: () => {
            if (typeof reinitializeInteractions === 'function') {
                reinitializeInteractions();
            }
        }
    });

    const blobs = document.querySelectorAll('#page-mode-selection .background-blob');
    gsap.set(blobs, {scale: 0, opacity: 0});
    timeline.to(blobs, {
        duration: 0.8,
        scale: 1,
        opacity: 1,
        ease: "power2.out",
        stagger: 0.1
    }, 0);

    const title = document.querySelector('#page-mode-selection h1');
    const subtitle = document.querySelector('#page-mode-selection .subtitle');
    gsap.set([title, subtitle], {opacity: 0, y: -30});
    timeline.to([title, subtitle], {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out",
        stagger: 0.1
    }, 0.3);

    const modeCards = document.querySelectorAll('.mode-card');
    gsap.set(modeCards, {opacity: 0, scale: 0.8, y: 50});
    timeline.to(modeCards, {
        duration: 0.8,
        opacity: 1,
        scale: 1,
        y: 0,
        ease: "back.out(1.4)",
        stagger: 0.15
    }, 0.5);
}

/**
 * Animate transition from home to questionnaire page
 */
function animateHomeToQuestionnaire() {
    const timeline = gsap.timeline({
        onComplete: () => {
            showPage('questionnaire', true);
            animateQuestionnaireEntry();
        }
    });

    const title = document.querySelector('#page-home h1');
    const subtitle = document.querySelector('#page-home .subtitle');
    const buttons = document.querySelectorAll('#page-home .button');
    const blobs = document.querySelectorAll('#page-home .background-blob');

    timeline.to(title, {
        duration: 0.5,
        opacity: 0,
        y: -100,
        scale: 1.2,
        ease: "power2.in"
    }, 0);

    timeline.to(subtitle, {
        duration: 0.4,
        opacity: 0,
        y: -50,
        ease: "power2.in"
    }, 0.1);

    timeline.to(buttons, {
        duration: 0.5,
        opacity: 0,
        scale: 0.5,
        y: 100,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.1);

    timeline.to(blobs, {
        duration: 0.6,
        scale: 2,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.08
    }, 0.2);
}

/**
 * Animate questionnaire page entry
 */
function animateQuestionnaireEntry() {
    const timeline = gsap.timeline({
        onComplete: () => {
            if (typeof reinitializeInteractions === 'function') {
                reinitializeInteractions();
            }
        }
    });

    const blobs = document.querySelectorAll('#page-questionnaire .background-blob');
    gsap.set(blobs, {scale: 0, opacity: 0});
    timeline.to(blobs, {
        duration: 0.8,
        scale: 1,
        opacity: 1,
        ease: "power2.out",
        stagger: 0.1
    }, 0);

    const progressBar = document.querySelector('.progress-bar');
    gsap.set(progressBar, {scaleX: 0, opacity: 0});
    timeline.to(progressBar, {
        duration: 0.6,
        scaleX: 1,
        opacity: 1,
        transformOrigin: "left center",
        ease: "power2.out"
    }, 0.3);

    const questionCard = document.querySelector('.question-card');
    gsap.set(questionCard, {opacity: 0, scale: 0.8, rotateY: -20});
    timeline.to(questionCard, {
        duration: 0.8,
        opacity: 1,
        scale: 1,
        rotateY: 0,
        ease: "back.out(1.4)"
    }, 0.4);

    const questionNumber = document.querySelector('.question-number');
    gsap.set(questionNumber, {opacity: 0, x: -30});
    timeline.to(questionNumber, {
        duration: 0.5,
        opacity: 1,
        x: 0,
        ease: "power2.out"
    }, 0.7);

    const questionText = document.querySelector('.question-text');
    gsap.set(questionText, {opacity: 0, y: -20});
    timeline.to(questionText, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.8);

    const answers = document.querySelectorAll('.answer-option');
    gsap.set(answers, {opacity: 0, x: -50, rotateY: -10});
    timeline.to(answers, {
        duration: 0.5,
        opacity: 1,
        x: 0,
        rotateY: 0,
        stagger: 0.08,
        ease: "back.out(1.5)"
    }, 0.9);

    const navButtons = document.querySelectorAll('.navigation-buttons button');
    gsap.set(navButtons, {opacity: 0, y: 30, scale: 0.8});
    timeline.to(navButtons, {
        duration: 0.5,
        opacity: 1,
        y: 0,
        scale: 1,
        stagger: 0.1,
        ease: "back.out(1.7)"
    }, 1.1);
}

// importing the function to initialize the questionnaire
import {startQuestionnaire} from './questionnaire.js';

document.addEventListener('DOMContentLoaded', () => {
    // Global variable to store the selected user mode 
    window.userMode = null; // 'novice' or 'expert'

    showPage('home', true);
    setTimeout(() => {
        const title = document.querySelector('#page-home h1');
        const subtitle = document.querySelector('#page-home .subtitle');
        const buttons = document.querySelectorAll('#page-home .button');

        if (title) title.style.opacity = '1';
        if (subtitle) subtitle.style.opacity = '1';
        buttons.forEach(btn => btn.style.opacity = '1');
    }, 10);

    // Mode selection handlers
    const modeButtons = document.querySelectorAll('#page-mode-selection .button[data-mode]');
    modeButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const mode = button.getAttribute('data-mode');
            const action = button.getAttribute('data-action');

            if (mode === 'novice') {
                window.userMode = 'novice';
                // Novice mode: switch to questionnaire page
                startQuestionnaire(); // initializing

                const timeline = gsap.timeline({
                    onComplete: () => {
                        showPage('questionnaire', true);
                        animateQuestionnaireEntry();
                    }
                });

                const modeCards = document.querySelectorAll('.mode-card');
                const title = document.querySelector('#page-mode-selection h1');
                const subtitle = document.querySelector('#page-mode-selection .subtitle');

                timeline.to([title, subtitle, modeCards], {
                    duration: 0.5,
                    opacity: 0,
                    y: -50,
                    stagger: 0.05,
                    ease: "power2.in"
                });

            } else if (mode === 'expert') {
                window.userMode = 'expert';

                if (action === 'with-questionnaire') {
                    // Expert novice with questionnaire
                    startQuestionnaire();  // initializing

                    const timeline = gsap.timeline({
                        onComplete: () => {
                            showPage('questionnaire', true);
                            animateQuestionnaireEntry();
                        }
                    });

                    const modeCards = document.querySelectorAll('.mode-card');
                    const title = document.querySelector('#page-mode-selection h1');
                    const subtitle = document.querySelector('#page-mode-selection .subtitle');

                    timeline.to([title, subtitle, modeCards], {
                        duration: 0.5,
                        opacity: 0,
                        y: -50,
                        stagger: 0.05,
                        ease: "power2.in"
                    });

                } else if (action === 'without-questionnaire') {
                    // Mode expert sans questionnaire: aller directement à la sélection de test
                    const timeline = gsap.timeline({
                        onComplete: () => {
                            showPage('test-selection', true);
                            // Définir un niveau par défaut "Standard" pour le mode expert
                            const recommendedLevelText = document.getElementById('recommended-level-text');
                            if (recommendedLevelText) {
                                recommendedLevelText.textContent = 'Standard';
                            }

                            // Adapter le subtitle pour le mode expert sans questionnaire
                            const subtitle = document.querySelector('#page-test-selection .subtitle');
                            if (subtitle) {
                                subtitle.innerHTML = 'Choisissez le niveau d\'analyse qui vous convient.';
                            }

                            // S'assurer que toutes les cartes sont actives en mode expert
                            document.querySelectorAll('.test-card').forEach(card => {
                                const level = card.dataset.level;
                                const badge = card.querySelector('.recommended-badge');
                                const button = card.querySelector('.button-test');

                                card.style.opacity = '1';
                                card.style.pointerEvents = 'auto';
                                card.style.borderColor = level === 'Standard' ? 'rgba(233, 233, 233, 0.4)' : 'rgba(255, 255, 255, 0.1)';
                                card.style.background = level === 'Standard' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(255, 255, 255, 0.03)';

                                if (level === 'Standard') {
                                    if (!badge) {
                                        const newBadge = document.createElement('span');
                                        newBadge.className = 'recommended-badge';
                                        newBadge.textContent = 'Recommandé';
                                        card.querySelector('.test-card-header').appendChild(newBadge);
                                    }
                                } else {
                                    if (badge) badge.remove();
                                }

                                if (button) {
                                    button.disabled = false;
                                    button.style.opacity = '1';
                                    button.style.pointerEvents = 'auto';
                                    button.style.cursor = 'pointer';
                                }
                            });

                            animateTestSelectionEntrance('Standard');
                        }
                    });

                    const modeCards = document.querySelectorAll('.mode-card');
                    const title = document.querySelector('#page-mode-selection h1');
                    const subtitle = document.querySelector('#page-mode-selection .subtitle');

                    timeline.to([title, subtitle, modeCards], {
                        duration: 0.5,
                        opacity: 0,
                        y: -50,
                        stagger: 0.05,
                        ease: "power2.in"
                    });
                }
            }
        });
    });

    // Add hover effects for mode cards
    const modeCards = document.querySelectorAll('.mode-card');
    modeCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            gsap.to(card, {
                duration: 0.3,
                scale: 1.05,
                borderColor: 'rgba(255, 255, 255, 0.3)',
                ease: "power2.out"
            });
        });

        card.addEventListener('mouseleave', () => {
            gsap.to(card, {
                duration: 0.3,
                scale: 1,
                borderColor: 'rgba(255, 255, 255, 0.1)',
                ease: "power2.out"
            });
        });
    });
});
