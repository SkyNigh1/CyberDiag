let allScans = [];
let currentFilter = 'all';
const INITIAL_LOAD_LIMIT = 20; // Only load first 20 scans initially

/**
 * @param {Object} scan - Scan data
 */
function saveToHistory(scan) {
    console.log('Scan saved by backend:', scan);
}

/**
 * Load scan history from backend with optimized loading
 */
async function loadHistory() {
    const container = document.getElementById('history-list');

    container.innerHTML = `
        <div style="text-align: center; padding: 60px; color: rgba(255, 255, 255, 0.5);">
            <h3>Chargement de l'historique...</h3>
        </div>
    `;

    try {
        if (!window.pywebview || !window.pywebview.api) {
            container.innerHTML = `
                <div style="text-align: center; padding: 60px; color: rgba(255, 255, 255, 0.5);">
                    <h3>API Python non disponible</h3>
                    <p>L'historique nécessite l'API Python pour fonctionner</p>
                </div>
            `;
            return;
        }

        const scans = await window.pywebview.api.get_scan_history();
        allScans = scans || [];

        allScans.sort((a, b) => {
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
            return dateB - dateA; // Most recent first
        });

        if (allScans.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 60px; color: rgba(255, 255, 255, 0.5);">
                    <h3>Aucun audit dans l'historique</h3>
                    <p>Lancez votre premier diagnostic pour commencer</p>
                </div>
            `;
            return;
        }

        displayFilteredScans();

    } catch (error) {
        console.error('Erreur lors du chargement de l\'historique:', error);
        container.innerHTML = `
            <div style="text-align: center; padding: 60px; color: rgba(255, 255, 255, 0.5);">
                <h3>Erreur de chargement</h3>
                <p>Impossible de charger l'historique des scans</p>
            </div>
        `;
    }
}

/**
 * Display scans based on active filter with lazy loading
 */
async function displayFilteredScans() {
    const container = document.getElementById('history-list');
    container.innerHTML = '';

    let filteredScans = allScans;

    if (currentFilter === 'recent') {
        // Show only last 10 scans
        filteredScans = allScans.slice(0, 10);
    } else if (currentFilter === 'network') {
        filteredScans = allScans.filter(s => s.type === 'network');
    } else if (currentFilter === 'system') {
        filteredScans = allScans.filter(s => s.type === 'system');
    }

    if (filteredScans.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 60px; color: rgba(255, 255, 255, 0.5);">
                <h3>Aucun résultat</h3>
                <p>Aucun scan ne correspond au filtre sélectionné</p>
            </div>
        `;
        return;
    }

    // Use DocumentFragment for better performance when adding many elements
    const fragment = document.createDocumentFragment();
    const scansToShow = filteredScans.slice(0, INITIAL_LOAD_LIMIT);

    for (const scan of scansToShow) {
        const item = createHistoryItem(scan);
        fragment.appendChild(item);
    }

    container.appendChild(fragment);

    // Show "Load more" button if there are more scans
    if (filteredScans.length > INITIAL_LOAD_LIMIT) {
        const loadMoreBtn = document.createElement('button');
        loadMoreBtn.className = 'button button-secondary';
        loadMoreBtn.style.margin = '20px auto';
        loadMoreBtn.style.display = 'block';
        loadMoreBtn.innerHTML = `<span class="button-text">Charger plus (${filteredScans.length - INITIAL_LOAD_LIMIT} restants)</span>`;
        loadMoreBtn.onclick = () => loadMoreScans(filteredScans, INITIAL_LOAD_LIMIT);
        container.appendChild(loadMoreBtn);
    }
}

/**
 * Load more scans when user clicks "Load more"
 */
function loadMoreScans(filteredScans, startIndex) {
    const container = document.getElementById('history-list');
    const loadMoreBtn = container.querySelector('.button-secondary');
    if (loadMoreBtn) loadMoreBtn.remove();

    const fragment = document.createDocumentFragment();
    const nextBatch = filteredScans.slice(startIndex, startIndex + INITIAL_LOAD_LIMIT);

    for (const scan of nextBatch) {
        const item = createHistoryItem(scan);
        fragment.appendChild(item);
    }

    container.appendChild(fragment);

    // Show another "Load more" if still more scans
    const remaining = filteredScans.length - startIndex - INITIAL_LOAD_LIMIT;
    if (remaining > 0) {
        const newLoadMoreBtn = document.createElement('button');
        newLoadMoreBtn.className = 'button button-secondary';
        newLoadMoreBtn.style.margin = '20px auto';
        newLoadMoreBtn.style.display = 'block';
        newLoadMoreBtn.innerHTML = `<span class="button-text">Charger plus (${remaining} restants)</span>`;
        newLoadMoreBtn.onclick = () => loadMoreScans(filteredScans, startIndex + INITIAL_LOAD_LIMIT);
        container.appendChild(newLoadMoreBtn);
    }
}

/**
 * @param {Object} scan - Scan metadata
 * @returns {HTMLElement} History item element
 */
function createHistoryItem(scan) {
    const date = new Date(scan.date);
    const item = document.createElement('div');
    item.className = 'history-item';

    const dateStr = date.toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    const typeLabel = scan.type === 'network' ? 'Scan Réseau' : 'Scan Système';
    const typeClass = scan.type === 'network' ? 'network' : 'system';
    item.classList.add(scan.type === 'network' ? 'network-item' : 'system-item');

    item.innerHTML = `
        <div class="history-item-info">
            <div class="history-item-header">
                <span class="history-type ${typeClass}">${typeLabel}</span>
                <span class="history-date">${dateStr}</span>
            </div>
            <div class="history-stats">
                <span class="history-filename">${scan.filename}</span>
            </div>
        </div>
        <div class="history-action">Voir le rapport →</div>
    `;

    item.addEventListener('click', async () => {
        window.currentArtifacts = scan.artifacts || {};
        if (!window.currentArtifacts.date) {
            window.currentArtifacts.date = scan.date;
        }
        window.currentScanType = scan.type;
        await viewScanReport(scan);
    });

    return item;
}

/**
 * @param {Object} scan - Scan to display
 */
async function viewScanReport(scan) {
    try {
        // mode selected with the toggle button
        const toggleButton = document.getElementById('mode-user-toggle-button');

        window.userMode = toggleButton.checked ? 'novice' : 'expert';

        // Load scan data from Python
        const scanData = await window.pywebview.api.get_scan_data(scan.path);

        if (!scanData) {
            alert('Impossible de charger les données du scan');
            return;
        }

        // Navigate to results page
        showPage('results');

        // Display results based on scan type
        if (scan.type === 'network') {
            displayNetworkScanResults(scanData, scan.date);
        } else {
            displaySystemScanResults(scanData, scan.date);
        }

    } catch (error) {
        console.error('Erreur lors du chargement du scan:', error);
        alert('Erreur lors du chargement du rapport');
    }
}

function displayNetworkScanResults(data, scanDate) {
    console.log('[History] displayNetworkScanResults called with data:', data);

    const vulnerabilities = parseNetworkScanData(data);
    console.log('[History] Parsed vulnerabilities:', vulnerabilities.length);

    // Count vulnerabilities by severity
    const counts = {
        critical: 0,
        high: 0,
        medium: 0,
        low: 0
    };

    vulnerabilities.forEach(vuln => {
        if (counts.hasOwnProperty(vuln.severity)) {
            counts[vuln.severity]++;
        }
    });

    console.log('[History] Vulnerability counts:', counts);

    const score = calculateSecurityScore(vulnerabilities);
    console.log('[History] Calculated score:', score);

    displayResults({
        score: score,
        vulnerabilities: vulnerabilities,
        counts: counts,
        scanDate: scanDate
    });
}

/**
 * @param {Object} data - System scan data
 * @param {string} scanDate - Scan date
 */
function displaySystemScanResults(data, scanDate) {
    console.log('[History] displaySystemScanResults called with data:', data);

    const vulnerabilities = parseSystemScanData(data);
    console.log('[History] Parsed vulnerabilities:', vulnerabilities.length);

    // Count vulnerabilities by severity
    const counts = {
        critical: 0,
        high: 0,
        medium: 0,
        low: 0
    };

    vulnerabilities.forEach(vuln => {
        if (counts.hasOwnProperty(vuln.severity)) {
            counts[vuln.severity]++;
        }
    });

    console.log('[History] Vulnerability counts:', counts);

    let score;
    if (data.security_score !== undefined) {
        score = data.security_score;
        console.log('[History] Using security_score from data:', score);
    } else {
        score = calculateSecurityScore(vulnerabilities);
        console.log('[History] Calculated score from vulnerabilities:', score);
    }

    // Display results
    displayResults({
        score: score,
        vulnerabilities: vulnerabilities,
        counts: counts,
        scanDate: scanDate
    });
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            currentFilter = btn.dataset.filter;
            displayFilteredScans();
        });
    });
});
