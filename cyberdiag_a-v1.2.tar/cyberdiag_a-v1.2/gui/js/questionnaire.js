let questions = [];
let questionPath = [0];

// Load the json file 
fetch('./js/questions/questions.json')
    .then(res => res.json())
    .then(data => {
        questions = data.questions;
    })
    .catch(err => console.error("Erreur lors du chargement des questions (JSON) :", err));

let currentQuestionIndex = 0;
let userAnswers = [];
let isAnimating = false;

/**
 * Initialize questionnaire from beginning
 */
export function startQuestionnaire() {
    currentQuestionIndex = 0;
    questionPath = [0];
    userAnswers = [];
    displayQuestion();
}

/**
 * Display current question with answer options
 */
function displayQuestion() {
    const question = questions[currentQuestionIndex];
    document.getElementById('question-text').textContent = question.text;
    document.getElementById('current-question').textContent = questionPath.length;
    document.getElementById('total-questions').textContent = getTotalQuestionsDynamic();

    const answersContainer = document.getElementById('answers-container');
    answersContainer.innerHTML = '';

    question.answers.forEach((answer, index) => {
        const answerDiv = document.createElement('div');
        answerDiv.className = 'answer-option';
        answerDiv.textContent = answer.text;
        answerDiv.dataset.score = answer.score;
        answerDiv.dataset.index = index;

        if (userAnswers[currentQuestionIndex] === index) {
            answerDiv.classList.add('selected');
        }

        answerDiv.addEventListener('click', () => selectAnswer(index, answer.score));
        answersContainer.appendChild(answerDiv);
    });

    const total = getTotalQuestionsDynamic();
    const progress = (questionPath.length / total) * 100;
    gsap.to('.progress-fill', {
        duration: 0.6,
        width: `${progress}%`,
        ease: "power2.out"
    });

    document.getElementById('prev-question').disabled = false;
    updateNextButton();

    animateQuestionTransition();
}

/**
 *
 */
function getTotalQuestionsDynamic() {
    let total = questions.filter(q => !q.id || !q.id.endsWith('_son')).length;

    // count the questions 'son' through the path
    questionPath.forEach(i => {
        if (questions[i].id && questions[i].id.endsWith('_son')) {
            total++;
        }
    });

    return total;
}

/**
 * Animate question transition
 */
function animateQuestionTransition() {
    requestAnimationFrame(() => {
        const questionNumber = document.querySelector('.question-number');
        const questionText = document.querySelector('.question-text');
        const answers = document.querySelectorAll('.answer-option');

        if (!questionNumber || !questionText || answers.length === 0) {
            return;
        }

        questionNumber.style.opacity = '1';
        questionText.style.opacity = '1';
        answers.forEach(answer => answer.style.opacity = '1');

        const timeline = gsap.timeline();

        timeline.from(questionNumber, {
            duration: 0.3,
            opacity: 0,
            x: -20,
            ease: "power2.out"
        }, 0);

        timeline.from(questionText, {
            duration: 0.4,
            opacity: 0,
            y: -15,
            ease: "power2.out"
        }, 0.1);

        timeline.from(answers, {
            duration: 0.4,
            opacity: 0,
            y: 20,
            stagger: 0.06,
            ease: "power2.out"
        }, 0.2);
    });
}

/**
 * @param {number} index - Answer index
 * @param {number} score - Answer score
 */
function selectAnswer(index, score) {
    userAnswers[currentQuestionIndex] = index;

    const options = document.querySelectorAll('.answer-option');
    options.forEach((option, i) => {
        option.classList.remove('selected');
        if (i === index) {
            option.classList.add('selected');
            gsap.fromTo(option,
                {scale: 0.95},
                {
                    scale: 1,
                    duration: 0.3,
                    ease: "back.out(2)"
                }
            );
        }
    });

    updateNextButton();
}

/**
 * Update next button state and text
 */
function updateNextButton() {
    const nextButton = document.getElementById('next-question');
    const hasAnswer = userAnswers[currentQuestionIndex] !== undefined;
    nextButton.disabled = !hasAnswer;

    if (currentQuestionIndex === questions.length - 1 && hasAnswer) {
        nextButton.querySelector('.button-text').textContent = 'Terminer';
    } else {
        nextButton.querySelector('.button-text').textContent = 'Suivant';
    }
}

/**
 * Checks if the current question has a "son" question
 */
function getNextIndex() {
    const currentQuestion = questions[currentQuestionIndex];
    const answer = currentQuestion.answers[userAnswers[currentQuestionIndex]];

    if (answer && answer.nextQuestionID) {
        const nextID = questions.findIndex(q => q.id === answer.nextQuestionID);

        if (nextID !== -1) {
            return nextID;
        }
    }

    for (let i = currentQuestionIndex + 1; i < questions.length; i++) {
        if (!questions[i].id || !questions[i].id.endsWith('_son')) {
            return i;
        }
    }
    return -1;
}

document.getElementById('next-question')?.addEventListener('click', () => {
    if (isAnimating) return;
    if (currentQuestionIndex < questions.length - 1) {
        isAnimating = true;
        animateQuestionExit('next', () => {
            currentQuestionIndex = nextIndex;
            questionPath.push(nextIndex);
            displayQuestion();
            isAnimating = false;
        });
    } else {
        let totalScore = 0;

        // loop through each question index in the navigation path (questionPath)
        for (const qIndex of questionPath) {
            const answerIndex = userAnswers[qIndex];
            // find the corresponding answer
            const selectedAnswer = questions[qIndex].answers[answerIndex];

            if (selectedAnswer) {
                totalScore += selectedAnswer.score
            }
        }

        const percentage = (totalScore / (questionPath.length * 4)) * 100;

        let recommendedLevel = 'Basique';
        if (percentage > 70) recommendedLevel = 'Approfondi';
        else if (percentage > 40) recommendedLevel = 'Standard';

        showTestSelection(recommendedLevel, percentage);
    }
});

document.getElementById('prev-question')?.addEventListener('click', () => {
    if (isAnimating) return;
    if (currentQuestionIndex > 0) {
        isAnimating = true;
        animateQuestionExit('prev', () => {
            questionPath.pop(); // remove current question from history
            currentQuestionIndex = questionPath[questionPath.length - 1]; // go to previous question
            displayQuestion();
            isAnimating = false;
        });
    } else {
        // At question 0, go back to mode selection page
        isAnimating = true;
        const timeline = gsap.timeline({
            onComplete: () => {
                isAnimating = false;
                showPage('mode-selection', true);
                animateModeSelectionEntry();
            }
        });

        const questionCard = document.querySelector('.question-card');
        const progressBar = document.querySelector('.progress-bar');
        const blobs = document.querySelectorAll('#page-questionnaire .background-blob');

        timeline.to(questionCard, {
            duration: 0.4,
            opacity: 0,
            scale: 0.9,
            y: 30,
            ease: "power2.in"
        }, 0);

        timeline.to(progressBar, {
            duration: 0.3,
            opacity: 0,
            scaleX: 0,
            transformOrigin: "left center",
            ease: "power2.in"
        }, 0.1);

        timeline.to(blobs, {
            duration: 0.5,
            scale: 1.5,
            opacity: 0,
            ease: "power2.inOut",
            stagger: 0.08
        }, 0.2);
    }
});

/**
 * @param {string} direction - Animation direction
 * @param {Function} onComplete - Completion callback
 */
function animateQuestionExit(direction, onComplete) {
    const timeline = gsap.timeline({
        onComplete: () => {
            gsap.set([questionText, ...answers], {clearProps: "all"});

            onComplete();
        }
    });

    const questionText = document.querySelector('.question-text');
    const answers = document.querySelectorAll('.answer-option');

    const xOffset = direction === 'next' ? 30 : -30;

    timeline.to([questionText, ...answers], {
        duration: 0.25,
        opacity: 0,
        x: xOffset,
        ease: "power2.in"
    }, 0);
}

/**
 * @param {string} recommendedLevel - Recommended test level
 * @param {number} maturityScore - User maturity score
 */
function showTestSelection(recommendedLevel, maturityScore) {
    const timeline = gsap.timeline({
        onComplete: () => {
            showPage('test-selection');

            window.currentMaturityScore = maturityScore;
            const isNoviceMode = window.userMode === 'novice';

            document.getElementById('recommended-level-text').textContent = recommendedLevel;

            // Modifier le texte du subtitle selon le mode et le niveau recommandé
            const subtitle = document.querySelector('#page-test-selection .subtitle');
            if (subtitle) {
                const isMostExhaustive = recommendedLevel === 'Approfondi';
                if (isNoviceMode) {
                    if (isMostExhaustive) {
                        subtitle.innerHTML = 'Basé sur vos réponses, votre situation nécessite une analyse <span id="recommended-level-text">' + recommendedLevel + '</span>. Il est important de ne pas négliger ce diagnostic.';
                    } else {
                        subtitle.innerHTML = 'Basé sur vos réponses, nous recommandons une analyse <span id="recommended-level-text">' + recommendedLevel + '</span>.';
                    }
                } else {
                    // En mode expert, toujours laisser la liberté de choix
                    subtitle.innerHTML = 'Basé sur vos réponses, nous recommandons une analyse <span id="recommended-level-text">' + recommendedLevel + '</span>. Vous pouvez toutefois choisir le niveau qui vous convient.';
                }
            }

            document.querySelectorAll('.test-card').forEach(card => {
                const badge = card.querySelector('.recommended-badge');
                const level = card.dataset.level;
                const button = card.querySelector('.button-test');

                if (level === recommendedLevel) {
                    if (!badge) {
                        const newBadge = document.createElement('span');
                        newBadge.className = 'recommended-badge';
                        newBadge.textContent = 'Recommandé';
                        card.querySelector('.test-card-header').appendChild(newBadge);
                    }
                    card.style.borderColor = 'rgba(233, 233, 233, 0.4)';
                    card.style.background = 'rgba(255, 255, 255, 0.05)';
                    card.style.opacity = '1';
                    card.style.pointerEvents = 'auto';
                    if (button) {
                        button.disabled = false;
                        button.style.opacity = '1';
                        button.style.pointerEvents = 'auto';
                    }
                } else {
                    if (badge) badge.remove();

                    // En mode novice, désactiver complètement les autres options
                    if (isNoviceMode) {
                        card.style.borderColor = 'rgba(255, 255, 255, 0.05)';
                        card.style.background = 'rgba(255, 255, 255, 0.01)';
                        card.style.opacity = '0.3';
                        card.style.pointerEvents = 'none';
                        if (button) {
                            button.disabled = true;
                            button.style.opacity = '0.3';
                            button.style.pointerEvents = 'none';
                            button.style.cursor = 'not-allowed';
                        }
                    } else {
                        // En mode expert, laisser les cartes actives
                        card.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                        card.style.background = 'rgba(255, 255, 255, 0.03)';
                        card.style.opacity = '1';
                        card.style.pointerEvents = 'auto';
                        if (button) {
                            button.disabled = false;
                            button.style.opacity = '1';
                            button.style.pointerEvents = 'auto';
                            button.style.cursor = 'pointer';
                        }
                    }
                }
            });

            animateTestSelectionEntrance(recommendedLevel);
        }
    });

    const questionCard = document.querySelector('.question-card');
    const progressBar = document.querySelector('.progress-bar');
    const questionNumber = document.querySelector('.question-number');
    const questionText = document.querySelector('.question-text');
    const answers = document.querySelectorAll('.answer-option');
    const navButtons = document.querySelectorAll('.navigation-buttons button');

    timeline.to(questionText, {
        duration: 0.3,
        opacity: 0,
        y: -20,
        ease: "power2.in"
    }, 0);

    timeline.to(answers, {
        duration: 0.4,
        opacity: 0,
        x: -50,
        rotateY: -15,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.1);

    timeline.to(navButtons, {
        duration: 0.3,
        opacity: 0,
        y: 30,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.2);

    timeline.to(progressBar, {
        duration: 0.4,
        scaleX: 0,
        opacity: 0,
        transformOrigin: "left center",
        ease: "power2.in"
    }, 0.3);

    timeline.to(questionCard, {
        duration: 0.5,
        scale: 0.8,
        opacity: 0,
        y: 50,
        ease: "power2.in"
    }, 0.4);

    const blobs = document.querySelectorAll('#page-questionnaire .background-blob');
    timeline.to(blobs, {
        duration: 0.6,
        scale: 1.5,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.1
    }, 0.3);
}

/**
 * @param {string} recommendedLevel - Recommended test level
 */
function animateTestSelectionEntrance(recommendedLevel) {
    const timeline = gsap.timeline({
        onComplete: () => {
            if (typeof reinitializeInteractions === 'function') {
                reinitializeInteractions();
            }
        }
    });

    // Reset container styles that may have been left by a previous page exit animation
    const container = document.querySelector('.test-selection-container');
    if (container) {
        gsap.set(container, {opacity: 1, scale: 1, y: 0, clearProps: 'all'});
    }

    const blobs = document.querySelectorAll('#page-test-selection .background-blob');
    gsap.set(blobs, {scale: 0, opacity: 0});
    timeline.to(blobs, {
        duration: 0.8,
        scale: 1,
        opacity: 1,
        ease: "power2.out",
        stagger: 0.1
    }, 0);

    const title = document.querySelector('#page-test-selection .gradient-text');
    gsap.set(title, {opacity: 0, y: -30});
    timeline.to(title, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.2);

    const subtitle = document.querySelector('#page-test-selection .subtitle');
    gsap.set(subtitle, {opacity: 0, y: -20});
    timeline.to(subtitle, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.3);

    const testCards = document.querySelectorAll('.test-card');
    gsap.set(testCards, {
        opacity: 0,
        y: 50,
        scale: 0.9
    });

    timeline.to(testCards, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        scale: 1,
        stagger: 0.12,
        ease: "power2.out",
        onComplete: () => {
            testCards.forEach(card => {
                if (card.dataset.level === recommendedLevel) {
                    gsap.to(card, {
                        duration: 0.4,
                        scale: 1.02,
                        ease: "power2.out"
                    });
                }
            });
        }
    }, 0.4);

    const buttons = document.querySelectorAll('.test-card .button-test');
    gsap.set(buttons, {opacity: 0});
    timeline.to(buttons, {
        duration: 0.4,
        opacity: 1,
        stagger: 0.08,
        ease: "power2.out"
    }, 0.8);
}

document.querySelectorAll('.button-test').forEach(button => {
    button.addEventListener('click', function () {
        const selectedLevel = this.dataset.level;
        const selectedScanType = document.querySelector('.scan-type-btn.active')?.dataset.scanType || 'network';
        console.log(`Starting scan: level=${selectedLevel}, type=${selectedScanType}`);
        startScan(selectedLevel, window.currentMaturityScore || 50, selectedScanType);
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const scanTypeButtons = document.querySelectorAll('.scan-type-btn');
    scanTypeButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            scanTypeButtons.forEach(b => {
                b.classList.remove('active');
                b.style.background = 'rgba(255, 255, 255, 0.03)';
                b.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                b.style.color = 'rgba(255, 255, 255, 0.6)';
            });

            this.classList.add('active');
            this.style.background = 'linear-gradient(135deg, rgba(59, 130, 246, 0.22), rgba(99, 102, 241, 0.22))';
            this.style.borderColor = 'rgba(255, 255, 255, 0.3)';
            this.style.color = '#fff';
        });
    });
});
