/** @type {Object|null} */
window.currentScanData = null;
/** @type {string|null} */
window.currentScanType = null;
/** @type {number|null} */
window.scanTimerInterval = null;
/** @type {number|null} */
window.scanProgressInterval = null;
/** @type {Date|null} */
window.scanStartTime = null;
/** @type {boolean} */
window.scanCancelled = false;

/**
 * @param {string} scanType - Type of scan
 * @param {Object} data - Scan data
 * @param {Object} meta - Metadata
 */
window.onScanComplete = function (scanType, data, meta) {
    // Ignore if scan was cancelled
    if (window.scanCancelled) {
        window.scanCancelled = false;
        return;
    }

    // Stop the timer
    stopScanTimer();

    // Show navbar again
    document.body.classList.remove('scanning-active');

    const statusEl = document.getElementById('scan-status');
    if (statusEl) {
        const dataInfo = Array.isArray(data) ? `${data.length} hôtes` : typeof data;
        statusEl.textContent = `Données reçues: ${dataInfo}`;
        statusEl.style.color = '#22c55e';
    }

    console.log(`[onScanComplete] Scan ${scanType} terminé:`, data, meta);
    console.log(`[onScanComplete] Type des données:`, typeof data, Array.isArray(data));
    console.log(`[onScanComplete] Nombre d'éléments:`, Array.isArray(data) ? data.length : 'N/A');

    window.currentScanData = data;
    window.currentScanType = scanType;
    window.currentScanSimulated = meta && meta.simulated;
    window.currentScanSimReason = (meta && meta.reason) || null;
    window.currentArtifacts = (meta && meta.artifacts) || null;

    console.log(`[onScanComplete] Variables globales mises à jour:`, {
        currentScanData: window.currentScanData,
        currentScanType: window.currentScanType,
        currentScanSimulated: window.currentScanSimulated
    });

    document.querySelector('.scan-progress-fill').style.width = '100%';
    document.querySelector('.scan-percentage').textContent = '100%';

    if (window.currentScanSimulated) {
        const statusElement = document.getElementById('scan-status');
        if (statusElement) {
            const toolName = scanType === 'network' ? 'nmap' : 'Lynis';
            statusElement.textContent = `Résultats simulés — ${toolName} introuvable sur cet appareil`;
            statusElement.style.color = '#f59e0b';
        }
    }

    setTimeout(() => {
        const level = document.getElementById('scan-level').textContent || 'Basique';
        const maturityScore = window.currentMaturityScore || 50;
        animateToResultsPage(level, maturityScore);
        if (typeof updateBackButtonVisibility === 'function') {
            updateBackButtonVisibility();
        }
    }, 1000);
};

/**
 * @param {string} scanType - Type of scan
 * @param {string} errorMessage - Error message
 */
window.onScanError = function (scanType, errorMessage) {
    console.error(`Erreur scan ${scanType}:`, errorMessage);

    // Stop the timer
    stopScanTimer();

    // Show navbar again
    document.body.classList.remove('scanning-active');

    const statusElement = document.getElementById('scan-status');
    if (statusElement) {
        statusElement.textContent = `Erreur: ${errorMessage}`;
        statusElement.style.color = '#ef4444';
    }

    const progressFill = document.querySelector('.scan-progress-fill');
    if (progressFill) {
        progressFill.style.backgroundColor = '#ef4444';
    }
};

/**
 * @param {string} scanType - Type of scan
 * @param {number} percent - Progress percentage
 * @param {number} items - Number of processed items
 */
window.onScanProgress = function (scanType, percent, items) {
    // Ignore progress updates if scan was cancelled
    if (window.scanCancelled) {
        return;
    }

    try {
        percent = Number(percent) || 0;
        const progressFill = document.querySelector('.scan-progress-fill');
        if (progressFill) progressFill.style.width = `${percent}%`;
        const perc = document.querySelector('.scan-percentage');
        if (perc) perc.textContent = `${Math.floor(percent)}%`;
        const itemsEl = document.getElementById('scanned-items');
        if (itemsEl) itemsEl.textContent = items || 0;

        // Store the last reported values so the scanning loop uses them
        try {
            window._lastReportedPercent = percent;
            window._lastReportedItems = items || 0;
            window._lastReportedAt = Date.now();
        } catch (e) {
            // ignore
        }

        // If progress reaches 100, let the normal onScanComplete flow finish
        if (percent >= 100 && window.onScanComplete) {
            // Let onScanComplete handle the rest as usual
        }
    } catch (e) {
        console.error('Erreur dans onScanProgress handler:', e);
    }
};

/**
 * Start the scan timer
 */
function startScanTimer() {
    window.scanStartTime = new Date();
    window.scanCancelled = false;

    // Display start time
    const startTimeEl = document.getElementById('scan-start-time');
    if (startTimeEl) {
        startTimeEl.textContent = window.scanStartTime.toLocaleTimeString('fr-FR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    // Reset elapsed time
    const elapsedEl = document.getElementById('scan-elapsed-time');
    if (elapsedEl) {
        elapsedEl.textContent = '00:00';
    }

    // Update elapsed time every second
    window.scanTimerInterval = setInterval(() => {
        if (window.scanStartTime) {
            const now = new Date();
            const elapsed = Math.floor((now - window.scanStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;

            const elapsedEl = document.getElementById('scan-elapsed-time');
            if (elapsedEl) {
                elapsedEl.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            }
        }
    }, 1000);
}

/**
 * Stop the scan timer
 */
function stopScanTimer() {
    if (window.scanTimerInterval) {
        clearInterval(window.scanTimerInterval);
        window.scanTimerInterval = null;
    }
    if (window.scanProgressInterval) {
        clearInterval(window.scanProgressInterval);
        window.scanProgressInterval = null;
    }
}

/**
 * Cancel the current scan
 */
function cancelScan() {
    console.log('Annulation du scan...');
    window.scanCancelled = true;

    // Stop timer
    stopScanTimer();

    // Call Python API to cancel scan
    if (typeof pywebview !== 'undefined' && pywebview.api) {
        pywebview.api.cancel_scan().then(response => {
            console.log('Réponse annulation:', response);
        }).catch(error => {
            console.error('Erreur lors de l\'annulation:', error);
        });
    }

    // Show navbar again
    document.body.classList.remove('scanning-active');

    // Reset progress bar
    const progressFill = document.querySelector('.scan-progress-fill');
    if (progressFill) {
        progressFill.style.width = '0%';
        progressFill.style.backgroundColor = '';
    }
    const percentage = document.querySelector('.scan-percentage');
    if (percentage) percentage.textContent = '0%';

    // Return to the actual previous page in history after cancel.
    if (typeof goBack === 'function') {
        goBack();
    } else {
        // Fallback if navigation helper is unavailable.
        showPage('mode-selection', true, true);
        animateModeSelectionEntry();
    }

    console.log('Retour à la page précédente après annulation');
}

// Setup cancel button listener when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    const cancelBtn = document.getElementById('cancel-scan');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', cancelScan);
    }
});

/**
 * @param {string} level - Scan depth level
 * @param {number} maturityScore - User maturity score
 * @param {string} scanType - Type of scan (network/system)
 */
function startScan(level, maturityScore, scanType = 'network') {
    // Reset cancelled flag
    window.scanCancelled = false;

    animateToScanningPage(() => {
        showPage('scanning', true);
        document.getElementById('scan-level').textContent = level;

        // Hide navbar during scan
        document.body.classList.add('scanning-active');

        // Start the timer
        startScanTimer();

        // Entry animation for scanning page
        animateScanningPageEntry();

        const networkScans = [
            "Initialisation du scan",
            "Analyse des ports réseau",
            "Détection des services actifs",
            "Vérification des vulnérabilités connues",
            "Analyse des configurations réseau",
            "Test des politiques de sécurité",
            "Évaluation des accès et permissions",
            "Génération du rapport"
        ];

        const systemScans = [
            "Initialisation du scan",
            "Analyse du noyau système",
            "Vérification des packages installés",
            "Audit des services actifs",
            "Analyse des configurations système",
            "Test de durcissement (hardening)",
            "Évaluation des permissions et accès",
            "Génération du rapport"
        ];


        const scans = scanType === 'system' ? systemScans : networkScans;

        let progress = 0;
        let Index = 0;
        let itemsScanned = 0;

        // Progress reported by backend (authoritative when available)
        window._lastReportedPercent = null;
        window._lastReportedItems = 0;
        window._lastReportedAt = 0; // timestamp ms

        // Initialize sphere animation after a short delay
        setTimeout(() => {
            if (typeof initSphereAnimation === 'function') {
                initSphereAnimation();
            }
        }, 500);

        // Launch actual Python scan
        let scanStarted = false;
        if (typeof pywebview !== 'undefined' && pywebview.api) {
            console.log(`Lancement du scan ${scanType} via Python...`);

            // Optimistically mark the scan as started so the UI progresses even if
            // the promise resolution is delayed or the bridge is slow.
            scanStarted = true;

            let depth = 1;
            if (level === 'Standard') depth = 2;
            else if (level === 'Approfondi') depth = 3;

            // Launch appropriate scan based on type
            const scanPromise = scanType === 'system'
                ? pywebview.api.start_system_scan(depth)
                : pywebview.api.start_network_scan(null, depth);

            scanPromise.then(response => {
                console.log("Réponse du scan:", response);
                // keep scanStarted true; when onScanComplete is called, UI will finish
            }).catch(error => {
                console.error("Erreur lors du lancement du scan:", error);
                window.onScanError(scanType, error.message || 'Erreur inconnue');
            });
        } else {
            console.warn("API Python non disponible, simulation du scan...");
            // Use simulation path
            scanStarted = false; // leave as false to use faster simulated progress
        }

        window.scanProgressInterval = setInterval(() => {
            try {
                // Check if scan was cancelled
                if (window.scanCancelled) {
                    clearInterval(window.scanProgressInterval);
                    window.scanProgressInterval = null;
                    return;
                }

                if (scanStarted) {
                    const hasReportedProgress = window._lastReportedPercent !== null && window._lastReportedPercent !== undefined;
                    const reportedIsFresh = (Date.now() - (window._lastReportedAt || 0)) < 3000;

                    if (hasReportedProgress && reportedIsFresh) {
                        progress = Math.max(progress, Number(window._lastReportedPercent) || 0);
                        itemsScanned = Math.max(itemsScanned, Number(window._lastReportedItems) || 0);
                    } else {
                        // Keep UI alive if bridge updates are slow; backend values still win when they arrive.
                        progress = Math.min(95, progress + (Math.random() * 2 + 0.5));
                        itemsScanned += Math.floor(Math.random() * 3);
                    }
                    if (progress >= 100) {
                        clearInterval(window.scanProgressInterval);
                        window.scanProgressInterval = null;
                    }
                } else {
                    progress += Math.random() * 15;
                    itemsScanned += Math.floor(Math.random() * 12) + 5;
                    if (progress >= 100) {
                        progress = 100;
                        clearInterval(window.scanProgressInterval);
                        window.scanProgressInterval = null;
                        setTimeout(() => {
                            animateToResultsPage(level, maturityScore);
                            if (typeof updateBackButtonVisibility === 'function') {
                                updateBackButtonVisibility();
                            }
                        }, 1000);
                    }
                }

                // Update text with animation
                if (Index < scans.length) {
                    if (progress > (Index + 1) * (100 / scans.length)) {
                        Index++;
                        const statusElement = document.getElementById('scan-status');
                        if (statusElement) {
                            gsap.to(statusElement, {
                                duration: 0.2,
                                opacity: 0,
                                y: -10,
                                onComplete: () => {
                                    if (Index < scans.length) {
                                        statusElement.textContent = scans[Index];
                                        gsap.to(statusElement, {
                                            duration: 0.3,
                                            opacity: 1,
                                            y: 0,
                                            ease: "power2.out"
                                        });
                                    }
                                }
                            });
                        }
                    }
                }


                const progressFill = document.querySelector('.scan-progress-fill');
                if (progressFill) progressFill.style.width = `${progress}%`;
                const perc = document.querySelector('.scan-percentage');
                if (perc) perc.textContent = `${Math.floor(progress)}%`;
                const itemsEl = document.getElementById('scanned-items');
                if (itemsEl) itemsEl.textContent = itemsScanned;
            } catch (err) {
                console.error('Erreur dans la boucle de progression du scan:', err);
            }
        }, 400);
    });
}

/**
 * @param {Function} onComplete - Callback on animation complete
 */
function animateToScanningPage(onComplete) {
    const timeline = gsap.timeline({onComplete});

    const testCards = document.querySelectorAll('.test-card');
    timeline.to(testCards, {
        duration: 0.5,
        opacity: 0,
        y: -50,
        rotateX: 20,
        scale: 0.8,
        stagger: 0.08,
        ease: "power2.in"
    }, 0);

    const title = document.querySelector('#page-test-selection h1');
    const subtitle = document.querySelector('#page-test-selection .subtitle');
    const scanTypeSelector = document.querySelector('.scan-type-selector');

    timeline.to([title, subtitle], {
        duration: 0.4,
        opacity: 0,
        y: -100,
        ease: "power2.in"
    }, 0.1);

    if (scanTypeSelector) {
        timeline.to(scanTypeSelector, {
            duration: 0.4,
            opacity: 0,
            y: -50,
            ease: "power2.in"
        }, 0.1);
    }

    const blobs = document.querySelectorAll('#page-test-selection .background-blob');
    timeline.to(blobs, {
        duration: 0.6,
        scale: 1.5,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.08
    }, 0.2);
}

/**
 * Animate scanning page entry
 */
function animateScanningPageEntry() {
    const timeline = gsap.timeline();

    const blobs = document.querySelectorAll('#page-scanning .background-blob');
    gsap.set(blobs, {scale: 0, opacity: 0});
    timeline.to(blobs, {
        duration: 1,
        scale: 1,
        opacity: 1,
        ease: "power2.out",
        stagger: 0.15
    }, 0);

    const scannerAnimation = document.querySelector('.scanner-animation');
    gsap.set(scannerAnimation, {scale: 0, opacity: 0, rotateY: 180});
    timeline.to(scannerAnimation, {
        duration: 1.2,
        scale: 1,
        opacity: 1,
        rotateY: 0,
        ease: "back.out(1.4)"
    }, 0.3);

    const title = document.querySelector('.scanning-title');
    gsap.set(title, {opacity: 0, y: -30});
    timeline.to(title, {
        duration: 0.8,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.5);

    const status = document.querySelector('.scanning-subtitle');
    gsap.set(status, {opacity: 0, y: -20});
    timeline.to(status, {
        duration: 0.6,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.7);

    const progressContainer = document.querySelector('.scan-progress');
    gsap.set(progressContainer, {opacity: 0, scaleX: 0});
    timeline.to(progressContainer, {
        duration: 0.7,
        opacity: 1,
        scaleX: 1,
        transformOrigin: "left center",
        ease: "power2.out"
    }, 0.9);

    const details = document.querySelectorAll('.scan-detail-item');
    gsap.set(details, {opacity: 0, x: -30});
    timeline.to(details, {
        duration: 0.5,
        opacity: 1,
        x: 0,
        stagger: 0.1,
        ease: "power2.out"
    }, 1.1);
}

/**
 * @param {string} level - Scan depth level
 * @param {number} maturityScore - User maturity score
 */
function animateToResultsPage(level, maturityScore) {
    const timeline = gsap.timeline({
        onComplete: () => {
            showResults(level, maturityScore);
            if (typeof dropScanningPageFromHistory === 'function') {
                dropScanningPageFromHistory();
            }
        }
    });

    // Shrink sphere
    const scannerAnimation = document.querySelector('.scanner-animation');
    timeline.to(scannerAnimation, {
        duration: 0.6,
        scale: 0,
        opacity: 0,
        rotateY: -180,
        ease: "power2.in"
    }, 0);

    // Title and status
    const title = document.querySelector('.scanning-title');
    const status = document.querySelector('.scanning-subtitle');
    timeline.to([title, status], {
        duration: 0.5,
        opacity: 0,
        y: -50,
        ease: "power2.in"
    }, 0.1);

    // Progress bar explosion effect
    const progressContainer = document.querySelector('.scan-progress');
    timeline.to(progressContainer, {
        duration: 0.5,
        opacity: 0,
        scale: 1.5,
        ease: "power2.in"
    }, 0.2);

    // Details
    const details = document.querySelectorAll('.scan-detail-item');
    timeline.to(details, {
        duration: 0.4,
        opacity: 0,
        x: 50,
        stagger: 0.05,
        ease: "power2.in"
    }, 0.1);


    // Background blobs
    const blobs = document.querySelectorAll('#page-scanning .background-blob');
    timeline.to(blobs, {
        duration: 0.6,
        scale: 0.5,
        opacity: 0,
        ease: "power2.inOut",
        stagger: 0.08
    }, 0.2);
}
