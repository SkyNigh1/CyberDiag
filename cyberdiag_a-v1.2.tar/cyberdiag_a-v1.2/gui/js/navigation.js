const pages = document.querySelectorAll('.page');
const navLinks = document.querySelectorAll('.nav-link');

let currentPage = null;
let isInitialLoad = true;
let pageHistory = [];

const SCANNING_HISTORY_PAGES = new Set(['scanning']);

function prunePageHistory(predicate) {
    pageHistory = pageHistory.filter(pageId => !predicate(pageId));
}

function dropScanningPageFromHistory() {
    prunePageHistory(pageId => SCANNING_HISTORY_PAGES.has(pageId));
    updateBackButtonVisibility();
}

/**
 * Reset all pages to clear residual GSAP inline styles
 * This ensures clean state before page transitions
 */
function resetAllPages() {
    pages.forEach(page => {
        // Clear all GSAP-applied inline styles from page elements
        const allElements = page.querySelectorAll('*');
        allElements.forEach(el => {
            gsap.set(el, {clearProps: 'opacity,transform,visibility,scale,y,x,rotateY'});
        });

        // Reset containers to ensure visibility
        const containers = page.querySelectorAll('.test-selection-container, .results-container, .questionnaire-container, .history-container, .about-container, .mode-selection-container, .scanning-container');
        containers.forEach(container => {
            container.style.opacity = '';
            container.style.visibility = '';
            container.style.transform = '';
        });
    });
}

/**
 * @param {string} pageId - Page identifier
 * @param {boolean} skipAnimation - Skip transition animation
 * @param {boolean} isBackNavigation - Whether this is a back navigation
 */
function showPage(pageId, skipAnimation = false, isBackNavigation = false) {
    const previousPage = currentPage;

    // Track page history for back navigation (unless going back or initial load)
    if (previousPage && previousPage !== pageId && !isBackNavigation) {
        pageHistory.push(previousPage);
    }

    currentPage = pageId;
    updateBackButtonVisibility();

    // Always reset all pages to clear any residual GSAP inline styles
    resetAllPages();

    // Deactivate all pages
    pages.forEach(page => {
        page.classList.remove('active');
    });

    if (skipAnimation) {
        const targetPage = document.getElementById(`page-${pageId}`);
        if (targetPage) {
            targetPage.classList.add('active');

            // reinitializing display elements (opacity)
            const containers = targetPage.querySelectorAll('.test-selection-container, .results-container, .questionnaire-container');
            gsap.set(containers, {opacity: 1, visibility: "visible"});

            const elementsToReset = targetPage.querySelectorAll('.test-card, .mode-card, .gradient-text, h1, .subtitle');
            gsap.set(elementsToReset, {
                clearProps: "opacity,transform,visibility", // On ne nettoie QUE ce qui bloque l'affichage
                opacity: 1,
                visibility: "visible"
            });

            const blobs = targetPage.querySelectorAll('.background-blob');
            gsap.set(blobs, {opacity: 1, scale: 1, clearProps: "all"});
        }
        return;
    }

    isInitialLoad = false;

    const activePage = document.querySelector('.page.active');
    if (activePage && previousPage) {
        animatePageExit(activePage, () => {
            pages.forEach(page => {
                page.classList.remove('active');
            });

            const targetPage = document.getElementById(`page-${pageId}`);
            if (targetPage) {
                targetPage.classList.add('active');
                animatePageEntry(targetPage, pageId);
            }
        });
    } else {
        pages.forEach(page => {
            page.classList.remove('active');
        });

        const targetPage = document.getElementById(`page-${pageId}`);
        if (targetPage) {
            targetPage.classList.add('active');
            animatePageEntry(targetPage, pageId);
        }
    }
}

/**
 * @param {HTMLElement} page - Page element to animate out
 * @param {Function} onComplete - Callback on completion
 */
function animatePageExit(page, onComplete) {
    const timeline = gsap.timeline({
        onComplete: () => {
            // After exit animation, clean all inline styles left by GSAP
            const allElements = page.querySelectorAll('*');
            allElements.forEach(el => {
                gsap.set(el, {clearProps: 'all'});
            });
            if (onComplete) onComplete();
        }
    });

    const blobs = page.querySelectorAll('.background-blob');
    timeline.to(blobs, {
        duration: 0.4,
        scale: 0.5,
        opacity: 0,
        ease: "power2.in",
        stagger: 0.05
    }, 0);

    const mainContent = page.querySelector('.hero, .history-container, .about-container, .results-container, .test-selection-container, .mode-selection-container');
    if (mainContent) {
        timeline.to(mainContent, {
            duration: 0.5,
            opacity: 0,
            y: -30,
            scale: 0.95,
            ease: "power2.in"
        }, 0);
    }
}

/**
 * @param {HTMLElement} page - Page element to animate in
 * @param {string} pageId - Page identifier
 */
function animatePageEntry(page, pageId) {
    const timeline = gsap.timeline();

    const mainContent = page.querySelector('.hero, .history-container, .about-container, .results-container, .test-selection-container');
    if (mainContent) {
        gsap.set(mainContent, {opacity: 1, scale: 1, y: 0, clearProps: 'all'});
    }

    const blobs = page.querySelectorAll('.background-blob');

    if (!(pageId === 'home' && isInitialLoad)) {
        gsap.set(blobs, {scale: 0, opacity: 0});
        timeline.to(blobs, {
            duration: 0.8,
            scale: 1,
            opacity: 1,
            ease: "power2.out",
            stagger: 0.1
        }, 0);
    }

    switch (pageId) {
        case 'home':
            animateHomePage(timeline);
            break;
        case 'history':
            animateHistoryPage(timeline).catch(err => console.error('History animation error:', err));
            break;
        case 'about':
            animateAboutPage(timeline);
            break;
    }
}

/**
 * @param {gsap.core.Timeline} timeline - GSAP timeline
 */
function animateHomePage(timeline) {
    const title = document.querySelector('#page-home h1');
    const subtitle = document.querySelector('#page-home .subtitle');
    const buttons = document.querySelectorAll('#page-home .button');

    if (title) gsap.set(title, {clearProps: "all"});
    if (subtitle) gsap.set(subtitle, {clearProps: "all"});
    buttons.forEach(btn => gsap.set(btn, {clearProps: "all"}));

    if (title) {
        title.style.opacity = '1';
        title.style.pointerEvents = 'auto';
    }
    if (subtitle) {
        subtitle.style.opacity = '1';
    }
    buttons.forEach(btn => {
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
        btn.style.cursor = 'pointer';
        btn.disabled = false;
    });

    if (timeline && !isInitialLoad) {
        timeline.from(title, {
            duration: 0.8,
            opacity: 0,
            y: -30,
            ease: "power2.out",
            clearProps: "all"
        }, 0.1);

        timeline.from(subtitle, {
            duration: 0.6,
            opacity: 0,
            y: -20,
            ease: "power2.out",
            clearProps: "all"
        }, 0.3);

        timeline.from(buttons, {
            duration: 0.6,
            opacity: 0,
            y: 30,
            scale: 0.9,
            stagger: 0.1,
            ease: "back.out(1.4)",
            clearProps: "all"
        }, 0.5);
    }
}

/**
 * @param {gsap.core.Timeline} timeline - GSAP timeline
 */
async function animateHistoryPage(timeline) {
    console.log('[Navigation] animateHistoryPage called');
    const container = document.querySelector('.history-container');
    if (!container) {
        console.error('[Navigation] history-container not found!');
        return;
    }

    gsap.set(container, {opacity: 1, clearProps: 'transform,scale'});

    const title = container.querySelector('h1');
    const filters = container.querySelectorAll('.filter-btn');
    const historyList = container.querySelector('.history-list');

    console.log('[Navigation] Elements found:', {title: !!title, filters: filters.length, historyList: !!historyList});

    if (title) gsap.set(title, {opacity: 1, y: 0, clearProps: 'transform'});
    if (filters.length > 0) gsap.set(filters, {opacity: 1, y: 0, clearProps: 'transform'});
    if (historyList) gsap.set(historyList, {opacity: 1, clearProps: 'transform'});

    if (typeof loadHistory === 'function') {
        console.log('[Navigation] Calling loadHistory()');
        try {
            await loadHistory();
            console.log('[Navigation] loadHistory() completed');
        } catch (err) {
            console.error('[Navigation] loadHistory error:', err);
        }
    } else {
        console.error('[Navigation] loadHistory function not found!');
    }

    if (title) {
        timeline.from(title, {
            duration: 0.8,
            opacity: 0,
            y: -20,
            ease: "power2.out"
        }, 0.2);
    }

    if (filters.length > 0) {
        timeline.from(filters, {
            duration: 0.5,
            opacity: 0,
            y: -10,
            stagger: 0.08,
            ease: "power2.out"
        }, 0.4);
    }

    if (historyList) {
        timeline.from(historyList, {
            duration: 0.6,
            opacity: 0,
            ease: "power2.out"
        }, 0.6);
    }
}

/**
 * @param {gsap.core.Timeline} timeline - GSAP timeline
 */
function animateAboutPage(timeline) {
    const container = document.querySelector('.about-container');
    const title = container.querySelector('h1');
    const sections = container.querySelectorAll('.about-section');

    gsap.set([title, ...sections], {opacity: 0, y: 30});

    timeline.to(title, {
        duration: 0.8,
        opacity: 1,
        y: 0,
        ease: "power2.out"
    }, 0.2);

    timeline.to(sections, {
        duration: 0.7,
        opacity: 1,
        y: 0,
        stagger: 0.2,
        ease: "power2.out"
    }, 0.4);
}

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;

        // showPage now handles full reset of all pages via resetAllPages()
        showPage(page);

        if (page === 'history') {
            if (typeof loadHistory === 'function') {
                loadHistory();
            }
        }
    });
});

/**
 * Update back button visibility
 */
async function updateBackButtonVisibility() {
    const backBtn = document.getElementById('btn-back');
    if (backBtn) {
        let scanInProgress = false;
        if (window.pywebview && window.pywebview.api && window.pywebview.api.is_scan_in_progress) {
            try {
                scanInProgress = await window.pywebview.api.is_scan_in_progress();
            } catch (e) {
                console.error("Erreur lors de la vérification du scan en cours:", e);
            }
        }

        if (currentPage === 'home' || pageHistory.length === 0 || scanInProgress || currentPage === 'scanning') {
            backBtn.style.display = 'none';
        } else {
            backBtn.style.display = 'flex';
        }
    }
}

/**
 * Go back to the previous page
 */
function goBack() {
    while (pageHistory.length > 0) {
        const previousPageId = pageHistory.pop();

        // Skip stale or no-op history entries.
        if (!previousPageId || previousPageId === currentPage) {
            continue;
        }

        // Reset specialized page states if needed
        if (currentPage === 'questionnaire') {
            if (typeof startQuestionnaire === 'function') {
                startQuestionnaire();
            }
        }

        // Since we are going back, we pass true to isBackNavigation
        // to avoid pushing the current page into history again
        showPage(previousPageId, false, true);
        return;
    }

    updateBackButtonVisibility();
}

document.addEventListener('DOMContentLoaded', () => {
    const backBtn = document.getElementById('btn-back');
    if (backBtn) {
        backBtn.addEventListener('click', (e) => {
            e.preventDefault();
            goBack();
        });
    }
});

if (typeof window !== 'undefined') {
    window.showPage = showPage;
    window.goBack = goBack;
    window.dropScanningPageFromHistory = dropScanningPageFromHistory;
    window.dropCancelledTestFlowFromHistory = dropScanningPageFromHistory;
}
