"""
CyberDiag GUI Module

This module provides the graphical user interface components for CyberDiag.
It uses pywebview to create a native desktop application with a modern web-based UI.

Components:
    - webview_external: Main backend API exposed to the JavaScript frontend
    - index.html: Main HTML interface
    - styles.css: Application styling
    - js/: JavaScript modules for frontend functionality

The GUI provides:
    - Scan configuration and execution
    - Real-time progress tracking
    - Results visualization with risk assessment
    - Scan history management
"""

from gui.webview_external import launch_webview, ScanAPI

__all__ = ["launch_webview", "ScanAPI"]
