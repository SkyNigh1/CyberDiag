"""
Tests for cyberdiag.py main entry point
"""
from unittest.mock import patch

# Import the main module
import cyberdiag


class TestMain:
    """Tests for the main entry point."""

    @patch("cyberdiag.launch_webview")
    @patch("cyberdiag._ensure_root")
    @patch("cyberdiag.setup_logging")
    def test_main_calls_all_functions(self, mock_setup, mock_root, mock_launch):
        """Test that main() calls setup_logging, _ensure_root, and launch_webview."""
        cyberdiag.main()

        mock_setup.assert_called_once()
        mock_root.assert_called_once()
        mock_launch.assert_called_once_with(
            window_title="CyberDiag - Analyse de Sécurité v1.0"
        )

    @patch("cyberdiag.launch_webview")
    @patch("cyberdiag._ensure_root")
    @patch("cyberdiag.setup_logging")
    def test_main_order_of_calls(self, mock_setup, mock_root, mock_launch):
        """Test that functions are called in the correct order."""
        call_order = []

        def track_setup():
            call_order.append("setup_logging")

        def track_root():
            call_order.append("ensure_root")

        def track_launch(**kwargs):
            call_order.append("launch_webview")

        mock_setup.side_effect = track_setup
        mock_root.side_effect = track_root
        mock_launch.side_effect = track_launch

        cyberdiag.main()

        assert call_order == ["setup_logging", "ensure_root", "launch_webview"]
