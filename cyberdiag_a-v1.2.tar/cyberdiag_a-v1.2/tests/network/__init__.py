"""Network tests package for CyberDiag."""
