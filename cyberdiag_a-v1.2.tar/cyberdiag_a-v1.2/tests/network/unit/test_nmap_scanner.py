"""
Comprehensive unit tests for network/nmap_call.py

This module consolidates all tests for the NmapScanner class.
"""
from unittest.mock import patch, MagicMock

import pytest

from network.nmap_call import NmapScanner


# =============================================================================
# Initialization Tests
# =============================================================================

class TestNmapScannerInit:
    """Tests for NmapScanner initialization."""

    def test_depth_1(self):
        """Test NmapScanner accepts depth 1."""
        scanner = NmapScanner("10.0.0.1", 1)
        assert scanner.depth == 1
        assert scanner.target == "10.0.0.1"

    def test_depth_2(self):
        """Test NmapScanner accepts depth 2."""
        scanner = NmapScanner("192.168.1.0/24", 2)
        assert scanner.depth == 2
        assert scanner.target == "192.168.1.0/24"

    def test_depth_3(self):
        """Test NmapScanner accepts depth 3."""
        scanner = NmapScanner("scanme.nmap.org", 3)
        assert scanner.depth == 3
        assert scanner.target == "scanme.nmap.org"

    def test_invalid_depth_0(self):
        """Test NmapScanner rejects depth 0."""
        with pytest.raises(ValueError, match="Depth must be 1, 2, or 3"):
            NmapScanner("127.0.0.1", 0)

    def test_invalid_depth_4(self):
        """Test NmapScanner rejects depth 4."""
        with pytest.raises(ValueError, match="Depth must be 1, 2, or 3"):
            NmapScanner("127.0.0.1", 4)

    def test_invalid_depth_negative(self):
        """Test NmapScanner rejects negative depth."""
        with pytest.raises(ValueError, match="Depth must be 1, 2, or 3"):
            NmapScanner("127.0.0.1", -1)


# =============================================================================
# Scan Method Tests
# =============================================================================

class TestNmapScannerScan:
    """Tests for NmapScanner scan method."""

    def _create_mock_popen(self):
        mock = MagicMock()
        # Mock readline to return lines then empty string forever
        payload = ["line1\n", "line2\n"]
        iterator = iter(payload)

        def side_effect():
            try:
                return next(iterator)
            except StopIteration:
                return ""

        mock.stdout.readline.side_effect = side_effect

        # Mock poll to simulate running then finished
        mock.poll.side_effect = [None, None, 0]
        mock.returncode = 0
        return mock

    @patch("shutil.which")
    @patch("subprocess.Popen")
    def test_run_success(self, mock_popen, mock_which):
        """Test successful scan."""
        mock_which.return_value = "/usr/bin/nmap"
        mock_process = self._create_mock_popen()
        mock_popen.return_value = mock_process

        scanner = NmapScanner("127.0.0.1", 1)
        success = scanner.run("output.xml")

        assert success is True
        mock_popen.assert_called_once()
        args, kwargs = mock_popen.call_args
        cmd = args[0]
        assert "nmap" in cmd
        assert "127.0.0.1" in cmd
        assert "output.xml" in cmd

    @patch("shutil.which")
    def test_run_no_nmap(self, mock_which):
        """Test run fails if nmap is missing."""
        mock_which.return_value = None
        scanner = NmapScanner("127.0.0.1", 1)
        success = scanner.run("output.xml")
        assert success is False

    @patch("shutil.which")
    @patch("subprocess.Popen")
    def test_run_failure(self, mock_popen, mock_which):
        """Test run returns False on non-zero exit code."""
        mock_which.return_value = "/usr/bin/nmap"
        mock_process = self._create_mock_popen()
        mock_process.returncode = 1
        # Fix poll side effect for failure case
        # We need it to return None initially (running), then return code (finished)
        mock_process.poll.side_effect = [None, None, 1]
        mock_popen.return_value = mock_process

        scanner = NmapScanner("127.0.0.1", 1)
        result = scanner.run("output.xml")

        assert result is False

    @patch("shutil.which")
    @patch("subprocess.Popen")
    def test_progress_callback(self, mock_popen, mock_which):
        """Test progress callback is called."""
        mock_which.return_value = "/usr/bin/nmap"

        mock_process = MagicMock()
        payload = [
            "Starting Nmap...\n",
            "Stats: 0:00:06 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan\n",
            "Service Scan Timing: About 50.00% done; ETC: 12:00 (0:00:06 remaining)\n"
        ]
        iterator = iter(payload)

        def side_effect():
            try:
                return next(iterator)
            except StopIteration:
                return ""

        mock_process.stdout.readline.side_effect = side_effect

        mock_process.poll.side_effect = [None, None, None, 0]
        mock_process.returncode = 0
        mock_popen.return_value = mock_process

        scanner = NmapScanner("127.0.0.1", 1)
        callback = MagicMock()

        scanner.run("output.xml", progress_callback=callback)

        # Check if the callback was called with the expected progress strings
        assert callback.call_count == 3

        # Verify call args manually because percent might vary or be 0.0
        calls = callback.call_args_list
        messages = [args[0] for args, _ in calls]

        assert "Starting Nmap..." in messages
        assert "Stats: 0:00:06 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan" in messages
        assert "Service Scan Timing: About 50.00% done; ETC: 12:00 (0:00:06 remaining)" in messages

        # Check if 50% was parsed correctly
        found_50 = False
        for args, _ in calls:
            if args[1] == 50.0:
                found_50 = True
        assert found_50


# =============================================================================
# Depth-Specific Command Tests
# =============================================================================

class TestNmapScannerDepthCommands:
    """Tests for NmapScanner depth-specific command generation."""

    def test_depth_1_command(self):
        scanner = NmapScanner("192.168.1.1", 1)
        cmd = scanner.build_command("out.xml")

        assert "nmap" in cmd
        assert "-sS" in cmd
        assert "-sV" in cmd
        assert "--top-ports" in cmd
        assert "100" in cmd
        assert "192.168.1.1" in cmd

    def test_depth_2_command(self):
        scanner = NmapScanner("10.0.0.0/24", 2)
        cmd = scanner.build_command("out.xml")

        assert "nmap" in cmd
        assert "--top-ports" in cmd
        assert "750" in cmd
        assert "--script" in cmd
        assert "vuln and not intrusive" in cmd

    def test_depth_3_command(self):
        scanner = NmapScanner("target.com", 3)
        cmd = scanner.build_command("out.xml")

        assert "nmap" in cmd
        assert "-sC" in cmd
        assert "-A" in cmd
        assert "--script" in cmd
        assert "vuln,exploit,auth" in cmd
        assert "--version-intensity" in cmd
        assert "9" in cmd
