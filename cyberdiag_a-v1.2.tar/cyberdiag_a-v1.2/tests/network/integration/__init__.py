"""Integration tests for the network module."""
