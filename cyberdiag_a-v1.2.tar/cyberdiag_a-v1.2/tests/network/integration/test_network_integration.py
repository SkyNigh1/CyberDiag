from unittest.mock import patch, MagicMock

from network.networkScanAnalysis import parse_xml
from network.nmap_call import NmapScanner


class TestNetworkIntegration:
    """Integration tests for the network module."""

    def test_nmap_to_analysis_flow(self, tmp_path):
        """Test the flow from scan execution to XML parsing and JSON analysis."""
        output_xml = tmp_path / "output.xml"

        # 1. Create a fake XML file that nmap would produce
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<nmaprun scanner="nmap" args="nmap -oX - 127.0.0.1" start="1636928046" version="7.95">
<host>
<status state="up" reason="localhost-response"/>
<address addr="127.0.0.1" addrtype="ipv4"/>
<ports><port protocol="tcp" portid="22"><state state="open"/><service name="ssh"/></port></ports>
<os><osmatch name="Linux 5.x" accuracy="100"/></os>
<tcpsequence index="250" difficulty="Good luck!"/>
<ipidsequence class="All zeros"/>
</host>
<runstats><finished exit="success"/></runstats>
</nmaprun>
"""

        with patch("shutil.which", return_value="/usr/bin/nmap"), \
                patch("subprocess.Popen") as mock_popen:
            # Setup mock process
            mock_process = MagicMock()
            mock_process.stdout.readline.side_effect = [
                "Starting Nmap 7.95 ...",
                "Nmap scan report for localhost (127.0.0.1)",
                "",  # End of output
                ""  # Consistent end of output
            ]

            # poll() should return None a few times then 0
            # 1. After first "" -> returns None -> continue
            # 2. After second "" -> returns 0 -> break
            mock_process.poll.side_effect = [None, 0]
            mock_process.returncode = 0

            mock_popen.return_value = mock_process

            # Write fake XML when run is called (simulating nmap -oX)
            # But the Popen is mocked, so we must write the file manually 
            # or side_effect on Popen? Popen just starts process.
            # We can write the file before calling scan since valid XML is needed for parse_xml later.
            # But scanner.run() expects nmap to create it.
            # In unit test, since we mock nmap, we must ensure the file is created.
            output_xml.write_text(xml_content)

            scanner = NmapScanner("127.0.0.1", 1)
            success = scanner.run(str(output_xml))

            assert success is True
            assert output_xml.exists()

            # 2. Parse the produced XML
            data = parse_xml(str(output_xml))
            assert len(data) == 1
            assert data[0]["ip"] == "127.0.0.1"
            assert data[0]["OS"] == "Linux 5.x"
            assert any(p["port"] == "22" for p in data[0]["ports_ouverts"])
