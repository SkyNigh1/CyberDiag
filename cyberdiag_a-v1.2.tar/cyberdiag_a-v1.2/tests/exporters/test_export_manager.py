import json
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from exporters.export_manager import (
    _compute_network_score,
    _build_network_stats,
    export_scan
)


class TestNetworkScore:
    def test_empty_scan_data(self):
        """Should return None or handle empty list gracefully."""
        assert _compute_network_score([]) == 100
        # Wait, looking at the code:
        # total_hosts = max(1, len(scan_data)) -> 1
        # findings = []
        # score = 100
        # host_risk_ratio = 0 / 1 = 0
        # score -= 0
        # return 100

        # But looking at code:
        # if not isinstance(scan_data, list): return None
        assert _compute_network_score(None) is None
        assert _compute_network_score({}) is None

    def test_critical_vulnerability(self):
        scan_data = [{
            "vulnerabilities": [{"criticite": "CRITIQUE"}],
            "ports_ouverts": []
        }]
        # 1 host, 1 critical finding.
        # score = 100 - 20 (critical) = 80
        # hosts_with_issues = 1
        # host_risk_ratio = 1/1 = 1
        # score -= round(1 * 10) = 10
        # Missing tcp/ipid sequence -> 2 low findings -> -2
        # final = 70 - 2 = 68
        assert _compute_network_score(scan_data) == 68

    def test_high_vulnerability(self):
        scan_data = [{
            "vulnerabilities": [{"criticite": "ELEVEE"}],
            "ports_ouverts": []
        }]
        # score = 100 - 12 (high) - 10 (risk ratio) = 78
        # Missing tcp/ipid sequence -> 2 low findings -> -2
        # final = 78 - 2 = 76
        assert _compute_network_score(scan_data) == 76

    def test_multiple_findings(self):
        scan_data = [{
            "vulnerabilities": [
                {"criticite": "CRITIQUE"},
                {"criticite": "ELEVEE"}
            ],
            "ports_ouverts": [
                {"criticite": "MOYENNE", "nombre_exploits": 0}
            ],
            "criticite_tcpsequence": "FAIBLE",
            "criticite_ipidsequence": "FAIBLE"
        }]
        # critical: 1 -> -20
        # high: 1 -> -12
        # medium: 1 -> -6
        # low: 2 -> -2  (tcp/ipid explicit)
        # total deduction: 40
        # risk ratio: 1/1 -> -10
        # score: 100 - 40 - 10 = 50
        assert _compute_network_score(scan_data) == 50

    def test_exploits_impact(self):
        scan_data = [{
            "ports_ouverts": [
                {"criticite": "FAIBLE", "nombre_exploits": 5}
            ]
        }]
        # low: 1 -> -1 (port)
        # low: 2 -> -2 (tcp/ipid implicit)
        # exploits: 5
        # score -= min(25, round(log1p(5) * 6))
        # log1p(5) = ln(6) ≈ 1.79
        # 1.79 * 6 ≈ 10.75 -> 11
        # risk ratio: 1/1 -> -10
        # score: 100 - 3 - 11 - 10 = 76
        expected_score = 100 - 3 - 11 - 10
        assert _compute_network_score(scan_data) == expected_score


class TestNetworkStats:
    def test_empty_stats(self):
        stats = _build_network_stats([])
        assert stats == {
            "total_hosts": 0,
            "total_ports": 0,
            "total_exploits": 0,
            "hosts_with_issues": 0,
        }

    def test_stats_calculation(self):
        scan_data = [
            {
                "ports_ouverts": [
                    {"criticite": "CRITIQUE", "nombre_exploits": 2},
                    {"criticite": "FAIBLE", "nombre_exploits": 0}
                ],
                "vulnerabilities": []
            },
            {
                "ports_ouverts": [],
                "vulnerabilities": [{"criticite": "ELEVEE"}]
            },
            {
                "ports_ouverts": [],  # No issues
                "vulnerabilities": []
            }
        ]

        stats = _build_network_stats(scan_data)
        assert stats["total_hosts"] == 3
        assert stats["total_ports"] == 2
        assert stats["total_exploits"] == 2
        assert stats["hosts_with_issues"] == 2  # Host 1 (crit port) and Host 2 (vuln)


class TestExportScan:
    @pytest.fixture
    def mock_dependencies(self):
        with (
            patch("exporters.export_manager.get_project_root") as mock_root,
            patch("exporters.export_manager.weasyprint.HTML") as mock_html,
            patch("exporters.export_manager.datetime") as mock_date,
            patch("exporters.export_manager.uuid.uuid4") as mock_uuid,
        ):
            yield mock_root, mock_html, mock_date, mock_uuid

    def test_export_scan_network(self, mock_dependencies, tmp_path):
        mock_root, mock_html, mock_date, mock_uuid = mock_dependencies

        # Setup mocks
        mock_root.return_value = tmp_path
        fixed_date = datetime(2023, 1, 1, 12, 0, 0)
        mock_date.now.return_value = fixed_date
        mock_date.strptime = datetime.strptime  # Keep original strptime if needed
        mock_date.strftime = datetime.strftime
        mock_uuid.return_value = "12345678-1234-5678-1234-567812345678"

        scan_data = [{"ports_ouverts": [], "vulnerabilities": []}]

        # Determine expected paths
        scan_id = "20230101_120000_12345678"
        expected_dir = tmp_path / "result" / scan_id

        # Execute
        result = export_scan("network", scan_data)

        # Assertions
        assert result["scan_id"] == scan_id
        assert result["scan_type"] == "network"
        assert Path(result["json"]).exists()
        assert Path(result["html"]).exists()

        # Verify JSON content
        with open(result["json"], "r") as f:
            data = json.load(f)
            assert data == scan_data

        # Verify HTML content (basic check)
        with open(result["html"], "r") as f:
            html_content = f.read()
            assert "CyberDiag" in html_content
            assert scan_id in html_content

        # Verify PDF generation was called
        mock_html.assert_called_once()
        mock_html.return_value.write_pdf.assert_called_once()

    def test_export_scan_system(self, mock_dependencies, tmp_path):
        mock_root, mock_html, mock_date, mock_uuid = mock_dependencies

        mock_root.return_value = tmp_path
        fixed_date = datetime(2023, 1, 1, 12, 0, 0)
        mock_date.now.return_value = fixed_date
        mock_uuid.return_value = "abcdefgh-1234-5678-1234-567812345678"

        scan_data = {
            "security_score": 85,
            "details": "some system details",
            "summary": {
                "total_tests": 12,
                "warnings": 2,
                "suggestions": 5
            }
        }

        result = export_scan("system", scan_data)

        assert result["scan_type"] == "system"
        # Since PDF mock doesn't actually write file, check path logic in code
        # export_scan returns pdf path if exists, else None.
        # weasyprint mock does not write file to disk unless we make it.
        # But we want to test return value.

        # If we want pdf path to be returned, we must simulate file existence OR 
        # rely on the fact that `write_pdf` is called. 
        # Actually export_manager checks `if pdf_path.exists()`.
        # So we need to create the dummy PDF file in our mock side effect if we want it to return the path.

        # Alternatively, let's just assert that HTML is generated and write_pdf is called.
        # The return value for PDF might be None because file is not created by mock.

        mock_html.assert_called()

    def test_export_scan_system_missing_summary(self, mock_dependencies, tmp_path):
        mock_root, mock_html, mock_date, mock_uuid = mock_dependencies

        mock_root.return_value = tmp_path
        mock_date.now.return_value = datetime(2023, 1, 1, 12, 0, 0)
        mock_uuid.return_value = "missing-summary-test"

        # Missing summary key
        scan_data = {"security_score": 50}

        # Should not raise UndefinedError
        export_scan("system", scan_data)

        # Verify summary was added to scan_data (side effect check, optional but good to know)
        assert "summary" in scan_data
        assert scan_data["summary"]["total_tests"] == 0

