"""
Comprehensive unit tests for gui/webview_external.py

This module consolidates all webview tests for the ScanAPI class and
related helper functions.
"""
import json
import socket
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from gui.webview_external import (
    ScanAPI,
    _get_project_root,
    _get_window,
    _notify_progress,
    _get_networkscan_analysis,
    _get_lynis_interface,
    _get_local_network_cidr,
    _cleanup_processes,
)


@pytest.fixture
def no_background_threads(monkeypatch):
    """Replace threading.Thread with a no-op stub for start_*_scan API tests."""

    class _NoopThread:
        def __init__(self, target=None, daemon=None, *args, **kwargs):
            self.target = target
            self.daemon = daemon

        def start(self):
            return None

    monkeypatch.setattr("gui.webview_external.threading.Thread", _NoopThread)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def scan_api():
    """Create a fresh ScanAPI instance for testing."""
    return ScanAPI()


@pytest.fixture
def mock_results_dir(tmp_path):
    """Create a mock unified results directory."""
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True)
    return results_dir


# =============================================================================
# Helper Functions Tests
# =============================================================================

class TestLazyLoaders:
    """Tests for lazy loading functions."""

    def test_get_networkscan_analysis(self):
        """Test lazy loading of network scan analysis module."""
        import gui.webview_external as webview_module
        webview_module._networkscan_analysis = None

        result = _get_networkscan_analysis()
        assert result is not None
        assert callable(result)

    def test_get_lynis_interface(self):
        """Test lazy loading of Lynis interface module."""
        import gui.webview_external as webview_module
        webview_module._LynisInterface = None

        result = _get_lynis_interface()
        assert result is not None


class TestGetProjectRoot:
    """Tests for _get_project_root function."""

    def test_returns_path(self):
        """Test _get_project_root returns a Path object."""
        result = _get_project_root()
        assert isinstance(result, Path)
        assert result.exists()

    def test_is_cached(self):
        """Test _get_project_root returns cached result."""
        result1 = _get_project_root()
        result2 = _get_project_root()
        assert result1 is result2


class TestGetWindow:
    """Tests for _get_window function."""

    def test_returns_main_window_if_set(self):
        """Test _get_window returns _MAIN_WINDOW when set."""
        import gui.webview_external as module

        mock_window = MagicMock()
        original = module._MAIN_WINDOW
        module._MAIN_WINDOW = mock_window

        try:
            result = _get_window()
            assert result is mock_window
        finally:
            module._MAIN_WINDOW = original

    @patch("webview.windows", [MagicMock()])
    def test_returns_first_window(self):
        """Test _get_window returns first webview window when no main window."""
        import gui.webview_external as module

        original = module._MAIN_WINDOW
        module._MAIN_WINDOW = None

        try:
            result = _get_window()
            assert result is not None
        finally:
            module._MAIN_WINDOW = original

    def test_returns_none_when_no_windows(self):
        """Test _get_window returns None when no windows available."""
        import gui.webview_external as module

        original = module._MAIN_WINDOW
        module._MAIN_WINDOW = None

        with patch("webview.windows", []):
            result = _get_window()
            assert result is None

        module._MAIN_WINDOW = original


class TestNotifyProgress:
    """Tests for _notify_progress function."""

    def test_calls_evaluate_js(self):
        """Test _notify_progress calls window.evaluate_js."""
        mock_window = MagicMock()
        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("network", 50, 10)

        mock_window.evaluate_js.assert_called_once()
        js_call = mock_window.evaluate_js.call_args[0][0]
        assert "onScanProgress" in js_call
        assert "network" in js_call
        assert "50" in js_call

    def test_handles_none_window(self):
        """Test _notify_progress handles None window gracefully."""
        with patch("gui.webview_external._get_window", return_value=None):
            _notify_progress("system", 75, 5)  # Should not raise

    def test_handles_none_percent(self):
        """Test _notify_progress handles None percent."""
        mock_window = MagicMock()
        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("network", None, 0)

        mock_window.evaluate_js.assert_called_once()
        js_call = mock_window.evaluate_js.call_args[0][0]
        assert "0.0" in js_call or "0" in js_call

    def test_handles_exception(self):
        """Test _notify_progress catches exceptions."""
        mock_window = MagicMock()
        mock_window.evaluate_js.side_effect = Exception("JS error")

        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("network", 50, 0)  # Should not raise

    def test_with_zero_items(self):
        """Test _notify_progress with zero items."""
        mock_window = MagicMock()
        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("system", 50, 0)

        mock_window.evaluate_js.assert_called_once()
        js_call = mock_window.evaluate_js.call_args[0][0]
        assert "0" in js_call

    def test_with_100_percent(self):
        """Test _notify_progress with 100% progress."""
        mock_window = MagicMock()
        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("network", 100, 255)

        mock_window.evaluate_js.assert_called_once()
        js_call = mock_window.evaluate_js.call_args[0][0]
        assert "100" in js_call

    def test_handles_float_values(self):
        """Test _notify_progress handles float items."""
        mock_window = MagicMock()
        with patch("gui.webview_external._get_window", return_value=mock_window):
            _notify_progress("network", 50.5, 10.7)

        mock_window.evaluate_js.assert_called_once()


class TestGetLocalNetworkCidr:
    """Tests for _get_local_network_cidr function."""

    def test_success(self):
        """Test successful network CIDR detection."""
        mock_socket = MagicMock()
        mock_socket.getsockname.return_value = ("192.168.1.100", 12345)

        with patch("socket.socket") as mock_sock_class:
            mock_sock_class.return_value.__enter__.return_value = mock_socket
            mock_sock_class.return_value.__exit__.return_value = None
            result = _get_local_network_cidr()

        assert result == "192.168.1.0/24"

    def test_socket_error_fallback(self):
        """Test fallback to localhost on socket error."""
        with patch("socket.socket") as mock_sock_class:
            mock_sock_class.side_effect = socket.error("Network unreachable")
            result = _get_local_network_cidr()

        assert result == "127.0.0.1"

    def test_os_error_fallback(self):
        """Test fallback to localhost on OSError."""
        with patch("socket.socket") as mock_sock_class:
            mock_sock_class.side_effect = OSError("Connection refused")
            result = _get_local_network_cidr()

        assert result == "127.0.0.1"

    def test_10_network(self):
        """Test CIDR detection for 10.x.x.x networks."""
        mock_socket = MagicMock()
        mock_socket.getsockname.return_value = ("10.0.5.42", 12345)

        with patch("socket.socket") as mock_sock_class:
            mock_sock_class.return_value.__enter__.return_value = mock_socket
            mock_sock_class.return_value.__exit__.return_value = None
            result = _get_local_network_cidr()

        assert result == "10.0.5.0/24"

    def test_172_network(self):
        """Test CIDR detection for 172.16.x.x networks."""
        mock_socket = MagicMock()
        mock_socket.getsockname.return_value = ("172.16.20.150", 12345)

        with patch("socket.socket") as mock_sock_class:
            mock_sock_class.return_value.__enter__.return_value = mock_socket
            mock_sock_class.return_value.__exit__.return_value = None
            result = _get_local_network_cidr()

        assert result == "172.16.20.0/24"


class TestCleanupProcesses:
    """Tests for _cleanup_processes function."""

    def test_terminates_running_process(self):
        """Test cleanup terminates running processes."""
        api = ScanAPI()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None  # Process still running
        mock_proc.pid = 12345
        api._active_processes = [mock_proc]

        _cleanup_processes(api)

        mock_proc.terminate.assert_called_once()
        assert api._active_processes == []

    def test_skips_terminated_process(self):
        """Test cleanup skips already terminated processes."""
        api = ScanAPI()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = 0  # Already terminated
        api._active_processes = [mock_proc]

        _cleanup_processes(api)

        mock_proc.terminate.assert_not_called()
        assert api._active_processes == []

    def test_force_kills_on_timeout(self):
        """Test cleanup force kills stubborn processes."""
        api = ScanAPI()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.pid = 12345
        mock_proc.wait.side_effect = [subprocess.TimeoutExpired("cmd", 2), None]
        api._active_processes = [mock_proc]

        _cleanup_processes(api)

        mock_proc.terminate.assert_called_once()
        mock_proc.kill.assert_called_once()
        assert api._active_processes == []

    def test_handles_exception(self):
        """Test cleanup handles exceptions gracefully."""
        api = ScanAPI()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.pid = 12345
        mock_proc.terminate.side_effect = OSError("Process not found")
        api._active_processes = [mock_proc]

        _cleanup_processes(api)  # Should not raise
        assert api._active_processes == []

    def test_handles_empty_list(self):
        """Test cleanup handles empty process list."""
        api = ScanAPI()
        api._active_processes = []

        _cleanup_processes(api)  # Should not raise
        assert api._active_processes == []

    def test_multiple_processes(self):
        """Test cleanup terminates multiple processes."""
        api = ScanAPI()
        mock_proc1 = MagicMock()
        mock_proc1.poll.return_value = None
        mock_proc1.pid = 12345

        mock_proc2 = MagicMock()
        mock_proc2.poll.return_value = None
        mock_proc2.pid = 12346

        mock_proc3 = MagicMock()
        mock_proc3.poll.return_value = 0  # Already done

        api._active_processes = [mock_proc1, mock_proc2, mock_proc3]

        _cleanup_processes(api)

        mock_proc1.terminate.assert_called_once()
        mock_proc2.terminate.assert_called_once()
        mock_proc3.terminate.assert_not_called()
        assert api._active_processes == []


# =============================================================================
# ScanAPI Tests
# =============================================================================

class TestScanAPIInit:
    """Tests for ScanAPI initialization."""

    def test_defaults(self):
        """Test ScanAPI initializes with correct defaults."""
        api = ScanAPI()

        assert api.scan_in_progress is False
        assert api.scan_cancelled is False
        assert api.last_network_scan is None
        assert api.last_system_scan is None
        assert api._active_processes == []


class TestScanAPIListScans:
    """Tests for ScanAPI.list_scans method."""

    def test_list_scans_with_mock(self):
        """Test list_scans from mocked unified history entries."""
        api = ScanAPI()
        fake_scans = [
            {
                "type": "network",
                "path": "/tmp/results/scan1/data.json",
                "filename": "scan1",
                "date": "2026-01-01T10:00:00",
            }
        ]

        with patch.object(api, "get_scan_history", return_value=fake_scans):
            scans = api.list_scans("network")

        assert "network" in scans
        assert "system" in scans
        assert len(scans["network"]) == 1

    def test_list_scans_all(self, mock_results_dir):
        """Test listing all scan types."""
        api = ScanAPI()

        (mock_results_dir / "20250115_103000_aaaaaaaa").mkdir()
        (mock_results_dir / "20250115_103000_aaaaaaaa" / "data.json").write_text('[]')
        (mock_results_dir / "20250115_110000_bbbbbbbb").mkdir()
        (mock_results_dir / "20250115_110000_bbbbbbbb" / "data.json").write_text('{"summary": {}}')

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.list_scans("all")

        assert len(result["network"]) == 1
        assert len(result["system"]) == 1

    def test_list_scans_network_only(self, mock_results_dir):
        """Test listing network scans only."""
        api = ScanAPI()

        (mock_results_dir / "20250115_103000_aaaaaaaa").mkdir()
        (mock_results_dir / "20250115_103000_aaaaaaaa" / "data.json").write_text('[]')

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.list_scans("network")

        assert len(result["network"]) == 1
        assert len(result["system"]) == 0

    def test_list_scans_system_only(self, mock_results_dir):
        """Test listing system scans only."""
        api = ScanAPI()

        (mock_results_dir / "20250115_110000_bbbbbbbb").mkdir()
        (mock_results_dir / "20250115_110000_bbbbbbbb" / "data.json").write_text('{"summary": {}}')

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.list_scans("system")

        assert len(result["network"]) == 0
        assert len(result["system"]) == 1

    def test_list_scans_no_directories(self, tmp_path):
        """Test listing scans when directories don't exist."""
        api = ScanAPI()

        with patch("gui.webview_external._get_project_root", return_value=tmp_path):
            result = api.list_scans("all")

        assert result["network"] == []
        assert result["system"] == []


class TestScanAPIGetScanData:
    """Tests for ScanAPI.get_scan_data method."""

    def test_valid_file(self, tmp_path):
        """Test get_scan_data loads valid JSON file."""
        mock_data = {"test": "data"}
        json_file = tmp_path / "test.json"
        json_file.write_text(json.dumps(mock_data))

        api = ScanAPI()
        data = api.get_scan_data(str(json_file))
        assert data == mock_data

    def test_invalid_json(self, tmp_path):
        """Test get_scan_data returns None for invalid JSON."""
        api = ScanAPI()
        json_file = tmp_path / "invalid.json"
        json_file.write_text("not valid json {")

        result = api.get_scan_data(str(json_file))
        assert result is None

    def test_nonexistent_file(self, tmp_path):
        """Test get_scan_data returns None for nonexistent file."""
        api = ScanAPI()

        result = api.get_scan_data(str(tmp_path / "nonexistent.json"))
        assert result is None


class TestScanAPIGetScanHistory:
    """Tests for ScanAPI.get_scan_history method."""

    def test_with_network_files(self, mock_results_dir):
        """Test get_scan_history finds network scans."""
        scan_dir = mock_results_dir / "20251114_223842_aaaaaaaa"
        scan_dir.mkdir()
        net_file = scan_dir / "data.json"
        net_file.write_text(json.dumps([{"ip": "127.0.0.1"}]))

        api = ScanAPI()
        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            scans = api.get_scan_history()
            assert len(scans) == 1

    def test_empty_directories(self, mock_results_dir):
        """Test get_scan_history returns empty list when no scans."""
        api = ScanAPI()

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.get_scan_history()
            assert result == []

    def test_no_results_dirs(self, tmp_path):
        """Test get_scan_history when results directories don't exist."""
        api = ScanAPI()

        with patch("gui.webview_external._get_project_root", return_value=tmp_path):
            result = api.get_scan_history()

        assert result == []

    def test_with_system_scans(self, mock_results_dir):
        """Test get_scan_history finds system scans."""
        api = ScanAPI()
        scan_dir = mock_results_dir / "20250115_110000_bbbbbbbb"
        scan_dir.mkdir()
        scan_file = scan_dir / "data.json"
        scan_file.write_text('{"summary": {}}')

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.get_scan_history()

        assert len(result) == 1
        assert result[0]["type"] == "system"

    def test_date_parsing_fallback(self, mock_results_dir):
        """Test get_scan_history uses file mtime date metadata."""
        api = ScanAPI()

        scan_dir = mock_results_dir / "custom_scan_folder"
        scan_dir.mkdir()
        scan_file = scan_dir / "data.json"
        scan_file.write_text('{"test": "data"}')

        with patch("gui.webview_external._get_project_root", return_value=mock_results_dir.parent):
            result = api.get_scan_history()

        assert len(result) == 1
        assert "date" in result[0]


class TestScanAPICancelScan:
    """Tests for ScanAPI.cancel_scan method."""

    def test_no_scan_in_progress(self):
        """Test cancel_scan returns error when no scan running."""
        api = ScanAPI()
        api.scan_in_progress = False

        result = api.cancel_scan()
        assert result["success"] is False
        assert "Aucun scan" in result["message"]

    def test_terminates_processes(self, scan_api):
        """Test cancel_scan terminates active processes."""
        scan_api.scan_in_progress = True

        mock_proc = MagicMock()
        mock_proc.poll.return_value = None  # Still running
        scan_api._active_processes = [mock_proc]

        result = scan_api.cancel_scan()

        assert result["success"] is True
        mock_proc.terminate.assert_called_once()
        assert scan_api.scan_in_progress is False
        assert scan_api.scan_cancelled is False

    def test_kills_stubborn_process(self):
        """Test cancel_scan kills process that doesn't terminate."""
        api = ScanAPI()
        api.scan_in_progress = True

        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.wait.side_effect = [subprocess.TimeoutExpired("cmd", 2), None]
        api._active_processes = [mock_proc]

        result = api.cancel_scan()

        assert result["success"] is True
        mock_proc.kill.assert_called_once()

    def test_process_already_terminated(self):
        """Test cancel_scan when process has already terminated."""
        api = ScanAPI()
        api.scan_in_progress = True

        mock_proc = MagicMock()
        mock_proc.poll.return_value = 0  # Process already finished
        api._active_processes = [mock_proc]

        result = api.cancel_scan()

        assert result["success"] is True
        mock_proc.terminate.assert_not_called()

    def test_terminate_exception(self):
        """Test cancel_scan handles terminate exception."""
        api = ScanAPI()
        api.scan_in_progress = True

        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.terminate.side_effect = ProcessLookupError("Process not found")
        api._active_processes = [mock_proc]

        result = api.cancel_scan()

        assert result["success"] is True
        assert api.scan_in_progress is False


class TestScanAPIStartNetworkScan:
    """Tests for ScanAPI.start_network_scan method."""

    def test_already_running(self, no_background_threads):
        """Test start_network_scan returns error if scan already running."""
        api = ScanAPI()
        api.scan_in_progress = True

        result = api.start_network_scan()

        assert result["success"] is False
        assert "déjà en cours" in result["message"]

    def test_auto_target(self, no_background_threads):
        """Test start_network_scan with 'auto' target."""
        api = ScanAPI()

        with patch.object(api, "scan_in_progress", False):
            with patch("gui.webview_external._get_local_network_cidr", return_value="192.168.1.0/24"):
                result = api.start_network_scan(target="auto", depth=1)

        assert result["success"] is True
        assert "started" in result["message"].lower()

    def test_none_target(self, no_background_threads):
        """Test start_network_scan with None target defaults to auto-detection."""
        api = ScanAPI()

        with patch.object(api, "scan_in_progress", False):
            with patch("gui.webview_external._get_local_network_cidr", return_value="10.0.0.0/24"):
                result = api.start_network_scan(target=None, depth=2)

        assert result["success"] is True

    def test_various_depths(self, no_background_threads):
        """Test start_network_scan with different depth levels."""
        api = ScanAPI()

        for depth in [1, 2, 3]:
            api.scan_in_progress = False
            result = api.start_network_scan(target="127.0.0.1", depth=depth)
            assert result["success"] is True

    def test_with_hostname(self, no_background_threads):
        """Test start_network_scan accepts hostname."""
        api = ScanAPI()
        api.scan_in_progress = False

        result = api.start_network_scan(target="localhost", depth=1)
        assert result["success"] is True

    def test_with_cidr(self, no_background_threads):
        """Test start_network_scan accepts CIDR notation."""
        api = ScanAPI()
        api.scan_in_progress = False

        result = api.start_network_scan(target="192.168.1.0/24", depth=2)
        assert result["success"] is True


class TestScanAPIStartSystemScan:
    """Tests for ScanAPI.start_system_scan method."""

    def test_already_running(self, no_background_threads):
        """Test start_system_scan returns error if scan already running."""
        api = ScanAPI()
        api.scan_in_progress = True

        result = api.start_system_scan()

        assert result["success"] is False
        assert "already in progress" in result["message"]

    def test_success(self, no_background_threads):
        """Test start_system_scan starts successfully."""
        api = ScanAPI()
        api.scan_in_progress = False

        result = api.start_system_scan(depth=1)

        assert result["success"] is True
        assert "started" in result["message"].lower()


class TestScanAPIGetLastScans:
    """Tests for get_last_network_scan and get_last_system_scan methods."""

    def test_get_last_network_scan_exists(self, tmp_path):
        """Test getting last network scan when it exists."""
        api = ScanAPI()
        scan_file = tmp_path / "last_network.json"
        scan_file.write_text('{"ip": "192.168.1.1", "ports": [22, 80]}')
        api.last_network_scan = str(scan_file)

        result = api.get_last_network_scan()

        assert result is not None
        assert result["ip"] == "192.168.1.1"

    def test_get_last_network_scan_not_exists(self, tmp_path):
        """Test getting last network scan when file doesn't exist."""
        api = ScanAPI()
        api.last_network_scan = str(tmp_path / "nonexistent.json")

        result = api.get_last_network_scan()
        assert result is None

    def test_get_last_network_scan_none(self):
        """Test getting last network scan when none has been performed."""
        api = ScanAPI()
        api.last_network_scan = None

        result = api.get_last_network_scan()
        assert result is None

    def test_get_last_system_scan_exists(self, tmp_path):
        """Test getting last system scan when it exists."""
        api = ScanAPI()
        scan_file = tmp_path / "last_system.json"
        scan_file.write_text('{"score": 85, "vulnerabilities": []}')
        api.last_system_scan = str(scan_file)

        result = api.get_last_system_scan()

        assert result is not None
        assert result["score"] == 85

    def test_get_last_system_scan_not_exists(self, tmp_path):
        """Test getting last system scan when file doesn't exist."""
        api = ScanAPI()
        api.last_system_scan = str(tmp_path / "nonexistent.json")

        result = api.get_last_system_scan()
        assert result is None

    def test_get_last_system_scan_none(self):
        """Test getting last system scan when none has been performed."""
        api = ScanAPI()
        api.last_system_scan = None

        result = api.get_last_system_scan()
        assert result is None
