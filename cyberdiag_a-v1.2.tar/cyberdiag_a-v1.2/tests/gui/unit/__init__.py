"""Unit tests for the GUI module."""
