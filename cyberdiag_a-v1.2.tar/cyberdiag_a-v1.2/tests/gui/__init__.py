"""GUI tests package for CyberDiag."""
