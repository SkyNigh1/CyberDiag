"""Integration tests for the GUI module."""
