import pytest

from gui.webview_external import ScanAPI


class TestGUIIntegration:
    """Integration tests for the GUI/Webview bridge."""

    @pytest.fixture
    def api(self, tmp_path):
        """Mocked ScanAPI instance for integration testing."""
        # Use a temporary results directory for tests
        results_dir = tmp_path / "results"
        results_dir.mkdir()

        # Instantiate API and override paths for testing
        api = ScanAPI()
        # Note: In a real integration test, we might want to check
        # if ScanAPI can be modified to use a different root.
        # For now, let's just test that the basic methods can run.
        return api

    def test_api_initialization(self, api):
        """Verify that ScanAPI initializes and has access to its core state."""
        assert hasattr(api, "scan_in_progress")
        assert hasattr(api, "_active_processes")
        assert isinstance(api._active_processes, list)

    def test_list_scans_returns_dict(self, api):
        """Verify that list_scans returns a dict of scan history."""
        scans = api.list_scans()
        assert isinstance(scans, dict)
        assert "network" in scans
        assert "system" in scans

    def test_get_scan_data_handles_missing_file(self, api):
        """Verify that get_scan_data returns None for non-existent files."""
        result = api.get_scan_data("non_existent_file.json")
        assert result is None
