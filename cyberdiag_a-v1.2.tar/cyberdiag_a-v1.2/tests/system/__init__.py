"""System tests package for CyberDiag."""
