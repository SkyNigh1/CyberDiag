"""Integration tests for the system module."""
