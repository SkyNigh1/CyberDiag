from unittest.mock import patch, MagicMock

from system.lynis_interface import LynisInterface


class TestSystemIntegration:
    """Integration tests for the system module."""

    def test_lynis_audit_to_report_flow(self, tmp_path):
        """Test the flow from running a (mocked) lynis audit to generating reports."""
        report_dat = tmp_path / "lynis-report.dat"
        report_json = tmp_path / "report.json"

        dat_content = """lynis_version=3.1.6
suggestion[]=TEST-1234|Fix this|https://example.com|Solution|
hardening_index=75
"""

        # Mock for subprocess.Popen (used in run_audit)
        mock_popen_instance = MagicMock()
        mock_popen_instance.stdout = iter([
            "[Initializing program]\n",
            "Performing test ID TEST-0001\n",
            "[Kernel]\n",
            ""
        ])
        mock_popen_instance.returncode = 0
        mock_popen_instance.wait.return_value = 0

        def popen_side_effect(*args, **kwargs):
            # Write the report file when Popen is called (simulating Lynis execution)
            report_dat.write_text(dat_content)
            return mock_popen_instance

        # Mock for subprocess.run (used in LynisReportParser for reading files)
        def run_side_effect(*args, **kwargs):
            if "cat" in args[0]:  # handle LynisReportParser reading
                return MagicMock(returncode=0, stdout=dat_content)
            return MagicMock(returncode=0)

        with patch("subprocess.Popen", side_effect=popen_side_effect) as _mock_popen:
            with patch("subprocess.run", side_effect=run_side_effect) as _mock_run:
                # 1. Run audit (mocked subprocess)
                with patch(
                        "system.lynis_interface.LynisInterface._check_lynis_installation",
                        return_value=True,
                ):
                    with patch(
                            "system.lynis_interface.LynisInterface._find_lynis_in_path",
                            return_value="/usr/bin/lynis",
                    ):
                        # We need to ensure the interface uses our tmp report path
                        interface = LynisInterface(lynis_path="/usr/bin/lynis")
                        interface.report_path = str(report_dat)
                        # Force the parser to also use this path
                        interface.report_parser.report_path = str(report_dat)
                        results = interface.run_audit()

            assert report_dat.exists()

            # Verify results structure
            assert "security_score" in results
            assert "vulnerabilities" in results
