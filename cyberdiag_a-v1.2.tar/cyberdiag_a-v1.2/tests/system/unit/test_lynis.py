"""
Comprehensive unit tests for system/lynis_interface.py

This module consolidates all tests for Lynis interface classes:
- LynisLogParser
- LynisReportParser
- LynisAnalyzer
- LynisInterface
- LynisReportGenerator
"""
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from system.lynis_interface import (
    LynisLogParser,
    LynisReportParser,
    LynisAnalyzer,
    LynisInterface,
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_dat(tmp_path):
    """Create a sample Lynis report DAT file."""
    content = """lynis_version=3.1.6
suggestion[]=BOOT-5122|Set a password on GRUB|Manual|
vulnerable_package[]=openssl,highvuln|
hardening_index=64
"""
    dat_file = tmp_path / "test.dat"
    dat_file.write_text(content)
    return str(dat_file)


@pytest.fixture
def sample_results():
    """Sample audit results for testing."""
    return {
        "timestamp": "2025-01-15T10:30:00",
        "security_score": 75,
        "exit_code": 0,
        "vulnerabilities": [
            {
                "type": "suggestion",
                "description": "Enable firewall",
                "priority": "medium",
            },
            {
                "type": "warning",
                "description": "Root login enabled",
                "priority": "high",
            },
        ],
        "services": ["sshd", "nginx"],
        "kernel_info": {
            "type": "Linux",
            "version": "5.15.0",
            "hostname": "testserver",
        },
        "log_analysis": {
            "warnings": [{"message": "test warning"}],
            "suggestions": [{"message": "test suggestion"}],
        },
    }


@pytest.fixture
def minimal_results():
    """Minimal audit results for testing."""
    return {
        "timestamp": "2025-01-15T10:30:00",
        "security_score": 0,
        "exit_code": 0,
        "vulnerabilities": [],
        "services": [],
        "kernel_info": {},
        "log_analysis": {"warnings": [], "suggestions": []},
    }


# =============================================================================
# LynisLogParser Tests
# =============================================================================

class TestLynisLogParser:
    """Tests for LynisLogParser class."""

    def test_parse_log_file_not_exists(self, tmp_path):
        """Test parse_log returns error when file doesn't exist."""
        parser = LynisLogParser(str(tmp_path / "nonexistent.log"))
        results = parser.parse_log()
        assert "errors" in results
        assert len(results["errors"]) > 0
        assert "introuvable" in results["errors"][0]

    def test_parse_log_with_warnings(self, tmp_path):
        """Test parse_log correctly parses warnings."""
        log_content = """Starting Lynis scan
Warning: Found old kernel
Warning: SSH root login allowed
Performing test ID AUTH-9204
"""
        log_file = tmp_path / "lynis.log"
        log_file.write_text(log_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisLogParser(str(log_file))
            results = parser.parse_log()

        assert len(results["warnings"]) == 2
        assert results["warnings"][0]["type"] == "warning"
        assert "old kernel" in results["warnings"][0]["message"]

    def test_parse_log_with_suggestions(self, tmp_path):
        """Test parse_log correctly parses suggestions."""
        log_content = """Starting Lynis scan
Suggestion: Enable firewall
Suggestion: Update packages
"""
        log_file = tmp_path / "lynis.log"
        log_file.write_text(log_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisLogParser(str(log_file))
            results = parser.parse_log()

        assert len(results["suggestions"]) == 2
        assert results["suggestions"][0]["type"] == "suggestion"

    def test_parse_log_with_tests(self, tmp_path):
        """Test parse_log correctly parses test IDs."""
        log_content = """Performing test ID AUTH-9204
Performing test ID FILE-6310
"""
        log_file = tmp_path / "lynis.log"
        log_file.write_text(log_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisLogParser(str(log_file))
            results = parser.parse_log()

        assert len(results["tests"]) == 2
        assert results["tests"][0]["test_id"] == "AUTH-9204"
        assert results["tests"][1]["test_id"] == "FILE-6310"

    def test_parse_warning_line(self):
        """Test _parse_warning correctly extracts warning message."""
        parser = LynisLogParser("/var/log/lynis.log")
        result = parser._parse_warning("Warning: This is a warning message")
        assert result["type"] == "warning"
        assert result["message"] == "This is a warning message"

    def test_parse_suggestion_line(self):
        """Test _parse_suggestion correctly extracts suggestion message."""
        parser = LynisLogParser("/var/log/lynis.log")
        result = parser._parse_suggestion("Suggestion: This is a suggestion")
        assert result["type"] == "suggestion"
        assert result["message"] == "This is a suggestion"

    def test_parse_test_line(self):
        """Test _parse_test correctly extracts test ID."""
        parser = LynisLogParser("/var/log/lynis.log")
        result = parser._parse_test("Performing test ID BOOT-5122")
        assert result["test_id"] == "BOOT-5122"

    def test_parse_test_unknown_format(self):
        """Test _parse_test returns UNKNOWN for invalid format."""
        parser = LynisLogParser("/var/log/lynis.log")
        result = parser._parse_test("Some random line")
        assert result["test_id"] == "UNKNOWN"

    @patch("subprocess.run")
    def test_parse_log_with_sudo(self, mock_run, tmp_path):
        """Test parse_log uses sudo when not root."""
        log_file = tmp_path / "lynis.log"
        log_file.write_text("Warning: Test warning")

        mock_run.return_value = MagicMock(
            returncode=0, stdout="Warning: Sudo warning\n"
        )

        with patch("os.geteuid", return_value=1000):  # Not root
            with patch("os.path.exists", return_value=True):
                parser = LynisLogParser(str(log_file))
                results = parser.parse_log()

        mock_run.assert_called()
        assert len(results["warnings"]) == 1

    def test_parse_log_all_entry_types(self, tmp_path):
        """Test parsing log with warnings, suggestions, and tests."""
        log_content = """
Warning: Found insecure configuration
Suggestion: Enable audit logging
Performing test ID AUTH-9204
Performing test ID FILE-6310
Warning: SSH allows root login
"""
        log_file = tmp_path / "lynis.log"
        log_file.write_text(log_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisLogParser(str(log_file))
            results = parser.parse_log()

        assert len(results["warnings"]) == 2
        assert len(results["suggestions"]) == 1
        assert len(results["tests"]) == 2


# =============================================================================
# LynisReportParser Tests
# =============================================================================

class TestLynisReportParser:
    """Tests for LynisReportParser class."""

    def test_parse_report_file_not_exists(self, tmp_path):
        """Test parse_report returns error when file doesn't exist."""
        parser = LynisReportParser(str(tmp_path / "nonexistent.dat"))
        data = parser.parse_report()
        assert "error" in data
        assert "introuvable" in data["error"]

    def test_parse_report_basic(self, tmp_path):
        """Test parse_report correctly parses key=value format."""
        report_content = """# Lynis report
lynis_version=3.1.6
hardening_index=64
hostname=testhost
"""
        report_file = tmp_path / "lynis-report.dat"
        report_file.write_text(report_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisReportParser(str(report_file))
            data = parser.parse_report()

        assert data.get("lynis_version") == "3.1.6"
        assert data.get("hardening_index") == "64"
        assert data.get("hostname") == "testhost"

    def test_parse_report_multiple_values(self, tmp_path):
        """Test parse_report handles multiple values for same key."""
        report_content = """suggestion[]=AUTH-1234|Fix auth|Details|Solution|
suggestion[]=FILE-5678|Fix file|Details|Solution|
"""
        report_file = tmp_path / "lynis-report.dat"
        report_file.write_text(report_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisReportParser(str(report_file))
            data = parser.parse_report()

        assert "suggestion[]" in data
        assert isinstance(data["suggestion[]"], list)
        assert len(data["suggestion[]"]) == 2

    def test_parse_report_ignores_comments(self, tmp_path):
        """Test parse_report ignores comment lines."""
        report_content = """# This is a comment
lynis_version=3.1.6
# Another comment
"""
        report_file = tmp_path / "lynis-report.dat"
        report_file.write_text(report_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisReportParser(str(report_file))
            data = parser.parse_report()

        assert "lynis_version" in data
        assert "#" not in str(data.keys())

    def test_parse_report_empty_file(self, tmp_path):
        """Test parsing an empty report file."""
        report_file = tmp_path / "empty.dat"
        report_file.write_text("")

        with patch("os.geteuid", return_value=0):
            parser = LynisReportParser(str(report_file))
            data = parser.parse_report()

        assert isinstance(data, dict)

    def test_parse_report_malformed_lines(self, tmp_path):
        """Test parsing report with malformed lines."""
        report_content = """malformed_line_without_equals
key_with_no_value=
=value_with_no_key
valid_key=valid_value
"""
        report_file = tmp_path / "malformed.dat"
        report_file.write_text(report_content)

        with patch("os.geteuid", return_value=0):
            parser = LynisReportParser(str(report_file))
            data = parser.parse_report()

        assert data.get("valid_key") == "valid_value"


# =============================================================================
# LynisAnalyzer Tests
# =============================================================================

class TestLynisAnalyzer:
    """Tests for LynisAnalyzer class."""

    def test_get_vulnerabilities_suggestions(self):
        """Test get_vulnerabilities extracts suggestions."""
        report_data = {
            "suggestion[1]": "TEST-1|Description 1|Details|Solution|",
            "suggestion[2]": "TEST-2|Description 2|Details|Solution|",
        }
        analyzer = LynisAnalyzer(report_data)
        vulns = analyzer.get_vulnerabilities()

        assert len(vulns) == 2
        assert vulns[0]["type"] == "suggestion"

    def test_get_vulnerabilities_warnings(self):
        """Test get_vulnerabilities extracts warnings with high priority."""
        report_data = {
            "warning[1]": "WARN-1|Critical warning|Details|Solution|",
        }
        analyzer = LynisAnalyzer(report_data)
        vulns = analyzer.get_vulnerabilities()

        assert len(vulns) == 1
        assert vulns[0]["type"] == "warning"
        assert vulns[0]["priority"] == "high"

    def test_get_vulnerabilities_list_values(self):
        """Test get_vulnerabilities handles list values."""
        report_data = {
            "suggestion[1]": [
                "TEST-A|Suggestion A|Details|Solution|",
                "TEST-B|Suggestion B|Details|Solution|",
            ],
        }
        analyzer = LynisAnalyzer(report_data)
        vulns = analyzer.get_vulnerabilities()

        assert len(vulns) == 2

    def test_get_vulnerabilities_with_suggestion_list(self):
        """Test get_vulnerabilities with suggestion[] key."""
        report_data = {
            "suggestion[]": [
                "TEST-1|Description 1|Details|Solution|",
                "TEST-2|Description 2|Details|Solution|",
            ]
        }
        analyzer = LynisAnalyzer(report_data)
        vulns = analyzer.get_vulnerabilities()

        assert len(vulns) == 2

    def test_get_vulnerabilities_with_warning_list(self):
        """Test get_vulnerabilities with warning[] key."""
        report_data = {
            "warning[]": [
                "WARN-1|Warning description|Details|Solution|"
            ]
        }
        analyzer = LynisAnalyzer(report_data)
        vulns = analyzer.get_vulnerabilities()

        assert len(vulns) == 1
        assert vulns[0]["type"] == "warning"


class TestLynisAnalyzerPriority:
    """Tests for LynisAnalyzer priority extraction."""

    def test_extract_priority_critical(self):
        """Test _extract_priority identifies critical priority."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority("Critical issue found") == "critical"
        assert analyzer._extract_priority("Urgent fix needed") == "critical"

    def test_extract_priority_high(self):
        """Test _extract_priority identifies high priority."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority("Important update") == "high"
        assert analyzer._extract_priority("High severity") == "high"

    def test_extract_priority_medium(self):
        """Test _extract_priority identifies medium priority."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority("Medium risk") == "medium"
        assert analyzer._extract_priority("Moderate concern") == "medium"

    def test_extract_priority_low(self):
        """Test _extract_priority defaults to low."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority("Some suggestion") == "low"

    def test_extract_priority_list_input(self):
        """Test _extract_priority handles list input."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority(["critical", "issue"]) == "critical"

    def test_extract_priority_none_input(self):
        """Test _extract_priority handles None input."""
        analyzer = LynisAnalyzer({})
        assert analyzer._extract_priority(None) == "low"


class TestLynisAnalyzerSystemInfo:
    """Tests for LynisAnalyzer system information extraction."""

    def test_get_installed_packages(self):
        """Test get_installed_packages extracts packages."""
        report_data = {
            "installed_package[1]": "openssl",
            "installed_package[2]": ["nginx", "apache2"],
        }
        analyzer = LynisAnalyzer(report_data)
        packages = analyzer.get_installed_packages()

        assert "openssl" in packages
        assert "nginx" in packages
        assert "apache2" in packages

    def test_get_installed_packages_empty(self):
        """Test get_installed_packages with no packages."""
        analyzer = LynisAnalyzer({})
        packages = analyzer.get_installed_packages()
        assert packages == []

    def test_get_running_services(self):
        """Test get_running_services extracts services."""
        report_data = {
            "running_service[1]": "sshd",
            "service_running[1]": ["nginx", "mysql"],
        }
        analyzer = LynisAnalyzer(report_data)
        services = analyzer.get_running_services()

        assert "sshd" in services
        assert "nginx" in services
        assert "mysql" in services

    def test_get_running_services_empty(self):
        """Test get_running_services with no services."""
        analyzer = LynisAnalyzer({})
        services = analyzer.get_running_services()
        assert services == []

    def test_get_kernel_info(self):
        """Test get_kernel_info extracts kernel information."""
        report_data = {
            "linux_kernel_version": "5.15.0",
            "os_kernel_version": "5.15.0-generic",
            "os": "Linux",
            "hostname": "testserver",
        }
        analyzer = LynisAnalyzer(report_data)
        kernel = analyzer.get_kernel_info()

        assert kernel["version"] == "5.15.0"
        assert kernel["release"] == "5.15.0-generic"
        assert kernel["type"] == "Linux"
        assert kernel["hostname"] == "testserver"

    def test_get_kernel_info_defaults(self):
        """Test get_kernel_info returns Unknown for missing values."""
        analyzer = LynisAnalyzer({})
        kernel = analyzer.get_kernel_info()

        assert kernel["version"] == "Unknown"
        assert kernel["release"] == "Unknown"
        assert kernel["type"] == "Unknown"
        assert kernel["hostname"] == "Unknown"


class TestLynisAnalyzerSecurityScore:
    """Tests for LynisAnalyzer security score extraction."""

    def test_get_security_score(self):
        """Test get_security_score extracts hardening index."""
        analyzer = LynisAnalyzer({"hardening_index": "75"})
        assert analyzer.get_security_score() == 75

    def test_get_security_score_invalid(self):
        """Test get_security_score returns 0 for invalid value."""
        analyzer = LynisAnalyzer({"hardening_index": "invalid"})
        assert analyzer.get_security_score() == 0

    def test_get_security_score_missing(self):
        """Test get_security_score returns 0 when missing."""
        analyzer = LynisAnalyzer({})
        assert analyzer.get_security_score() == 0


class TestLynisAnalyzerSuggestionFormat:
    """Tests for LynisAnalyzer suggestion format parsing."""

    def test_parse_suggestion_format(self):
        """Test _parse_suggestion_format correctly parses Lynis format."""
        analyzer = LynisAnalyzer({})
        result = analyzer._parse_suggestion_format(
            "AUTH-1234|Enable firewall|www.example.com|Install ufw|"
        )

        assert result["test_id"] == "AUTH-1234"
        assert result["description"] == "Enable firewall"
        assert result["details"] == "www.example.com"
        assert result["solution"] == "Install ufw"

    def test_parse_suggestion_format_with_dash(self):
        """Test _parse_suggestion_format handles dash as empty."""
        analyzer = LynisAnalyzer({})
        result = analyzer._parse_suggestion_format("AUTH-1234|Enable firewall|-|-|")

        assert result["test_id"] == "AUTH-1234"
        assert result["details"] == ""
        assert result["solution"] == ""

    def test_parse_suggestion_format_invalid(self):
        """Test _parse_suggestion_format handles invalid format."""
        analyzer = LynisAnalyzer({})
        result = analyzer._parse_suggestion_format("Invalid format")

        assert result["test_id"] == "UNKNOWN"
        assert result["description"] == "Invalid format"


# =============================================================================
# LynisInterface Tests
# =============================================================================

class TestLynisInterface:
    """Tests for LynisInterface class."""

    @patch("os.path.exists", return_value=True)
    def test_init_with_existing_lynis(self, mock_exists):
        """Test LynisInterface initializes with valid lynis path."""
        interface = LynisInterface("/usr/bin/lynis")
        assert interface.lynis_path == "/usr/bin/lynis"

    @patch("os.path.exists", return_value=False)
    @patch("subprocess.run")
    def test_init_searches_path(self, mock_run, mock_exists):
        """Test LynisInterface searches PATH when default not found."""
        mock_run.return_value = MagicMock(returncode=0, stdout="/usr/local/bin/lynis\n")

        interface = LynisInterface("/nonexistent/lynis")
        assert interface.lynis_path == "/usr/local/bin/lynis"

    @patch("os.path.exists", return_value=False)
    @patch("subprocess.run")
    def test_init_fallback_to_lynis(self, mock_run, mock_exists):
        """Test LynisInterface falls back to 'lynis' when not found."""
        mock_run.return_value = MagicMock(returncode=1, stdout="")

        interface = LynisInterface("/nonexistent/lynis")
        assert interface.lynis_path == "lynis"


class TestLynisInterfaceRunAudit:
    """Tests for LynisInterface.run_audit method."""

    @patch("subprocess.Popen")
    @patch("os.path.exists", return_value=True)
    def test_run_audit_timeout(self, mock_exists, mock_popen):
        """Test run_audit handles TimeoutExpired exception."""
        mock_process = MagicMock()
        mock_process.wait.side_effect = subprocess.TimeoutExpired("lynis", 600)
        mock_popen.return_value = mock_process

        interface = LynisInterface("/usr/bin/lynis")
        result = interface.run_audit(options=["--quick"])

        assert "error" in result
        assert "timeout" in result["error"].lower()

    @patch("os.path.exists", return_value=True)
    def test_run_audit_permission_error(self, mock_exists):
        """Test run_audit handles PermissionError exception."""
        interface = LynisInterface("/usr/bin/lynis")

        with patch("subprocess.Popen", side_effect=PermissionError("No permission")):
            result = interface.run_audit(options=["--quick"])

        assert "error" in result
        assert "permission" in result["error"].lower()

    @patch("os.path.exists", return_value=True)
    def test_run_audit_file_not_found(self, mock_exists):
        """Test run_audit handles FileNotFoundError exception."""
        interface = LynisInterface("/nonexistent/lynis")

        with patch("subprocess.Popen", side_effect=FileNotFoundError("Lynis not found")):
            result = interface.run_audit(options=["--quick"])

        assert "error" in result

    @patch("os.path.exists", return_value=True)
    def test_run_audit_without_options(self, mock_exists):
        """Test run_audit uses default options when none provided."""
        interface = LynisInterface("/usr/bin/lynis")

        with patch("subprocess.Popen", side_effect=FileNotFoundError()):
            result = interface.run_audit()

        assert "error" in result


class TestLynisInterfaceFindLynis:
    """Tests for LynisInterface._find_lynis_in_path method."""

    @patch("subprocess.run")
    def test_find_lynis_in_path_success(self, mock_run):
        """Test finding Lynis in PATH."""
        mock_run.return_value = MagicMock(returncode=0, stdout="/usr/local/bin/lynis\n")

        with patch("os.path.exists", return_value=False):
            interface = LynisInterface("/nonexistent")

        assert interface.lynis_path == "/usr/local/bin/lynis"

    @patch("subprocess.run")
    def test_find_lynis_in_path_not_found(self, mock_run):
        """Test fallback when Lynis not in PATH."""
        mock_run.return_value = MagicMock(returncode=1, stdout="")

        with patch("os.path.exists", return_value=False):
            interface = LynisInterface("/nonexistent")

        assert interface.lynis_path == "lynis"

    @patch("subprocess.run", side_effect=Exception("Command failed"))
    def test_find_lynis_in_path_exception(self, mock_run):
        """Test fallback on exception."""
        with patch("os.path.exists", return_value=False):
            interface = LynisInterface("/nonexistent")

        assert interface.lynis_path == "lynis"
