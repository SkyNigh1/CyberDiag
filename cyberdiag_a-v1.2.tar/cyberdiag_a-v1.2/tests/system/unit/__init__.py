"""Unit tests for the system module."""
