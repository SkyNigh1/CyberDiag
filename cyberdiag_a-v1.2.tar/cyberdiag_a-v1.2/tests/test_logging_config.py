"""
Tests for utils/logging_config.py
"""
import logging
import os
from unittest.mock import patch

from utils.logging_config import setup_logging, get_logger


class TestLoggingConfig:
    """Tests for logging configuration module."""

    def test_setup_logging_with_explicit_level(self):
        """Test setup_logging with an explicit level parameter."""
        # setup_logging uses basicConfig which only works on the root logger
        # once, but we can verify the function doesn't raise exceptions
        setup_logging(level=logging.WARNING)
        # Function should complete without error

    def test_setup_logging_no_exception(self):
        """Test setup_logging completes without error when called with defaults."""
        with patch.dict(os.environ, {}, clear=True):
            setup_logging()  # Should not raise

    @patch.dict(os.environ, {"DEBUG": "true"})
    def test_setup_logging_debug_env_true_calls_basicconfig(self):
        """Test setup_logging processes DEBUG env var 'true'."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging()
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.DEBUG

    @patch.dict(os.environ, {"DEBUG": "1"})
    def test_setup_logging_debug_env_one_calls_basicconfig(self):
        """Test setup_logging processes DEBUG env var '1'."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging()
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.DEBUG

    @patch.dict(os.environ, {"DEBUG": "yes"})
    def test_setup_logging_debug_env_yes_calls_basicconfig(self):
        """Test setup_logging processes DEBUG env var 'yes'."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging()
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.DEBUG

    @patch.dict(os.environ, {"DEBUG": "false"})
    def test_setup_logging_debug_env_false_uses_info(self):
        """Test setup_logging uses INFO when DEBUG env var is 'false'."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging()
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.INFO

    @patch.dict(os.environ, {}, clear=True)
    def test_setup_logging_no_debug_env_uses_info(self):
        """Test setup_logging uses INFO when DEBUG env var is not set."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging()
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.INFO

    def test_setup_logging_explicit_level_overrides_env(self):
        """Test explicit level parameter overrides environment variable."""
        with patch("logging.basicConfig") as mock_basic:
            setup_logging(level=logging.ERROR)
            mock_basic.assert_called_once()
            call_kwargs = mock_basic.call_args[1]
            assert call_kwargs["level"] == logging.ERROR

    def test_get_logger_returns_logger(self):
        """Test get_logger returns a logger instance."""
        logger = get_logger("test_module")
        assert isinstance(logger, logging.Logger)
        assert logger.name == "test_module"

    def test_get_logger_same_name_returns_same_logger(self):
        """Test get_logger returns the same logger for the same name."""
        logger1 = get_logger("test_same")
        logger2 = get_logger("test_same")
        assert logger1 is logger2
