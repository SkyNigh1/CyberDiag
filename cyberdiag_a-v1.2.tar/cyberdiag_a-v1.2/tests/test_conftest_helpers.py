"""
Tests for conftest.py helper functions.
"""
from pathlib import Path
from unittest.mock import patch

from tests.conftest import (
    get_project_root,
    get_results_dir,
    cleanup_simulated_scans,
    cleanup_temp_xml_files,
    cleanup_test_artifacts,
)


class TestConftestHelpers:
    """Tests for conftest.py helper functions."""

    def test_get_project_root(self):
        """Test get_project_root returns valid path."""
        root = get_project_root()
        assert isinstance(root, Path)
        assert root.exists()

    def test_get_results_dir(self):
        """Test get_results_dir returns results subdirectory."""
        results = get_results_dir()
        assert isinstance(results, Path)
        assert results.name == "results"

    def test_cleanup_simulated_scans_with_files(self, tmp_path):
        """Test cleanup_simulated_scans removes matching files."""
        results_dir = tmp_path / "results"
        results_dir.mkdir(parents=True)

        # Create simulated scan files
        (results_dir / "simulated_scan_001.json").write_text('{}')
        (results_dir / "simulated_scan_002.json").write_text('{}')
        (results_dir / "regular_scan.json").write_text('{}')  # Should not be deleted

        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            cleanup_simulated_scans()

        # Simulated files should be deleted
        assert not (results_dir / "simulated_scan_001.json").exists()
        assert not (results_dir / "simulated_scan_002.json").exists()
        # Regular file should remain
        assert (results_dir / "regular_scan.json").exists()

    def test_cleanup_simulated_scans_no_directory(self, tmp_path):
        """Test cleanup_simulated_scans handles missing directory."""
        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            # Should not raise exception
            cleanup_simulated_scans()

    def test_cleanup_temp_xml_files_with_files(self, tmp_path):
        """Test cleanup_temp_xml_files removes matching files."""
        results_dir = tmp_path / "results"
        results_dir.mkdir(parents=True)

        # Create temp XML files
        (results_dir / "scan_temp_001.xml").write_text('<xml/>')
        (results_dir / "scan_temp_002.xml").write_text('<xml/>')
        (results_dir / "final_scan.xml").write_text('<xml/>')  # Should not be deleted

        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            cleanup_temp_xml_files()

        # Temp files should be deleted
        assert not (results_dir / "scan_temp_001.xml").exists()
        assert not (results_dir / "scan_temp_002.xml").exists()
        # Regular file should remain
        assert (results_dir / "final_scan.xml").exists()

    def test_cleanup_temp_xml_files_no_directory(self, tmp_path):
        """Test cleanup_temp_xml_files handles missing directory."""
        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            # Should not raise exception
            cleanup_temp_xml_files()

    def test_cleanup_test_artifacts(self, tmp_path):
        """Test cleanup_test_artifacts removes both types of files."""
        results_dir = tmp_path / "results"
        results_dir.mkdir(parents=True)

        # Create both types of files
        (results_dir / "simulated_scan_001.json").write_text('{}')
        (results_dir / "scan_temp_001.xml").write_text('<xml/>')

        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            cleanup_test_artifacts()

        assert not (results_dir / "simulated_scan_001.json").exists()
        assert not (results_dir / "scan_temp_001.xml").exists()

    def test_cleanup_simulated_scans_handles_os_error(self, tmp_path):
        """Test cleanup_simulated_scans handles OSError gracefully."""
        results_dir = tmp_path / "results"
        results_dir.mkdir(parents=True)

        scan_file = results_dir / "simulated_scan_001.json"
        scan_file.write_text('{}')

        def raise_os_error():
            raise OSError("Permission denied")

        with patch("tests.conftest.get_results_dir", return_value=tmp_path / "results"):
            with patch.object(Path, "unlink", side_effect=OSError("Permission denied")):
                # Should not raise exception
                cleanup_simulated_scans()
