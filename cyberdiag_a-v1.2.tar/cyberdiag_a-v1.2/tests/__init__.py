"""
CyberDiag Test Suite

This package contains all tests for the CyberDiag application, organized
into the following modules:

- gui/: Tests for the GUI/WebView components
- network/: Tests for network scanning and analysis
- system/: Tests for system audit (Lynis integration)
- security/: Tests for security and integrity checks
"""
