"""
Pytest configuration and shared fixtures for the CyberDiag test suite.

This module provides:
- Cleanup functionality to remove test artifacts
- Shared fixtures for common testing needs
- Session-wide configuration
"""

from pathlib import Path

import pytest


# =============================================================================
# Path Helper Functions
# =============================================================================

def get_project_root() -> Path:
    """Return the project root directory."""
    return Path(__file__).parent.parent


def get_results_dir() -> Path:
    """Return the results directory path."""
    return get_project_root() / "results"


# =============================================================================
# Cleanup Functions
# =============================================================================

def cleanup_simulated_scans():
    """Remove all simulated scan result files from the results directory."""
    results_dir = get_results_dir()
    if not results_dir.exists():
        return

    simulated_files = list(results_dir.glob("simulated_scan_*.json"))
    for f in simulated_files:
        try:
            f.unlink()
        except OSError:
            pass

    if simulated_files:
        print(f"\nCleaned up {len(simulated_files)} simulated scan file(s)")


def cleanup_temp_xml_files():
    """Remove temporary XML scan files from the results directory."""
    results_dir = get_results_dir()
    if not results_dir.exists():
        return

    temp_xml_files = list(results_dir.glob("scan_temp_*.xml"))
    for f in temp_xml_files:
        try:
            f.unlink()
        except OSError:
            pass

    if temp_xml_files:
        print(f"\nCleaned up {len(temp_xml_files)} temporary XML file(s)")


def cleanup_test_artifacts():
    """Remove all test artifacts (simulated scans and temp files)."""
    cleanup_simulated_scans()
    cleanup_temp_xml_files()


# =============================================================================
# Session-Scoped Fixtures
# =============================================================================

@pytest.fixture(scope="session", autouse=True)
def cleanup_after_tests(request):
    """
    Session-scoped fixture that cleans up test artifacts after all tests complete.

    This fixture runs automatically for all test sessions and removes:
    - Simulated scan JSON files (simulated_scan_*.json)
    - Temporary XML scan files (scan_temp_*.xml)
    """
    yield
    cleanup_test_artifacts()


# =============================================================================
# Directory Fixtures
# =============================================================================

@pytest.fixture
def clean_results_dir():
    """
    Fixture that provides a clean results directory for individual tests.

    Use this fixture when a test needs to ensure no leftover artifacts
    exist before and after the test runs.

    Usage:
        def test_something(clean_results_dir):
            # Test code here
            pass
    """
    cleanup_test_artifacts()
    yield get_results_dir()
    cleanup_test_artifacts()


@pytest.fixture
def results_network_dir():
    """Fixture that provides the network results directory path."""
    return get_results_dir() / "network"


@pytest.fixture
def results_system_dir():
    """Fixture that provides the system results directory path."""
    return get_results_dir() / "system"


@pytest.fixture
def project_root():
    """Fixture that provides the project root directory path."""
    return get_project_root()


# =============================================================================
# Mock Results Directory Fixtures
# =============================================================================

@pytest.fixture
def mock_results_dir(tmp_path):
    """
    Create a mock results directory structure in a temporary path.

    Returns:
        Path: The results directory using unified scan subfolders.
    """
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True)
    return results_dir


# =============================================================================
# Sample Data Fixtures
# =============================================================================

@pytest.fixture
def sample_nmap_xml(tmp_path):
    """Create a sample Nmap XML file for testing."""
    xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<nmaprun scanner="nmap" args="nmap -oX - 127.0.0.1" start="1636928046" version="7.95">
<host starttime="1636928046" endtime="1636928048">
<status state="up" reason="localhost-response" reason_ttl="0"/>
<address addr="127.0.0.1" addrtype="ipv4"/>
<hostnames>
<hostname name="localhost" type="user"/>
</hostnames>
<ports>
<port protocol="tcp" portid="80">
<state state="open" reason="syn-ack" reason_ttl="0"/>
<service name="http" product="Apache httpd" version="2.4.41" method="probed" conf="10"/>
<script id="http-title" output="Example Page"/>
</port>
<port protocol="tcp" portid="22">
<state state="open" reason="syn-ack" reason_ttl="0"/>
<service name="ssh" version="7.4" method="probed" conf="10"/>
</port>
</ports>
<os>
<osmatch name="Linux 5.4" accuracy="100" line="68000"/>
</os>
<tcpsequence index="250" difficulty="Good luck!" values="A,B,C"/>
<ipidsequence class="All zeros" values="0,0,0"/>
</host>
<runstats>
<finished time="1636928048" timestr="Fri Nov 14 23:14:08 2025" summary="Nmap done" elapsed="1.87" exit="success"/>
<hosts up="1" down="0" total="1"/>
</runstats>
</nmaprun>
"""
    xml_file = tmp_path / "nmap_scan.xml"
    xml_file.write_text(xml_content)
    return str(xml_file)


@pytest.fixture
def sample_lynis_report(tmp_path):
    """Create a sample Lynis report DAT file for testing."""
    content = """lynis_version=3.1.6
hardening_index=64
hostname=testserver
os=Linux
linux_kernel_version=5.15.0
suggestion[]=AUTH-9204|Enable firewall|www.example.com|Install ufw|
suggestion[]=FILE-6310|Restrict permissions|Details|chmod 600|
warning[]=BOOT-5122|GRUB password not set|Details|Set password|
"""
    dat_file = tmp_path / "lynis-report.dat"
    dat_file.write_text(content)
    return str(dat_file)


@pytest.fixture
def sample_audit_results():
    """Sample Lynis audit results for testing."""
    return {
        "timestamp": "2025-01-15T10:30:00",
        "security_score": 75,
        "exit_code": 0,
        "vulnerabilities": [
            {
                "type": "suggestion",
                "description": "Enable firewall",
                "priority": "medium",
            },
            {
                "type": "warning",
                "description": "Root login enabled",
                "priority": "high",
            },
        ],
        "services": ["sshd", "nginx"],
        "kernel_info": {
            "type": "Linux",
            "version": "5.15.0",
            "hostname": "testserver",
        },
        "log_analysis": {
            "warnings": [{"message": "test warning"}],
            "suggestions": [{"message": "test suggestion"}],
        },
    }
