from unittest.mock import patch

from cyberdiag import _build_relaunch_command, _ensure_root


class TestPrivilegeEscalation:

    @patch("os.path.isfile")
    @patch("os.path.abspath")
    @patch("sys.argv", ["cyberdiag", "--flag"])
    @patch("sys.executable", "/tmp/.mount/usr/bin/cyberdiag")
    @patch("sys.frozen", True, create=True)
    def test_build_relaunch_command_prefers_appimage(
            self, mock_abspath, mock_isfile
    ):
        mock_abspath.side_effect = lambda path: f"/abs/{path}"
        mock_isfile.return_value = True

        with patch.dict("os.environ", {"APPIMAGE": "/home/user/CyberDiag.AppImage"}, clear=True):
            cmd = _build_relaunch_command()

        assert cmd == ["/abs//home/user/CyberDiag.AppImage", "--flag"]

    @patch("os.path.abspath")
    @patch("sys.argv", ["cyberdiag.py", "--flag"])
    @patch("sys.executable", "/usr/bin/python3")
    def test_build_relaunch_command_script_mode(self, mock_abspath):
        mock_abspath.side_effect = lambda path: f"/abs/{path}"

        with patch("sys.frozen", False, create=True):
            cmd = _build_relaunch_command()

        assert cmd == ["/abs//usr/bin/python3", "/abs/cyberdiag.py", "--flag"]

    @patch("os.geteuid")
    @patch("os.name", "posix")
    def test_ensure_root_already_root(self, mock_geteuid):
        """Test that _ensure_root returns immediately if already root."""
        mock_geteuid.return_value = 0
        with patch("os.execv") as mock_execv:
            _ensure_root()
            mock_execv.assert_not_called()

    @patch("os.geteuid")
    @patch("os.name", "posix")
    @patch("shutil.which")
    @patch("os.execvp")
    @patch("os.execv")
    def test_ensure_root_elevates_with_pkexec(
            self, mock_execv, mock_execvp, mock_which, mock_geteuid
    ):
        """Test that _ensure_root attempts to elevate using pkexec when not root."""
        mock_geteuid.return_value = 1000
        mock_which.side_effect = lambda cmd: (
            "/usr/bin/pkexec" if cmd == "pkexec" else None
        )

        with patch("cyberdiag._build_relaunch_command", return_value=["/relaunch", "--x"]):
            _ensure_root()

        mock_execv.assert_called_once()
        args = mock_execv.call_args[0]
        assert args[0] == "/usr/bin/pkexec"
        assert any("pkexec" in arg for arg in args[1])
        assert "env" in args[1]

        # Since mock_execv returns None (default mock), it WILL continue to the sudo part in our implementation.
        # This is okay for testing that it was CALLED.
        mock_execvp.assert_called_once()

    @patch("os.geteuid")
    @patch("os.name", "posix")
    @patch("shutil.which")
    @patch("os.execvp")
    def test_ensure_root_falls_back_to_sudo(
            self, mock_execvp, mock_which, mock_geteuid
    ):
        """Test that _ensure_root falls back to sudo if pkexec is missing."""
        mock_geteuid.return_value = 1000
        mock_which.return_value = None  # pkexec missing

        with patch("cyberdiag._build_relaunch_command", return_value=["/relaunch", "--x"]):
            _ensure_root()

        mock_execvp.assert_called_once()
        args = mock_execvp.call_args[0]
        assert args[0] == "sudo"
        assert "sudo" in args[1]
        assert "env" in args[1]
        assert args[1][-2:] == ["/relaunch", "--x"]
