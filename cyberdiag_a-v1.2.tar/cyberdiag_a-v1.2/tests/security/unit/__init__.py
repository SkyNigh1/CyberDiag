"""Unit tests for security checks."""
