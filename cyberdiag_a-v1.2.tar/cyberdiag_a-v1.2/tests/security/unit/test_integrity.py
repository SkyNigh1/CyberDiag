from pathlib import Path


def test_gui_assets_existence():
    """Verify that essential GUI assets exist in the project."""
    project_root = Path(__file__).resolve().parent.parent.parent.parent
    gui_dir = project_root / "gui"

    assert gui_dir.exists(), "gui directory missing"
    assert (gui_dir / "index.html").exists(), "index.html missing"
    assert (gui_dir / "styles.css").exists(), "styles.css missing"
    assert (gui_dir / "js" / "main.js").exists(), "main.js missing"
    assert (gui_dir / "assets" / "logo" / "logo.png").exists(), "logo missing"


def test_gui_lib_existence():
    """Verify that required JS libraries are present."""
    project_root = Path(__file__).resolve().parent.parent.parent.parent
    lib_dir = project_root / "gui" / "lib"

    assert lib_dir.exists(), "gui/lib directory missing"
    assert (lib_dir / "threejsmin.js").exists(), "three.js missing"
    assert (lib_dir / "gsapmin.js").exists(), "gsap missing"
