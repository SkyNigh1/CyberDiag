"""Security tests package for CyberDiag."""
