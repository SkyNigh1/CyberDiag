#!/usr/bin/env python3
"""
Lynis Interface - Python Interface for the Lynis System Audit Tool

This module provides a comprehensive Python interface for running Lynis
security audits and processing the results. It handles:

- Executing Lynis audits with configurable options
- Parsing log files (/var/log/lynis.log)
- Parsing report data files (/var/log/lynis-report.dat)
- Analyzing and categorizing vulnerabilities
- Generating reports in JSON, HTML, and text formats

Classes:
    LynisLogParser: Parses the Lynis log file for warnings, suggestions, and test results
    LynisReportParser: Parses the Lynis report.dat file (key=value format)
    LynisAnalyzer: Analyzes parsed data to extract vulnerabilities and system info
    LynisInterface: Main interface for running audits and accessing results
    LynisReportGenerator: Generates formatted reports from audit results

Security Score:
    Lynis provides a "hardening index" score from 0-100 indicating overall
    system security posture. Higher scores indicate better security.

Priority Levels:
    - critical: Severe security issues requiring immediate attention
    - high: Important issues that should be addressed soon
    - medium: Moderate issues for scheduled remediation
    - low: Minor improvements for consideration

Author:
    Yann CLOAREC
Date:
    November 10, 2025

Requirements:
    - Lynis installed on the system
    - Root/sudo privileges for full audit access
    - Read access to /var/log/lynis.log and /var/log/lynis-report.dat

Example:
    >>> from system.lynis_interface import LynisInterface
    >>> lynis = LynisInterface()
    >>> results = lynis.run_audit(options=['--quick'])
    >>> print(f"Security Score: {results['security_score']}/100")
    >>> for vuln in results['vulnerabilities'][:5]:
    ...     print(f"[{vuln['priority']}] {vuln['description']}")
"""

import os
import re
import subprocess
from datetime import datetime
from typing import List, Dict, Any

from utils.logging_config import get_logger

logger = get_logger(__name__)


class LynisLogParser:
    """
    Parser for the Lynis log file (/var/log/lynis.log).

    The Lynis log file contains detailed information about each test
    performed during an audit, including warnings, suggestions, and
    test execution status.

    Attributes:
        log_path (str): Path to the Lynis log file.

    Example:
        >>> parser = LynisLogParser("/var/log/lynis.log")
        >>> results = parser.parse_log()
        >>> print(f"Found {len(results['warnings'])} warnings")
    """

    def __init__(self, log_path: str = "/var/log/lynis.log"):
        """
        Initialize the log parser with the specified log file path.

        Args:
            log_path: Path to the Lynis log file (default: /var/log/lynis.log)
        """
        self.log_path = log_path

    def parse_log(self) -> Dict[str, List]:
        """
        Parse the Lynis log file and extract categorized entries.

        Reads the log file (using sudo if necessary) and categorizes
        entries into warnings, suggestions, test results, and errors.

        Returns:
            Dictionary with keys:
            - 'warnings': List of warning dictionaries
            - 'suggestions': List of suggestion dictionaries
            - 'tests': List of test execution entries
            - 'errors': List of parsing error messages
        """
        results = {"warnings": [], "suggestions": [], "tests": [], "errors": []}

        if not os.path.exists(self.log_path):
            results["errors"].append(f"Fichier log introuvable: {self.log_path}")
            return results

        try:
            # Read with sudo if file is not readable or if we are not root
            try:
                if os.geteuid() != 0:
                    raise PermissionError
                with open(self.log_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except (
                    PermissionError,
                    AttributeError,
            ):  # AttributeError if os.geteuid not available
                # Try with sudo
                result = subprocess.run(
                    ["sudo", "cat", self.log_path],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                content = result.stdout

            for line in content.splitlines():
                line = line.strip()

                if "Warning:" in line:
                    results["warnings"].append(self._parse_warning(line))
                elif "Suggestion:" in line:
                    results["suggestions"].append(self._parse_suggestion(line))
                elif "Performing test ID" in line:
                    results["tests"].append(self._parse_test(line))
        except Exception as e:
            results["errors"].append(f"Erreur lors du parsing du log: {str(e)}")

        return results

    def _parse_warning(self, line: str) -> Dict[str, str]:
        """Parse a warning line from the Lynis log file"""
        match = re.search(r"Warning:\s*(.+)", line)
        return {"type": "warning", "message": match.group(1) if match else line}

    def _parse_suggestion(self, line: str) -> Dict[str, str]:
        """Parse a suggestion line from the Lynis log file"""
        match = re.search(r"Suggestion:\s*(.+)", line)
        return {"type": "suggestion", "message": match.group(1) if match else line}

    def _parse_test(self, line: str) -> Dict[str, str]:
        """Parse a test line from the Lynis log file"""
        match = re.search(r"test ID\s+([A-Z]+-\d+)", line)
        return {"test_id": match.group(1) if match else "UNKNOWN", "line": line}


class LynisReportParser:
    """
    Parser for the Lynis report file (/var/log/lynis-report.dat).

    The report file contains structured data in key=value format with
    detailed system configuration, test results, and security findings.

    The file format supports:
        - Simple key=value pairs
        - Multi-value keys (same key appears multiple times)
        - Pipe-delimited complex values for suggestions/warnings

    Attributes:
        report_path (str): Path to the Lynis report file.

    Example:
        >>> parser = LynisReportParser()
        >>> data = parser.parse_report()
        >>> print(f"Hardening index: {data.get('hardening_index', 0)}")
    """

    def __init__(self, report_path: str = "/var/log/lynis-report.dat"):
        """
        Initialize the report parser.

        Args:
            report_path: Path to the Lynis report file
                        (default: /var/log/lynis-report.dat)
        """
        self.report_path = report_path

    def parse_report(self) -> Dict[str, Any]:
        """
        Parse the Lynis report file into a dictionary.

        Reads the report file (using sudo if necessary) and converts
        key=value pairs into a Python dictionary. Handles multi-value
        keys by converting them to lists.

        Returns:
            Dictionary mapping keys to their values. Multi-value keys
            are represented as lists. Contains 'error' key if file
            not found or 'parse_error' if parsing fails.
        """
        data = {}

        if not os.path.exists(self.report_path):
            return {"error": f"Fichier rapport introuvable: {self.report_path}"}

        try:
            # Read with sudo if file is not readable or if we are not root
            try:
                if os.name == "posix" and os.geteuid() != 0:
                    raise PermissionError
                with open(
                        self.report_path, "r", encoding="utf-8", errors="ignore"
                ) as f:
                    content = f.read()
            except (PermissionError, AttributeError):
                # Try with sudo
                result = subprocess.run(
                    ["sudo", "cat", self.report_path],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                content = result.stdout

            for line in content.splitlines():
                line = line.strip()

                # Ignore comments and empty lines
                if not line or line.startswith("#"):
                    continue

                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()

                    # Handle multiple values (same key)
                    if key in data:
                        if not isinstance(data[key], list):
                            data[key] = [data[key]]
                        data[key].append(value)
                    else:
                        data[key] = value
        except Exception as e:
            data["parse_error"] = str(e)

        return data


class LynisAnalyzer:
    """
    Analyzer for extracted Lynis report data.

    This class provides methods to extract and analyze security-relevant
    information from parsed Lynis report data, including vulnerabilities,
    system configuration, and running services.

    Attributes:
        data (Dict): The parsed Lynis report data.

    Example:
        >>> parser = LynisReportParser()
        >>> data = parser.parse_report()
        >>> analyzer = LynisAnalyzer(data)
        >>> score = analyzer.get_security_score()
        >>> vulns = analyzer.get_vulnerabilities()
    """

    def __init__(self, report_data: Dict):
        """
        Initialize the analyzer with parsed report data.

        Args:
            report_data: Dictionary of parsed Lynis report data
                        from LynisReportParser.parse_report()
        """
        self.data = report_data

    def _parse_suggestion_format(self, suggestion_text: str) -> Dict[str, str]:
        """Parse Lynis suggestion format: TEST-ID|Description|Details|Solution|

        Returns:
            Dict with test_id, description, details, solution
        """
        parts = suggestion_text.split("|")
        if len(parts) >= 4:
            return {
                "test_id": parts[0].strip(),
                "description": parts[1].strip(),
                "details": parts[2].strip() if parts[2].strip() != "-" else "",
                "solution": parts[3].strip() if parts[3].strip() != "-" else "",
            }
        else:
            # Format non standard, retourner tel quel
            return {
                "test_id": "UNKNOWN",
                "description": suggestion_text,
                "details": "",
                "solution": "",
            }

    def get_vulnerabilities(self) -> List[Dict[str, Any]]:
        """Extract detected vulnerabilities"""
        vulns = []

        for key, value in self.data.items():
            if key.startswith("suggestion["):
                # Si value est une liste, créer une vulnérabilité pour chaque élément
                if isinstance(value, list):
                    for suggestion in value:
                        parsed = self._parse_suggestion_format(suggestion)
                        vulns.append(
                            {
                                "type": "suggestion",
                                "test_id": parsed["test_id"],
                                "description": parsed["description"],
                                "details": parsed["details"],
                                "solution": parsed["solution"],
                                "priority": self._extract_priority(
                                    parsed["description"]
                                ),
                            }
                        )
                else:
                    parsed = self._parse_suggestion_format(value)
                    vulns.append(
                        {
                            "type": "suggestion",
                            "test_id": parsed["test_id"],
                            "description": parsed["description"],
                            "details": parsed["details"],
                            "solution": parsed["solution"],
                            "priority": self._extract_priority(parsed["description"]),
                        }
                    )
            elif key.startswith("warning["):
                # Si value est une liste, créer une vulnérabilité pour chaque élément
                if isinstance(value, list):
                    for warning in value:
                        parsed = self._parse_suggestion_format(warning)
                        vulns.append(
                            {
                                "type": "warning",
                                "test_id": parsed["test_id"],
                                "description": parsed["description"],
                                "details": parsed["details"],
                                "solution": parsed["solution"],
                                "priority": "high",
                            }
                        )
                else:
                    parsed = self._parse_suggestion_format(value)
                    vulns.append(
                        {
                            "type": "warning",
                            "test_id": parsed["test_id"],
                            "description": parsed["description"],
                            "details": parsed["details"],
                            "solution": parsed["solution"],
                            "priority": "high",
                        }
                    )

        # Trier par priorité (critical > high > medium > low)
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        vulns.sort(key=lambda v: priority_order.get(v.get("priority", "low"), 3))

        return vulns

    def _extract_priority(self, text: Any) -> str:
        """Extract the priority of a suggestion.

        Supports multiple types (str, list, None). If `text` is a list,
        it is concatenated into a single string before extracting the priority.
        """
        # Normalize as a string
        if isinstance(text, list):
            text_str = " ".join(map(str, text))
        else:
            text_str = "" if text is None else str(text)

        text_lower = text_str.lower()
        if "critical" in text_lower or "urgent" in text_lower:
            return "critical"
        elif "important" in text_lower or "high" in text_lower:
            return "high"
        elif "medium" in text_lower or "moderate" in text_lower:
            return "medium"
        else:
            return "low"

    def get_installed_packages(self) -> List[str]:
        """List of detected installed packages"""
        packages = []
        for key, value in self.data.items():
            # Ensure key is a string before calling .lower()
            if isinstance(key, str) and "installed_package" in key.lower():
                if isinstance(value, list):
                    packages.extend(value)
                else:
                    packages.append(value)
        return packages

    def get_running_services(self) -> List[str]:
        """Currently running services"""
        services = []
        for key, value in self.data.items():
            # Ensure key is a string before calling .lower()
            if isinstance(key, str):
                key_lower = key.lower()
                if "running_service" in key_lower or "service_running" in key_lower:
                    if isinstance(value, list):
                        services.extend(value)
                    else:
                        services.append(value)
        return services

    def get_kernel_info(self) -> Dict[str, str]:
        """Kernel information"""
        return {
            "version": self.data.get("linux_kernel_version", "Unknown"),
            "release": self.data.get("os_kernel_version", "Unknown"),
            "type": self.data.get("os", "Unknown"),
            "hostname": self.data.get("hostname", "Unknown"),
        }

    def get_security_score(self) -> int:
        """Retrieve the security score (hardening index)"""
        hardening = self.data.get("hardening_index", "0")
        try:
            return int(hardening)
        except (ValueError, TypeError):
            return 0


class LynisInterface:
    """
    Main interface for interacting with the Lynis security audit tool.

    This class provides the primary API for running Lynis audits and
    retrieving results. It automatically locates Lynis on the system
    and coordinates parsing of log and report files.

    Attributes:
        lynis_path (str): Path to the Lynis executable.
        log_parser (LynisLogParser): Parser for log files.
        report_parser (LynisReportParser): Parser for report files.

    Example:
        >>> lynis = LynisInterface()
        >>> results = lynis.run_audit(options=['--quick', '--quiet'])
        >>> if results.get('success'):
        ...     print(f"Score: {results['security_score']}/100")
        ...     for vuln in results['vulnerabilities']:
        ...         print(f"  [{vuln['priority']}] {vuln['description']}")
        >>> else:
        ...     print(f"Error: {results.get('error')}")

    Note:
        Lynis requires root privileges for full audit capabilities.
        Some tests may be skipped without proper permissions.
    """

    def __init__(self, lynis_path: str = "/usr/local/lynis/lynis"):
        """
        Initialize the Lynis interface.

        Args:
            lynis_path: Path to the Lynis executable. If the file doesn't
                       exist at this path, the constructor will search
                       for 'lynis' in the system PATH.
        """
        self.lynis_path = lynis_path
        self.log_parser = LynisLogParser()
        self.report_parser = LynisReportParser()

        # Check if Lynis is installed
        if not self._check_lynis_installation():
            logger.warning(f"ATTENTION: Lynis introuvable à {lynis_path}")
            logger.info("Essai de recherche dans le PATH...")
            self.lynis_path = self._find_lynis_in_path()

    def _check_lynis_installation(self) -> bool:
        """Check if Lynis is installed"""
        return os.path.exists(self.lynis_path)

    def _find_lynis_in_path(self) -> str:
        """Search for Lynis in the system PATH"""
        try:
            result = subprocess.run(["which", "lynis"], capture_output=True, text=True)
            if result.returncode == 0:
                path = result.stdout.strip()
                logger.info(f"Lynis trouvé: {path}")
                return path
        except Exception:
            pass
        return "lynis"  # Fallback

    def run_audit(self, options: List[str] = None, progress_callback=None) -> Dict[str, Any]:
        """
        Execute a full Lynis audit

        Args:
            options: Additional options for Lynis
                    Example: ['--quick', '--quiet', '--no-colors']
            progress_callback: Optional callback function(percent, message) for progress updates

        Returns:
            Dictionary containing all audit results
        """
        cmd = []

        cmd.extend([self.lynis_path, "audit", "system"])

        if options:
            cmd.extend(options)
        else:
            # Default options
            cmd.extend(["--no-colors", "--quiet"])

        logger.info(f"Commande: {' '.join(cmd)}")
        logger.info("Exécution en cours...")

        def _notify(percent, message=""):
            """Helper to safely call progress callback"""
            if progress_callback:
                try:
                    progress_callback(percent, message)
                except Exception as e:
                    logger.debug(f"Progress callback error: {e}")

        try:
            _notify(5, "Démarrage de l'audit Lynis...")

            # Use Popen for real-time output processing
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            stdout_lines = []
            current_group = ""
            tests_completed = 0

            # Progress tracking based on Lynis test groups
            # With --no-colors, output format is: [+] Group Name
            test_group_pattern = re.compile(r'^\[\+\]\s+([A-Za-z][A-Za-z0-9,: ()-]+)')
            performing_test_pattern = re.compile(r'Performing test ID ([A-Z]+-\d+)')

            _notify(10, "Audit en cours...")

            # Read output line by line for real-time progress
            for line in process.stdout:
                stdout_lines.append(line)
                line_stripped = line.strip()

                # Detect test group changes (e.g., [Boot and services], [Kernel], etc.)
                group_match = test_group_pattern.search(line_stripped)
                if group_match and group_match.group(1) != current_group:
                    current_group = group_match.group(1)
                    # Map known groups to progress percentages
                    group_progress = {
                        'Initializing program': 10,
                        'System Tools': 15,
                        'Boot and services': 20,
                        'Kernel': 25,
                        'Memory and processes': 30,
                        'Users, Groups and Authentication': 35,
                        'Shells': 40,
                        'File systems': 45,
                        'Storage': 48,
                        'NFS': 50,
                        'Software: name services': 52,
                        'Networking': 55,
                        'Printers and Spools': 58,
                        'Software: e-mail and messaging': 60,
                        'Software: firewalls': 62,
                        'Software: webserver': 65,
                        'SSH Support': 68,
                        'SNMP Support': 70,
                        'Databases': 72,
                        'LDAP Services': 74,
                        'Software: PHP': 76,
                        'Squid Support': 78,
                        'Logging and files': 80,
                        'Insecure services': 82,
                        'Banners and identification': 84,
                        'Scheduled tasks': 86,
                        'Accounting': 88,
                        'Time and Synchronization': 90,
                        'Cryptography': 92,
                        'Virtualization': 94,
                        'Security frameworks': 95,
                        'File Integrity': 96,
                        'Malware': 97,
                        'File Permissions': 98,
                        'Hardening': 99,
                    }
                    percent = group_progress.get(current_group, min(10 + tests_completed, 95))
                    _notify(percent, f"Analyse: {current_group}")

                # Count tests for fallback progress estimation
                test_match = performing_test_pattern.search(line_stripped)
                if test_match:
                    tests_completed += 1
                    # Estimate progress based on typical ~250 tests
                    if not current_group:
                        fallback_percent = min(10 + int(tests_completed * 0.35), 95)
                        _notify(fallback_percent, f"Test {test_match.group(1)}")

            # Wait for process to complete
            # Add timeout (10 minutes)
            process.wait(timeout=600)
            stdout_data = ''.join(stdout_lines)

            _notify(98, "Analyse terminée, traitement des résultats...")
            logger.info("Exécution terminée")
            logger.info(f"Code de sortie: {process.returncode}")

            # Wait a bit for log files to be written
            logger.info("Attente de l'écriture des fichiers de log...")
            import time

            time.sleep(2)

            _notify(99, "Lecture des fichiers de log...")
            # Parse results
            logger.info("Lecture des fichiers de log...")
            log_data = self.log_parser.parse_log()
            logger.info(f"   - Warnings: {len(log_data.get('warnings', []))}")
            logger.info(f"   - Suggestions: {len(log_data.get('suggestions', []))}")
            logger.info(f"   - Tests: {len(log_data.get('tests', []))}")

            logger.info("Lecture du rapport...")
            report_data = self.report_parser.parse_report()

            if "error" in report_data:
                logger.error(
                    f"Erreur lors de la lecture du rapport: {report_data['error']}"
                )

            analyzer = LynisAnalyzer(report_data)

            _notify(100, "Audit terminé")

            return {
                "timestamp": datetime.now().isoformat(),
                "exit_code": process.returncode,
                "stdout": stdout_data,
                "stderr": "",
                "log_analysis": log_data,
                "report_data": report_data,
                "security_score": analyzer.get_security_score(),
                "vulnerabilities": analyzer.get_vulnerabilities(),
                "kernel_info": analyzer.get_kernel_info(),
                "services": analyzer.get_running_services()[:20],  # Limiter à 20
                "success": process.returncode == 0,
            }

        except subprocess.TimeoutExpired:
            return {
                "error": "L'audit a dépassé le timeout de 10 minutes",
                "suggestion": "Essayez avec l'option --quick",
            }
        except PermissionError:
            return {
                "error": "Permission refusée. Lynis nécessite des privilèges root.",
                "suggestion": "L'application doit être lancée avec les privilèges appropriés.",
            }
        except FileNotFoundError:
            return {
                "error": f"Lynis introuvable à {self.lynis_path}",
                "suggestion": "Installez Lynis ou spécifiez le bon chemin",
            }
        except Exception as e:
            import traceback

            return {"error": str(e), "traceback": traceback.format_exc()}
