"""
CyberDiag System Auditing Module

This module provides system security auditing functionality using Lynis.
It handles Linux system configuration analysis, security assessment, and
compliance checking.

Components:
    - lynis_interface: Main interface for running Lynis audits and parsing results
        - LynisInterface: Executes Lynis audits
        - LynisLogParser: Parses Lynis log files
        - LynisReportParser: Parses Lynis report data files
        - LynisAnalyzer: Analyzes and extracts vulnerabilities
        - LynisReportGenerator: Generates JSON/HTML/text reports

Output:
    Results are saved as JSON files in unified 'results/<scan_id>/data.json' folders
    with structured information about:
    - System configuration
    - Security score (hardening index)
    - Warnings and suggestions
    - Detected vulnerabilities
    - Running services and installed packages

Requirements:
    - Lynis installed on the system
    - Root/sudo privileges for full audit capabilities

Example:
    >>> from system.lynis_interface import LynisInterface
    >>> lynis = LynisInterface()
    >>> results = lynis.run_audit()
    >>> print(f"Security score: {results['security_score']}")
"""

from system.lynis_interface import (
    LynisInterface,
    LynisLogParser,
    LynisReportParser,
    LynisAnalyzer,
)

__all__ = [
    "LynisInterface",
    "LynisLogParser",
    "LynisReportParser",
    "LynisAnalyzer",
]
