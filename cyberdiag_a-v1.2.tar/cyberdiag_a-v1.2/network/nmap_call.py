#!/usr/bin/env python3
"""
Nmap Scanner

This module provides a simple wrapper around nmap for network scanning with different depth levels.

Classes : NmapScanner: Main scanner class that handles nmap execution with multiple scan profiles

Usage : python3 nmap_call.py <depth> <target> [output.xml]

Examples : python3 nmap_call.py 1 192.168.1.1
"""

import re
import shutil
import subprocess
import threading
from typing import Optional, Callable

from utils.logging_config import get_logger

logger = get_logger(__name__)


class NmapScanner:
    """
    Wrapper class for executing nmap network scans with real-time feedback.
    """

    def __init__(self, target: str, depth: int):
        if depth not in [1, 2, 3]:
            raise ValueError("Depth must be 1, 2, or 3")
        self.target = target
        self.depth = depth
        self.process: Optional[subprocess.Popen] = None
        self._stop_event = threading.Event()

    def build_command(self, output_file: str) -> list[str]:
        """Construct the nmap command based on depth."""

        cmd = ["nmap", "-v"]

        if self.depth == 1:
            # Basic: Top 100 ports, fast
            cmd.extend([
                "-sS", "-sV", "-O",
                "--top-ports", "100",
                "--version-intensity", "3",
                "-T4", "--open",
                "--stats-every", "10s"
            ])
        elif self.depth == 2:
            # Standard: Top 750 ports, vuln scripts
            cmd.extend([
                "-sS", "-sV", "-O",
                "--top-ports", "750",
                "--open",
                "--script", "vuln and not intrusive",
                "--version-intensity", "5",
                "-T4",
                "--stats-every", "10s"
            ])
        else:  # depth == 3
            # Aggressive: All ports, comprehensive scripts
            cmd.extend([
                "-sS", "-sV", "-sC", "-O",
                "-p-",
                "--script", "vuln,exploit,auth",
                "--version-intensity", "9",
                "--osscan-guess",
                "-T4", "-A",
                "--max-retries", "2",
                "--host-timeout", "20m",
                "--stats-every", "10s"
            ])

        cmd.extend(["-oX", output_file, self.target])
        return cmd

    def run(self, output_file: str, progress_callback: Callable[[str, float], None] = None) -> bool:
        """
        Execute the nmap scan.

        Args:
            output_file: Path where the XML output should be saved.
            progress_callback: Optional function(line, percent) to receive updates.

        Returns:
            True if the scan completed successfully.
        """
        if not shutil.which("nmap"):
            logger.error("nmap binary not found.")
            return False

        cmd = self.build_command(output_file)
        logger.info(f"Executing: {' '.join(cmd)}")

        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            while True:
                if self._stop_event.is_set():
                    self.process.terminate()
                    return False

                line = self.process.stdout.readline()
                if not line:
                    if self.process.poll() is not None:
                        break
                    continue

                line = line.strip()
                if not line:
                    continue

                logger.debug(f"[nmap] {line}")

                if progress_callback:
                    # Attempt to parse progress % from nmap output
                    # Example: "Stats: 0:00:06 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan"
                    # "Service Scan Timing: About 50.00% done; ETC: 12:00 (0:00:06 remaining)"
                    percent = 0.0
                    if "About" in line and "% done" in line:
                        try:
                            # Extract percentage
                            match = re.search(r"About\s+(\d+\.\d+)%\s+done", line)
                            if match:
                                percent = float(match.group(1))
                        except Exception:
                            pass

                    try:
                        progress_callback(line, percent)
                    except Exception as cb_err:
                        logger.debug(f"progress_callback error (non-fatal): {cb_err}")

            return self.process.returncode == 0

        except Exception as e:
            logger.error(f"Error executing nmap: {e}")
            return False

    def stop(self):
        """Stop the running scan."""
        self._stop_event.set()
        if self.process:
            try:
                self.process.terminate()
            except Exception:
                pass
