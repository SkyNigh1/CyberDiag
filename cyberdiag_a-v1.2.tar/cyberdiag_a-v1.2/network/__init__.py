"""
CyberDiag Network Scanning Module

This module provides network security scanning functionality using nmap.
It handles port scanning, service detection, OS fingerprinting, and
vulnerability assessment.

Components:
    - nmap_call: Wrapper class for executing nmap scans with different depth levels
    - networkScanAnalysis: Parser for nmap XML output and JSON report generation

Scan Depth Levels:
    - Level 1 (Basic): Fast scan of top ports with version detection
    - Level 2 (Standard): Top 750 ports with vulnerability scripts
    - Level 3 (Thorough): Comprehensive scan with all NSE script categories

Output:
    Results are saved as JSON files in unified 'results/<scan_id>/data.json' folders
    with structured information about hosts, ports, services, and vulnerabilities.

Requirements:
    - nmap binary installed and accessible in PATH
    - Root/sudo privileges for SYN scanning (-sS)

Example:
    >>> from network.nmap_call import NmapScanner
    >>> scanner = NmapScanner(depth=1, target="192.168.1.1")
    >>> scanner.scan("output.xml")
"""

from network.networkScanAnalysis import networkscan_analysis, parse_xml
from network.nmap_call import NmapScanner

__all__ = ["NmapScanner", "networkscan_analysis", "parse_xml"]
