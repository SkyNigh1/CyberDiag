"""
Network Scan Analysis Module

This module parses nmap XML output and converts it to structured JSON format
for easier consumption by the CyberDiag frontend.

The module provides functionality to:
    - Parse nmap XML output files
    - Extract host information (IP, hostname, OS, status)
    - Analyze open ports and associated services
    - Evaluate security criticality of findings
    - Detect and categorize vulnerabilities from NSE scripts
    - Export results as JSON reports

Criticality Levels:
    - FAIBLE (Low): Minimal security concern
    - MOYENNE (Medium): Moderate security concern
    - ELEVEE (High): Significant security concern
    - CRITIQUE (Critical): Severe security vulnerability

Author:
    tiyab
Created:
    November 4, 2025
Version:
    1.0
"""

import datetime
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional

from utils.logging_config import get_logger

logger = get_logger(__name__)


def parse_xml(file_xml: str) -> List[Dict[str, Any]]:
    """
    Parse nmap XML output and extract structured host information.

    This function reads an nmap XML output file and extracts relevant
    security information for each discovered host, including:
    - IP address and hostname
    - Host status (up/down)
    - Operating system detection
    - TCP sequence predictability
    - IPID sequence analysis
    - Open ports with service detection
    - Vulnerabilities from NSE scripts

    Args:
        file_xml: Path to the nmap XML output file.

    Returns:
        A list of dictionaries, each containing information about a
        discovered host with the following structure:
        {
            "ip": str,
            "hostname": str or None,
            "status": str,
            "OS": str,
            "tcpsequence_difficulty": str or None,
            "criticite_tcpsequence": str,
            "ipid_class": str or None,
            "criticite_ipidsequence": str,
            "ports_ouverts": List[dict],
            "vulnerabilities": List[dict]
        }

    Raises:
        FileNotFoundError: If the XML file does not exist.
        xml.etree.ElementTree.ParseError: If the XML is malformed.

    Example:
        >>> hosts = parse_xml("/tmp/scan_result.xml")
        >>> for host in hosts:
        ...     print(f"{host['ip']}: {len(host['ports_ouverts'])} open ports")
    """
    # proceed to analyse a XML file
    tree = ET.parse(file_xml)
    scan = tree.getroot()

    # final report
    report = []

    # find() and findall() method search for the tag with the given parameter
    for host in scan.findall("host"):
        # collect the information concerning the host as a key/value form
        host_info: dict[str, Any] = {
            "ip": None,
            "hostname": None,
            "status": None,
            "OS": None,
            "tcpsequence_difficulty": None,
            "criticite_tcpsequence": None,
            "ipid_class": None,
            "criticite_ipidsequence": None,
            "ports_ouverts": [],
            "vulnerabilities": [],
        }

        # IP@
        ipaddress = host.find("address")
        if ipaddress is not None:
            host_info["ip"] = ipaddress.get("addr")

        # hostname
        hostnames = host.findall("hostnames/hostname")
        if hostnames:
            host_info["hostname"] = hostnames[0].get("name")
        else:
            host_info["hostname"] = None

        # state (up or down)
        status = host.find("status")
        if status is not None:
            host_info["status"] = status.get("state")

        # OS
        os_tag = host.find("os")
        if os_tag is not None:
            osmatch = os_tag.find("osmatch")
            if osmatch is not None:
                host_info["OS"] = osmatch.get("name")
        if host_info["OS"] is None:
            host_info["OS"] = "Inconnu"

        # TCP sequence difficulty
        tcpseq = host.find("tcpsequence")
        if tcpseq is not None:
            host_info["tcpsequence_difficulty"] = tcpseq.get("difficulty")

        host_info["criticite_tcpsequence"] = eval_tcpcriticality(
            host_info["tcpsequence_difficulty"]
        )

        # IPID sequence class
        ipid = host.find("ipidsequence")
        if ipid is not None:
            host_info["ipid_class"] = ipid.get("class")

        host_info["criticite_ipidsequence"] = eval_ipidcriticality(host_info["ipid_class"])
        if host_info["criticite_ipidsequence"] == "null":
            host_info["criticite_ipidsequence"] = "Inconnue"

        # ports ====================================================================
        # collect all the informations about the open ports
        for port in host.findall(".//port"):
            port_id = port.get("portid")
            protocol = port.get("protocol")
            state = port.find("state").get("state")
            service = port.find("service")
            # collect the service name
            if service is not None:
                service_name = service.get("name")
            else:
                service_name = "none"

            # collect the version
            if service is not None:
                version = service.get("version")
            else:
                version = "none"

            # evaluate the severity of the state
            criticality = "FAIBLE"  # par défaut

            # process the states according to each state in the Nmap documentation
            if state == "open":
                criticality = "MOYENNE"
            elif state == "open|filtered":
                criticality = "MOYENNE"
            elif state == "unfiltered":
                criticality = "MOYENNE"
            elif state == "filtered":
                criticality = "FAIBLE"
            elif state == "closed":
                criticality = "FAIBLE"

                # According to each services
            # remote connexion protocol and databases
            if service_name in ["ssh", "telnet", "ftp", "mysql", "postgresql", "mssql"]:
                criticality = "ELEVEE"

            # number of exploits concerning this port
            # exploits are related to known vulnerabilities or attack techniques
            # that match with detected services against public exploit
            nombre_exploits = 0
            exploits_details = []
            for table in port.findall(".//table"):
                exploit_info = {}
                for elem in table.findall("elem"):
                    key = elem.get("key")
                    val = elem.text.strip() if elem.text else ""
                    exploit_info[key] = val
                # only count and collect actual exploits
                if exploit_info.get("is_exploit", "").lower() == "true":
                    nombre_exploits += 1
                    exploits_details.append(
                        {
                            "id": exploit_info.get("id", "N/A"),
                            "cvss": float(exploit_info.get("cvss", 0)),
                            "type": exploit_info.get("type", "unknown"),
                        }
                    )
            # sort exploits by CVSS descending
            exploits_details.sort(key=lambda x: x["cvss"], reverse=True)

            # collecting the data concerning each open port
            host_info["ports_ouverts"].append(
                {
                    "port": port_id,
                    "protocole": protocol,
                    "etat": state,
                    "service": service_name,
                    "criticite": criticality,
                    "version": version,
                    "nombre_exploits": nombre_exploits,
                    "exploits_details": exploits_details,
                }
            )

        # vulnerabilities ====================================================================
        # collect all the informations concerning the vulnerabilities of the NSE scripts
        for script in host.findall("hostscript/script"):
            script_id = script.get("id")
            output = script.get("output", "")
            description, criticality = eval_vuln(output)

            # collect pertinent data
            if description:
                host_info["vulnerabilities"].append(
                    {
                        "script": script_id,
                        "description": description,
                        "criticite": criticality,
                    }
                )

        # complete the final report with all the informations and data required
        report.append(host_info)

    return report


def eval_tcpcriticality(difficulty: Optional[str]) -> str:
    """
    Evaluate the security criticality of TCP sequence predictability.

    TCP sequence predictability affects the difficulty of TCP session
    hijacking attacks. More predictable sequences are more vulnerable.

    Args:
        difficulty: The TCP sequence difficulty level from nmap:
            - "Good luck!" or "Hard": Very difficult to predict
            - "Medium": Moderately predictable
            - "Easy": Highly predictable (vulnerable)
            - None or other: Unknown

    Returns:
        Criticality level as a string:
        - "FAIBLE": Low risk (hard to predict)
        - "MOYENNE": Medium risk
        - "ELEVEE": High risk (easy to predict)
        - "null": Unknown/not determined
    """
    if difficulty == "Good luck!" or difficulty == "Hard":
        return "FAIBLE"
    elif difficulty == "Medium":
        return "MOYENNE"
    elif difficulty == "Easy":
        return "ELEVEE"
    else:
        return "null"


def eval_ipidcriticality(ipidclass: Optional[str]) -> str:
    """
    Evaluate the security criticality of IPID sequence behavior.

    IPID (IP Identification) sequence analysis can reveal information
    about the host and potentially enable idle scanning attacks.

    Args:
        ipidclass: The IPID sequence class from nmap:
            - "Randomized" or "All zeros": Secure, unpredictable
            - "Constant": Moderately concerning
            - "Incremental" or "Broken incremental": Vulnerable to idle scan

    Returns:
        Criticality level as a string:
        - "FAIBLE": Low risk (randomized/zeros)
        - "MOYENNE": Medium risk (constant)
        - "ELEVEE": High risk (incremental patterns)
        - "null": Unknown/not determined
    """
    if ipidclass in ["Randomized", "All zeros"]:
        return "FAIBLE"
    elif ipidclass == "Constant":
        return "MOYENNE"
    elif ipidclass in ["Incremental", "Broken incremental"]:
        return "ELEVEE"
    else:
        return "null"


def eval_vuln(output: str) -> tuple[str, str]:
    """
    Evaluate vulnerabilities detected by NSE (Nmap Scripting Engine) scripts.

    This function analyzes the output of NSE vulnerability scripts and
    categorizes findings based on keywords indicating severity.

    Args:
        output: The raw output text from the NSE script execution.

    Returns:
        A tuple of (description, criticality):
        - description: Human-readable description of the finding (in French)
        - criticality: One of "CRITIQUE", "ELEVEE", "MOYENNE"

    Categorization Rules:
        - CRITIQUE: CVE, exploit, backdoor, vulnerable, malware, trojan
        - ELEVEE: Brute-force, information disclosure, outdated versions
        - MOYENNE: General security information

    Example:
        >>> desc, level = eval_vuln("CVE-2017-5638 found")
        >>> print(f"{level}: {desc}")
        CRITIQUE: Vulnérabilité critique détecté
    """
    output = output.lower()  # avoid the syntax confusion

    # known vulnerabilities (CVE,exploits,backdoors)
    if (
            "cve" in output
            or "exploit" in output
            or "backdoor" in output
            or "vulnerable" in output
    ):
        return ("Vulnérabilité critique détecté", "CRITIQUE")
    # malware or suspicious behavior
    elif (
            "malware" in output
            or "suspicious" in output
            or "trojan" in output
            or "unrealircd" in output
    ):
        return ("Comportement suspect ou logiciel malveillant détecté", "CRITIQUE")

    # brute-force or login attempts
    elif (
            "brute force" in output
            or "login attempt" in output
            or "guessing" in output
            or "dictionnary attack" in output
            or "multiple failed" in output
    ):
        return ("Brute-force ou tentatie d'authentification détecté", "ELEVEE")
    # information disclosure or excessive enumeration
    elif (
            "information disclosure" in output
            or "leaks" in output
            or "zone transfer" in output
            or "enumeration" in output
            or "exposed records" in output
    ):
        return (
            "Divulgation d'informations sensibles ou énumération excessive",
            "ELEVEE",
        )
    # outdated or vulnerable version
    elif (
            "outdated version" in output
            or "version vulnerable" in output
            or "unsupported os" in output
    ):
        return ("Version obsolète ou potentiellement vulnérable", "ELEVEE")

    else:
        return ("Information de sécurité détectée", "MOYENNE")


# ========================================================================================


def export_as_json(
        donnees: List[Dict[str, Any]],
        nom_rapport: str = "resultat_scan_reseau",
        output_dir: str = "."
) -> str:
    """
    Export scan results to a JSON file with timestamp in filename.

    Creates a JSON file containing the structured scan data with
    automatic timestamping for unique filenames.

    Args:
        donnees: The scan data to export (list of host dictionaries).
        nom_rapport: Base name for the output file (default: "resultat_scan_reseau").
        output_dir: Directory to save the JSON file (default: current directory).

    Returns:
        The full path to the created JSON file.

    Example:
        >>> hosts = parse_xml("scan.xml")
        >>> json_path = export_as_json(hosts, output_dir="/results")
        >>> print(f"Results saved to: {json_path}")
        Results saved to: /results/resultat_scan_reseau_2026-03-12_14-30-00.json
    """
    # take today's date
    date = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    nom_fichier = Path(output_dir) / f"{nom_rapport}_{date}.json"

    # create the JSON file with the file given in the parameters
    with open(nom_fichier, "w", encoding="utf-8") as fichier:
        json.dump(donnees, fichier, ensure_ascii=False, indent=4)

    return str(nom_fichier)


def networkscan_analysis(file_xml: str, output_dir: str = ".") -> str:
    """
    Complete network scan analysis pipeline.

    This is the main entry point for processing nmap scan results.
    It parses the XML output and generates a structured JSON report.

    Args:
        file_xml: Path to the nmap XML output file.
        output_dir: Directory to save the JSON report (default: current directory).

    Returns:
        Path to the generated JSON report file.

    Example:
        >>> json_path = networkscan_analysis("scan.xml", "results")
        >>> print(f"Report saved to: {json_path}")

    Note:
        This function combines parse_xml() and export_as_json() into
        a single convenient workflow.
    """
    # sort the XML file data, with the scan output
    parsed_data = parse_xml(file_xml)
    json_file = export_as_json(parsed_data, output_dir=output_dir)

    logger.info("Rapport JSON réalisé avec succès.")
    return json_file
